# Proposal review · [#145077](https://dashboard.internetcomputer.org/proposal/145077)

Proposal #145077 · After proposal #145077 · Step 1 of 1

Subnet [5kdm2-62fc6-fwnja-hutkz-ycsnm-4z33i-woh43-4cenu-ev7mi-gii6t-4ae](https://dashboard.internetcomputer.org/network/subnets/5kdm2-62fc6-fwnja-hutkz-ycsnm-4z33i-woh43-4cenu-ev7mi-gii6t-4ae)

## Summary

Replace one node at dl1 with one at ge2. The subnet remains at 13 nodes. dl1 loses its last subnet member. ge2 membership changes 0 → 1.

13 members · Add 1 · Remove 1 · Unchanged 12

Target subnet checked; assignments in the other 97 listed subnets were not checked.

## Evidence scope

Pinned Registry version **66,264**. Governance checked after the selected comparisons.

- #145077 · Open observed 2026-11-27 19:02:41.220 UTC

- Proposed membership is conditional on the pinned evidence. Full execution validity remains unverified.

## Map

![Map of registered node locations for the selected comparison](map.png)

Add (green) · Remove (red) · Unchanged (blue). 14 unique nodes across both states · 14/14 located. Positions use the registered data-center coordinates. The dotted halo indicates multiple node identities at the same coordinates.

Natural Earth map-unit boundaries are cartographic. Country shading uses recorded membership groups. Green shows increases and red shows decreases. A dashed border marks a country falling to zero. Small squares mark represented map units too small to see at the current zoom.

Changed sites · dl1 · 1 → 0 nodes · ge2 · 0 → 1 nodes

## Node changes

| Action | Node | Data center | Registered owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
| Remove | [haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe](https://dashboard.internetcomputer.org/network/nodes/haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe) | [dl1](https://dashboard.internetcomputer.org/network/centers/dl1) | Flexential | [eipr5-izbom-neyqh-s3ec2-52eww-cyfpg-qfomg-3dpwj-4pffh-34xcu-7qe](https://dashboard.internetcomputer.org/network/provider/eipr5-izbom-neyqh-s3ec2-52eww-cyfpg-qfomg-3dpwj-4pffh-34xcu-7qe) | mw64v-jynex-7tu52-5a3te-ifbop-nh7y7-w7lno-ymmht-b7fmy-wfhha-gqe | 🇺🇸 United States (US) |
| Add | [ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae](https://dashboard.internetcomputer.org/network/nodes/ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae) | [ge2](https://dashboard.internetcomputer.org/network/centers/ge2) | SafeHost | [7ryes-jnj73-bsyu4-lo6h7-lbxk5-x4ien-lylws-5qwzl-hxd5f-xjh3w-mqe](https://dashboard.internetcomputer.org/network/provider/7ryes-jnj73-bsyu4-lo6h7-lbxk5-x4ien-lylws-5qwzl-hxd5f-xjh3w-mqe) | 5atxd-q4jom-dtpxr-awd3p-e562x-hpavj-godtj-g6vmz-of2c6-ildhh-fae | 🇨🇭 Switzerland (CH) |

<details>
<summary>Other Nodes (12)</summary>

| Action | Node | Data center | Registered owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
|  | [ayf37-rq2hn-jiuvy-c2i3m-3kft2-v3jbe-c6mzo-f6yjy-sv52k-poii6-5ae](https://dashboard.internetcomputer.org/network/nodes/ayf37-rq2hn-jiuvy-c2i3m-3kft2-v3jbe-c6mzo-f6yjy-sv52k-poii6-5ae) | [sg3](https://dashboard.internetcomputer.org/network/centers/sg3) | Racks Central | [x7uok-pi537-itm37-unjn3-ewkze-kuetg-kptap-nuqak-auq7z-tn5ey-dqe](https://dashboard.internetcomputer.org/network/provider/x7uok-pi537-itm37-unjn3-ewkze-kuetg-kptap-nuqak-auq7z-tn5ey-dqe) | vicvb-nkzkt-tj2lz-yzzw4-gfcsj-3eggv-izdti-tarpt-fsojm-lgq22-wae | 🇸🇬 Singapore (SG) |
|  | [nusc3-gza5p-4iw7a-ea7xu-b6afg-r4sd3-saik7-io6zs-c36mg-q47ut-qae](https://dashboard.internetcomputer.org/network/nodes/nusc3-gza5p-4iw7a-ea7xu-b6afg-r4sd3-saik7-io6zs-c36mg-q47ut-qae) | [sj3](https://dashboard.internetcomputer.org/network/centers/sj3) | InfoObjects | [7ws2n-wqorv-vmo4m-5e222-n42c3-hk43s-ei3kp-4hpbn-xlkzo-jgv7i-tqe](https://dashboard.internetcomputer.org/network/provider/7ws2n-wqorv-vmo4m-5e222-n42c3-hk43s-ei3kp-4hpbn-xlkzo-jgv7i-tqe) | jtrpk-wokqg-aqmcn-esiq7-fip4e-dl7lv-iwdyj-cu5pm-wbg7i-4jl4t-wae | 🇺🇸 United States (US) |
|  | [zgeaf-fcq4e-fcnht-g7mpg-sb7ff-r6awk-zvkwp-gkloc-rr6jl-ghsse-mqe](https://dashboard.internetcomputer.org/network/nodes/zgeaf-fcq4e-fcnht-g7mpg-sb7ff-r6awk-zvkwp-gkloc-rr6jl-ghsse-mqe) | [ta2](https://dashboard.internetcomputer.org/network/centers/ta2) | Telia DC | [diyay-s4rfq-xnx23-zczwi-nptra-5254n-e4zn6-p7tqe-vqhzr-sd4gd-bqe](https://dashboard.internetcomputer.org/network/provider/diyay-s4rfq-xnx23-zczwi-nptra-5254n-e4zn6-p7tqe-vqhzr-sd4gd-bqe) | rhtt6-acsjc-c73k7-mnd7w-5253w-h35fr-lfknt-as6bb-rgxoy-xe4zr-dae | 🇪🇪 Estonia (EE) |
|  | [uouxk-c246i-dgxzd-ql3a5-koofn-mclrv-toplo-bg76d-l4dzk-ngb3c-nae](https://dashboard.internetcomputer.org/network/nodes/uouxk-c246i-dgxzd-ql3a5-koofn-mclrv-toplo-bg76d-l4dzk-ngb3c-nae) | [tb1](https://dashboard.internetcomputer.org/network/centers/tb1) | Cloud9 | [vegae-c4chr-aetfj-7gzuh-c23sx-u2paz-vmvbn-bcage-pu7lu-mptnn-eqe](https://dashboard.internetcomputer.org/network/provider/vegae-c4chr-aetfj-7gzuh-c23sx-u2paz-vmvbn-bcage-pu7lu-mptnn-eqe) | yhfy4-ny5ww-huz33-bkxym-eu27d-htlt4-yi77a-hvdqb-wpdlv-2cky7-uae | 🇬🇪 Georgia (GE) |
|  | [62yzt-726hf-rwk73-c3j6k-fjdls-7oqh5-exbnn-bvrsn-2soat-m4vg3-7ae](https://dashboard.internetcomputer.org/network/nodes/62yzt-726hf-rwk73-c3j6k-fjdls-7oqh5-exbnn-bvrsn-2soat-m4vg3-7ae) | [to2](https://dashboard.internetcomputer.org/network/centers/to2) | Cyxtera | [7at4h-nhtvt-a4s55-jigss-wr2ha-ysxkn-e6w7x-7ggnm-qd3d5-ry66r-cae](https://dashboard.internetcomputer.org/network/provider/7at4h-nhtvt-a4s55-jigss-wr2ha-ysxkn-e6w7x-7ggnm-qd3d5-ry66r-cae) | 4lp6i-khv7q-lkgk3-hhrc6-ysjag-korh7-ysojw-7gv3h-glhdz-rpjrt-sqe | 🇨🇦 Canada (CA) |
|  | [tu7cd-aljf3-56j73-xdusu-fyjps-sgkoi-5w3fx-p3vvd-tusca-w2vyl-bqe](https://dashboard.internetcomputer.org/network/nodes/tu7cd-aljf3-56j73-xdusu-fyjps-sgkoi-5w3fx-p3vvd-tusca-w2vyl-bqe) | [mn2](https://dashboard.internetcomputer.org/network/centers/mn2) | NEXTDC | [ihbuj-erwnc-tkjux-tqtnv-zkoar-uniy2-sk2go-xfpkc-znbb4-seukm-wqe](https://dashboard.internetcomputer.org/network/provider/ihbuj-erwnc-tkjux-tqtnv-zkoar-uniy2-sk2go-xfpkc-znbb4-seukm-wqe) | l5lhp-734i5-tbott-vipvc-vud2f-pfh7r-g3227-tgkdj-4rggm-abc2e-cae | 🇦🇺 Australia (AU) |
|  | [oswv7-a355p-a5jlp-ko7pj-arrs2-rghho-dti4z-xgptn-szn55-jjr46-uqe](https://dashboard.internetcomputer.org/network/nodes/oswv7-a355p-a5jlp-ko7pj-arrs2-rghho-dti4z-xgptn-szn55-jjr46-uqe) | [ty3](https://dashboard.internetcomputer.org/network/centers/ty3) | Equinix | [sixix-2nyqd-t2k2v-vlsyz-dssko-ls4hl-hyij4-y7mdp-ja6cj-nsmpf-yae](https://dashboard.internetcomputer.org/network/provider/sixix-2nyqd-t2k2v-vlsyz-dssko-ls4hl-hyij4-y7mdp-ja6cj-nsmpf-yae) | a5glg-n6ul6-rkuc7-idthk-fb2fe-d5m75-4g4l7-22yko-h27pr-q3a7k-lae | 🇯🇵 Japan (JP) |
|  | [ihoip-fmbnl-mm4fa-pu7hu-2sbx2-mzl2f-tgzje-unnjg-bgcac-3apmo-gqe](https://dashboard.internetcomputer.org/network/nodes/ihoip-fmbnl-mm4fa-pu7hu-2sbx2-mzl2f-tgzje-unnjg-bgcac-3apmo-gqe) | [sg1](https://dashboard.internetcomputer.org/network/centers/sg1) | Telin | [6nbcy-kprg6-ax3db-kh3cz-7jllk-oceyh-jznhs-riguq-fvk6z-6tsds-rqe](https://dashboard.internetcomputer.org/network/provider/6nbcy-kprg6-ax3db-kh3cz-7jllk-oceyh-jznhs-riguq-fvk6z-6tsds-rqe) | d4bin-5o2wg-ycbdq-yljr7-45pjv-ptf6d-v243j-vg6x5-dlo7t-yqu62-5qe | 🇸🇬 Singapore (SG) |
|  | [zos66-lmcn7-satbv-gcdzj-q3cdf-4n6zc-2hlei-gc453-uoh7r-4sj3w-vqe](https://dashboard.internetcomputer.org/network/nodes/zos66-lmcn7-satbv-gcdzj-q3cdf-4n6zc-2hlei-gc453-uoh7r-4sj3w-vqe) | [sh1](https://dashboard.internetcomputer.org/network/centers/sh1) | Digital Realty | [bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe](https://dashboard.internetcomputer.org/network/provider/bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe) | lgp6d-brhlv-35izu-khc6p-rfszo-zdwng-xbtkh-xyvjg-y3due-7ha7t-uae | 🇸🇪 Sweden (SE) |
|  | [fbypf-pftue-r2nbt-pueee-s454b-ycsuw-pjqqn-h3rh4-vlfpo-tokd5-mae](https://dashboard.internetcomputer.org/network/nodes/fbypf-pftue-r2nbt-pueee-s454b-ycsuw-pjqqn-h3rh4-vlfpo-tokd5-mae) | [pl2](https://dashboard.internetcomputer.org/network/centers/pl2) | Yotta | [zy4m7-z5mhs-zfkpl-zlsjl-blrbx-mvvmq-5z4zu-mf7eq-hhv7o-ezfro-3ae](https://dashboard.internetcomputer.org/network/provider/zy4m7-z5mhs-zfkpl-zlsjl-blrbx-mvvmq-5z4zu-mf7eq-hhv7o-ezfro-3ae) | 7rw6b-6r7qv-al3uk-rimg7-ifkjv-hettz-lhmly-t55g7-xrwac-25ayy-wae | 🇮🇳 India (IN) |
|  | [ocvcv-56eg5-gxibh-dcgpo-unhwq-4bwmo-x7q3h-stwf2-ycfex-gdr2a-kae](https://dashboard.internetcomputer.org/network/nodes/ocvcv-56eg5-gxibh-dcgpo-unhwq-4bwmo-x7q3h-stwf2-ycfex-gdr2a-kae) | [jb2](https://dashboard.internetcomputer.org/network/centers/jb2) | Africa Data Centres | [nmdd6-rouxw-55leh-wcbkn-kejit-njvje-p4s6e-v64d3-nlbjb-vipul-mae](https://dashboard.internetcomputer.org/network/provider/nmdd6-rouxw-55leh-wcbkn-kejit-njvje-p4s6e-v64d3-nlbjb-vipul-mae) | 3bohy-zygmq-6novb-wm65r-3k3y2-deh42-7emld-zhqo7-xl2oa-iextm-fae | 🇿🇦 South Africa (ZA) |
|  | [wq5v7-ngito-7ztqs-zlf2v-ibk6f-e54em-t3hou-x24kz-v5j77-6vo72-kqe](https://dashboard.internetcomputer.org/network/nodes/wq5v7-ngito-7ztqs-zlf2v-ibk6f-e54em-t3hou-x24kz-v5j77-6vo72-kqe) | [lj1](https://dashboard.internetcomputer.org/network/centers/lj1) | Posita.si | [wdjjk-blh44-lxm74-ojj43-rvgf4-j5rie-nm6xs-xvnuv-j3ptn-25t4v-6ae](https://dashboard.internetcomputer.org/network/provider/wdjjk-blh44-lxm74-ojj43-rvgf4-j5rie-nm6xs-xvnuv-j3ptn-25t4v-6ae) | gl27f-y5srq-yy5ot-v4x5z-y2a2s-sgoor-l4gjg-qv4x4-v2olb-dz4dc-wae | 🇸🇮 Slovenia (SI) |

</details>

## Decentralisation

Arrows show before → proposed; a single value is unchanged.

### Different groups represented

How many different registered groups have at least one member in this subnet?

| Continent | Country | Data center | Registered owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 5 | 11 → 12 | 13 | 13 | 13 | 13 |

### Largest group size

The most subnet nodes sharing one value, such as one provider or one country label. Several groups may tie.

| Continent | Country | Data center | Registered owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 5 | 2 | 1 | 1 | 1 | 1 |

### Nakamoto coefficients

How many of the largest registered groups together contain more than one-third of the subnet's nodes? Each state uses floor(N / 3) + 1. Recorded groups do not establish independent ownership, subnet safety, execution validity or Target Topology compliance.

Node threshold: 5.

| Continent | Country | Data center | Registered owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 1 | 3 → 4 | 5 | 5 | 5 | 5 |

### Distances between registered node locations

Straight-line geographic distances calculated from registered data-center coordinates, counting each pair of nodes once. These are not measured network latency or health.

| Shortest | Average | Longest |
| --- | --- | --- |
| 14.0 km | 8,913.3 km → 8,397.9 km | 16,948.9 km |

78 of 78 pairs before and proposed.

No current Target Topology thresholds, exceptions or applicability are assumed.

<details>
<summary>Recorded country membership</summary>

| Country (recorded token) | Subnet members |
| --- | --- |
| 🇦🇺 Australia (AU) | 1 |
| 🇨🇦 Canada (CA) | 1 |
| 🇨🇭 Switzerland (CH) | 0 → 1 |
| 🇪🇪 Estonia (EE) | 1 |
| 🇬🇪 Georgia (GE) | 1 |
| 🇮🇳 India (IN) | 1 |
| 🇯🇵 Japan (JP) | 1 |
| 🇸🇪 Sweden (SE) | 1 |
| 🇸🇬 Singapore (SG) | 2 |
| 🇸🇮 Slovenia (SI) | 1 |
| 🇺🇸 United States (US) | 2 → 1 |
| 🇿🇦 South Africa (ZA) | 1 |

</details>

## Sources and calculation

Membership preview revision `fa01f85f47233c9f48a7d4634a298f4363302b7e4e66605c2bae58583afce7be`.

Calculation input SHA-256 `ef3ead6ee6fa98e72887f92ac7f3186a50768c6fba4619d1dae5086d558e92ca` · analysis v5.

The replicated calculation digest identifies the exact submitted evidence and scope. Source receipts identify the separate Registry and Governance observations.

- #145077 executable payload SHA-256 7b30eb7aa652f5192d7b07e28912caf75289a5d16c87c7bfe16037ea86b69050

<details>
<summary>Exact distance evidence in metres</summary>

| Distance | Before | Proposed |
| --- | --- | --- |
| Shortest | 13952 | 13952 |
| Average | 8913267 | 8397901 |
| Longest | 16948908 | 16948908 |

</details>

<details>
<summary>Registered geography evidence</summary>

| Data center | Original Registry region | Country token |
| --- | --- | --- |
| [dl1](https://dashboard.internetcomputer.org/network/centers/dl1) | North America,US,Texas | US |
| [ge2](https://dashboard.internetcomputer.org/network/centers/ge2) | Europe,CH,Geneva | CH |
| [sg3](https://dashboard.internetcomputer.org/network/centers/sg3) | Asia,SG,Singapore | SG |
| [sj3](https://dashboard.internetcomputer.org/network/centers/sj3) | North America,US,California | US |
| [ta2](https://dashboard.internetcomputer.org/network/centers/ta2) | Europe,EE,Tallinn | EE |
| [tb1](https://dashboard.internetcomputer.org/network/centers/tb1) | Asia,GE,Tbilisi | GE |
| [to2](https://dashboard.internetcomputer.org/network/centers/to2) | North America,CA,Ontario | CA |
| [mn2](https://dashboard.internetcomputer.org/network/centers/mn2) | Oceania,AU,Melbourne | AU |
| [ty3](https://dashboard.internetcomputer.org/network/centers/ty3) | Asia,JP,Tokyo | JP |
| [sg1](https://dashboard.internetcomputer.org/network/centers/sg1) | Asia,SG,Singapore | SG |
| [sh1](https://dashboard.internetcomputer.org/network/centers/sh1) | Europe,SE,Stockholm | SE |
| [pl2](https://dashboard.internetcomputer.org/network/centers/pl2) | Asia,IN,Panvel | IN |
| [jb2](https://dashboard.internetcomputer.org/network/centers/jb2) | Africa,ZA,Gauteng | ZA |
| [lj1](https://dashboard.internetcomputer.org/network/centers/lj1) | Europe,SI,Ljubljana | SI |

</details>

<details>
<summary>Session source receipts (53)</summary>

| Method | Item | Canister | Observed at | Reply SHA-256 or issue |
| --- | --- | --- | --- | --- |
| get\_proposal\_info | 145077 | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-27 19:01:49.769 UTC | e31db12c2577ccc70d1f10a1b5eb03e811b95395a4b5fe67af57bd211ac0a8a4 |
| get\_latest\_version | Registry head | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:01:52.531 UTC | 78dbea3c701c2af3efb51551d46818c01b53abd04e04978f116df49d8d5d38c4 |
| get\_value | subnet\_list | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:01:54.786 UTC | e700ca41381ba571f790b439875b923b4845fc269cfdb27ba1cb7dff6643f2b1 |
| get\_value | subnet\_record\_5kdm2-62fc6-fwnja-hutkz-ycsnm-4z33i-woh43-4cenu-ev7mi-gii6t-4ae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:01:56.986 UTC | 8a1f98eaed40644a5df8d19ae788235ceaa51cb51f66269535341c1c1f792041 |
| get\_value | node\_record\_haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:00.299 UTC | 3bf2975c0c1ed7a5f53c39e99b09dd2cc9ff510b5fd655274929c97cf667da0c |
| get\_value | node\_record\_ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:00.299 UTC | dc31d0aa28b9dac3dad08d0187c25cee04a5710d9c3750ee6ac11a5b9d0e44cb |
| get\_value | api\_boundary\_node\_haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:02.878 UTC | 0498d94b2e26beb1b374582e9b9463536cca019faf3c09b5077803cc32a2f3a3 |
| get\_value | api\_boundary\_node\_ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:02.878 UTC | 7293afa89d738fce16dd32596430a6c20ea5d62ce0d600fb7848e410d9b508c0 |
| get\_proposal\_info | 145077 | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-27 19:02:06.818 UTC | d4a0a81ad1949bccc1c817741dd7bbb65197622488f7f51f6ff47d3988d8ea2c |
| get\_value | node\_record\_ayf37-rq2hn-jiuvy-c2i3m-3kft2-v3jbe-c6mzo-f6yjy-sv52k-poii6-5ae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:13.960 UTC | 7a13411b346fbf7431ba58a949c4d9e83fa4eec53c20b7ec405dbba17bb3b27e |
| get\_value | node\_record\_nusc3-gza5p-4iw7a-ea7xu-b6afg-r4sd3-saik7-io6zs-c36mg-q47ut-qae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:13.960 UTC | ec6c88916e796d48b35e45989d5fb4cb6c637d23a4cf39975551b359d082f0cb |
| get\_value | node\_record\_fbypf-pftue-r2nbt-pueee-s454b-ycsuw-pjqqn-h3rh4-vlfpo-tokd5-mae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:13.960 UTC | 63164ab676a82f040f5d341061ae5fe7b66cf55c3a8b582482be8c99bd1ab720 |
| get\_value | node\_record\_zgeaf-fcq4e-fcnht-g7mpg-sb7ff-r6awk-zvkwp-gkloc-rr6jl-ghsse-mqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:13.960 UTC | 0f87f853f0b6989f3d82fd17f21e9ec935c495f7c7a006a515c22b462f2446fb |
| get\_value | node\_record\_uouxk-c246i-dgxzd-ql3a5-koofn-mclrv-toplo-bg76d-l4dzk-ngb3c-nae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:13.960 UTC | a78445b3111f3a31af22c1c1d6171f15b0bdab6189ee629d1ee1d18b64387a9d |
| get\_value | node\_record\_haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:13.960 UTC | 3bf2975c0c1ed7a5f53c39e99b09dd2cc9ff510b5fd655274929c97cf667da0c |
| get\_value | node\_record\_tu7cd-aljf3-56j73-xdusu-fyjps-sgkoi-5w3fx-p3vvd-tusca-w2vyl-bqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:13.960 UTC | 0ccf240850bd9de7558835b2cdb22dd87303adda01bbc062bde835078de4d9d6 |
| get\_value | node\_record\_62yzt-726hf-rwk73-c3j6k-fjdls-7oqh5-exbnn-bvrsn-2soat-m4vg3-7ae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:13.960 UTC | a98c3bd41ca7a3d61b39d2e16efe7ee5f42ff8a841040cfb0bbda4273523a886 |
| get\_value | node\_record\_ihoip-fmbnl-mm4fa-pu7hu-2sbx2-mzl2f-tgzje-unnjg-bgcac-3apmo-gqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:16.128 UTC | 56cf7d3554c76967daebe23ece33b9c424264380cbcbbf6ec4720b389b02b4f6 |
| get\_value | node\_record\_ocvcv-56eg5-gxibh-dcgpo-unhwq-4bwmo-x7q3h-stwf2-ycfex-gdr2a-kae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:16.128 UTC | 6c33d7067c02f8b870a942929a7ff126188df8af9fa93b40c9fe702ba843f456 |
| get\_value | node\_record\_zos66-lmcn7-satbv-gcdzj-q3cdf-4n6zc-2hlei-gc453-uoh7r-4sj3w-vqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:16.128 UTC | b03c333111717ee2c97018d2691fa903ea88cce162c369f5accf5aa0f5973362 |
| get\_value | node\_record\_oswv7-a355p-a5jlp-ko7pj-arrs2-rghho-dti4z-xgptn-szn55-jjr46-uqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:16.128 UTC | 2f244d753babdb191829ffd675f867582a4acc63f063400e533bcbeb271988a7 |
| get\_value | node\_record\_wq5v7-ngito-7ztqs-zlf2v-ibk6f-e54em-t3hou-x24kz-v5j77-6vo72-kqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:16.128 UTC | 66df3f5ec6a63b1ac5f6fbc7ef924f12a9b9d2e7d6efe275b97a9f4cff57e65a |
| get\_value | node\_record\_ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:16.128 UTC | dc31d0aa28b9dac3dad08d0187c25cee04a5710d9c3750ee6ac11a5b9d0e44cb |
| get\_value | node\_operator\_record\_vicvb-nkzkt-tj2lz-yzzw4-gfcsj-3eggv-izdti-tarpt-fsojm-lgq22-wae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:19.625 UTC | 74524f4e0d2dfeb212e54508286e6ba4655c127fb7df49e27ec65e3b94a430df |
| get\_value | node\_operator\_record\_jtrpk-wokqg-aqmcn-esiq7-fip4e-dl7lv-iwdyj-cu5pm-wbg7i-4jl4t-wae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:19.625 UTC | 062f7237a6310b21827142faa3d7003ae741febab3f65467e676bec3944e1d38 |
| get\_value | node\_operator\_record\_7rw6b-6r7qv-al3uk-rimg7-ifkjv-hettz-lhmly-t55g7-xrwac-25ayy-wae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:19.625 UTC | c3be55698ca63e14b767c582e6e52ca7d62e43a2839332ec503ae7aa9217b0dc |
| get\_value | node\_operator\_record\_rhtt6-acsjc-c73k7-mnd7w-5253w-h35fr-lfknt-as6bb-rgxoy-xe4zr-dae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:19.625 UTC | 7a60333ead9adb13ce3cb37fea51b9faeaf199d60fce0752ec695acad9fa5425 |
| get\_value | node\_operator\_record\_yhfy4-ny5ww-huz33-bkxym-eu27d-htlt4-yi77a-hvdqb-wpdlv-2cky7-uae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:19.625 UTC | 150593eea924e0fa1c830473c60497b28d7ca2f1773bba29b5350370ad55a552 |
| get\_value | node\_operator\_record\_mw64v-jynex-7tu52-5a3te-ifbop-nh7y7-w7lno-ymmht-b7fmy-wfhha-gqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:19.625 UTC | 9e807809b50c46f444d850166529b66e5d0d22c627909bae03e84e0cf4465284 |
| get\_value | node\_operator\_record\_l5lhp-734i5-tbott-vipvc-vud2f-pfh7r-g3227-tgkdj-4rggm-abc2e-cae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:19.625 UTC | 870a6d6179dd65e901e02a2c2f7c67aba57d6f4e5a458a8c5078ad5998331f5e |
| get\_value | node\_operator\_record\_4lp6i-khv7q-lkgk3-hhrc6-ysjag-korh7-ysojw-7gv3h-glhdz-rpjrt-sqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:19.625 UTC | 1c6bda60eae8cdff26d68fd39a03abc7a4a3d5a693b95fb47240be9e38353c81 |
| get\_value | node\_operator\_record\_d4bin-5o2wg-ycbdq-yljr7-45pjv-ptf6d-v243j-vg6x5-dlo7t-yqu62-5qe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:22.395 UTC | 605f0773da9d12d3a9428068393a1a7c258702ca68243fe5bdee8db153e02aaa |
| get\_value | node\_operator\_record\_3bohy-zygmq-6novb-wm65r-3k3y2-deh42-7emld-zhqo7-xl2oa-iextm-fae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:22.395 UTC | 55f1550a690609159b3bdbc1d34f5c1a122b5c43252024d19d08f8f461ff4185 |
| get\_value | node\_operator\_record\_lgp6d-brhlv-35izu-khc6p-rfszo-zdwng-xbtkh-xyvjg-y3due-7ha7t-uae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:22.395 UTC | 8b2fbe78cc4b1377882bb74555264106dd4c5970f199b579868fc3e5a41245fc |
| get\_value | node\_operator\_record\_a5glg-n6ul6-rkuc7-idthk-fb2fe-d5m75-4g4l7-22yko-h27pr-q3a7k-lae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:22.395 UTC | ca3dc094aa5bf974475b42b231448e3809b20828259d66d6528e1dd3c05ca456 |
| get\_value | node\_operator\_record\_gl27f-y5srq-yy5ot-v4x5z-y2a2s-sgoor-l4gjg-qv4x4-v2olb-dz4dc-wae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:22.395 UTC | 1fa4d72537af8fbd1798916221dde161175a7fad9a85f05b40e303dc74d705c1 |
| get\_value | node\_operator\_record\_5atxd-q4jom-dtpxr-awd3p-e562x-hpavj-godtj-g6vmz-of2c6-ildhh-fae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:22.395 UTC | 1388360b56112f1080e9e265c5876cad17e78f9dfb72f6bdaa76175bd01542aa |
| get\_value | data\_center\_record\_sg3 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:26.710 UTC | 90929f77df0b87158be9d169b7a4530d3702cdbcf5a548deaf9d1c9a98d34e66 |
| get\_value | data\_center\_record\_sj3 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:26.710 UTC | 544c70ff00ec165e5dfa5984b2a8948e18198a318a237fc98acd1b278d5b748f |
| get\_value | data\_center\_record\_pl2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:26.710 UTC | 7e0739d8f49ab5e841be5444a4bf280c278bf3fc5b6c1a29c3c7178cd235bc97 |
| get\_value | data\_center\_record\_ta2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:26.710 UTC | 657ac5bb67a5a177a95839ecc47da108483804f91d73ab9d15795af35862975a |
| get\_value | data\_center\_record\_tb1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:26.710 UTC | f0d69ba00d6458422c91d6b4d642fed99468654e2a9eb64f7a231bd3a592958d |
| get\_value | data\_center\_record\_dl1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:26.710 UTC | 570fa1dfc7c9ae7e05f1781a760e9c465be126482cc23cd77369d86b3b103dfe |
| get\_value | data\_center\_record\_mn2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:26.710 UTC | fcd7ea30f65e5626fc407494a5a67c98a1c9107c39bb4a404d12e002d4751982 |
| get\_value | data\_center\_record\_to2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:26.710 UTC | 7161762007c951239545c9fc2ea667c99df4da49bb96ee366972bceaf74e6741 |
| get\_value | data\_center\_record\_sg1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:30.160 UTC | 8063f1b111f69a286f34d0ee712ad6a834f57a52f62aab5634039a231095e7c2 |
| get\_value | data\_center\_record\_jb2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:30.160 UTC | c3de5004f3e0bab997fdb6a247ebeebcefdf8185b1d61f52ed5b634cf48f2fa9 |
| get\_value | data\_center\_record\_sh1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:30.160 UTC | 5efaa12dbed1f6f6ec61857abab3f001b8e7c8193e92b72642dbe71707ae36c9 |
| get\_value | data\_center\_record\_ty3 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:30.160 UTC | 9b914fd2c10cfb81862c10844447af01e280a5af3008521561e21955cbc5c0c3 |
| get\_value | data\_center\_record\_lj1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:30.160 UTC | 5f6dae6011b9f61e3f1c0a7710009816800e54292d1ffc313b541ab4b5d6e9db |
| get\_value | data\_center\_record\_ge2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:30.160 UTC | f5fe58753652335ca955fa15826fe946c69cd3d4350511c5d5916827829d0e78 |
| get\_value | nns\_subnet\_id | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-27 19:02:35.430 UTC | 74ca3bc2b0e0a7a0f6c02c9a4f286cbd1616ef3b3ce2cae7ecf2495d691d6154 |
| get\_proposal\_info | 145077 | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-27 19:02:41.220 UTC | ee88dbc69c5c16143d01480048b6fbded090d7ebf46c41295a207c251a9f316d |

</details>
