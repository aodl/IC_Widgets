# Proposal review · [#990022](https://dashboard.internetcomputer.org/proposal/990022) + [#990021](https://dashboard.internetcomputer.org/proposal/990021)

Proposal #990022 then Proposal #990021 · After proposal #990021 · Step 2 of 2

Subnet [5ag63-q3yke-ba](https://dashboard.internetcomputer.org/network/subnets/5ag63-q3yke-ba)

Bundled test case · Synthetic scenario · Constructed Open proposal · Registry 100

## Summary

Add 4 and remove 4 nodes. The subnet remains at 6 nodes.

6 members · Add 4 · Remove 4 · Unchanged 2

Checked all 1 listed subnet memberships. Full execution validity remains unverified.

- NNS role was not recorded at the pinned version

## Evidence scope

Pinned Registry version **100**. Governance checked after the selected comparisons.

- #990021 · Constructed status: Open · Synthetic Governance action · Fixture backend observed 2026-11-28 10:14:49.406 UTC
- #990022 · Constructed status: Open · Synthetic Governance action · Fixture backend observed 2026-11-28 10:14:49.406 UTC

- NNS role was not recorded at the pinned version
- Proposed membership is conditional on the pinned evidence. Full execution validity remains unverified.

Original Registry observation times unavailable for this replay.

## Review checks

Conservative availability model. The fault budget is floor((N − 1) / 3). Model departing nodes unavailable in the before-state and incoming nodes still synchronizing in the proposed state. The smaller margin applies. A margin below one triggers a warning. The cumulative case keeps all earlier arrivals unavailable while they remain in the subnet. These conditional margins do not establish global assignment, execution validity or actual liveness.

### Step 1 · Proposal #990022

Add and Remove are disjoint · Add duplicates 0 · Remove duplicates 0 · Membership preconditions · Established within the checked membership scope

Conditional step margin · Warning · modeled fault budget exceeded by 2

<details>
<summary>Instruction and margin arithmetic</summary>

- Duplicate Add principals · none
- Duplicate Remove principals · none
- Overlapping principals · none
- Individual step · 5ag63-q3yke-ba · Before · 6 members, budget 1, modeled unavailable 3, remaining -2 · Proposed · 5 members, budget 1, modeled unavailable 2, remaining -1 · Limiting side: before · Margin -2

</details>

### Step 2 · Proposal #990021

Add and Remove overlap · removal wins under the upstream simulation · Add duplicates 1 · Remove duplicates 1 · Membership preconditions · Established within the checked membership scope

Conditional step margin · Warning · modeled fault budget exceeded by 1

Cumulative unsynchronized arrivals · Warning · modeled fault budget exceeded by 3

<details>
<summary>Instruction and margin arithmetic</summary>

- Duplicate Add principals · kk3lb-f3yae-ba
- Duplicate Remove principals · kk3lb-f3yae-ba
- Overlapping principals · kk3lb-f3yae-ba
- Individual step · 5ag63-q3yke-ba · Before · 5 members, budget 1, modeled unavailable 1, remaining 0 · Proposed · 6 members, budget 1, modeled unavailable 2, remaining -1 · Limiting side: proposed · Margin -1
- Cumulative · 5ag63-q3yke-ba · Before · 5 members, budget 1, modeled unavailable 3, remaining -2 · Proposed · 6 members, budget 1, modeled unavailable 4, remaining -3 · Limiting side: proposed · Margin -3
- Earlier arrivals modeled · qn2ax-xtyba-ba, tjxtv-h3ybe-ba. Each contributes only to states where present.

</details>

Governance check complete within the supported evidence · 0 references found

- Sources uxrrr-q7777-77774-qaaaq-cai · 4 admitted reads

- Discovery observed 2026-11-28 10:14:49.748 UTC to 2026-11-28 10:14:49.748 UTC

- Pagination complete · 2 pages · oldest listed #990021 · Open 2 · Adopted awaiting execution 0

- Title, summary and supported motion text checked for 2 proposals · Supported actions decoded 2 · Hydrated 0 · Lifecycle changed 0

- Unsupported actions 0 · Missing payloads 0 · Malformed payloads 0 · Omitted findings 0

- Findings restricted to accepted instructions for #990021, #990022 · Review-specific discovery.

## Map

![Map of registered node locations for the selected comparison](map.png)

Add (green) · Remove (red) · Unchanged (blue). 10 unique nodes across both states · 10/10 located. Positions use the registered data-center coordinates. The dotted halo indicates multiple node identities at the same coordinates.

Natural Earth map-unit boundaries are cartographic. Country shading uses recorded membership groups. Green shows increases and red shows decreases. A dashed border marks a country falling to zero. Small squares mark represented map units too small to see at the current zoom.

Unmatched recorded country labels remain in the distribution.

Changed sites · fixture-0 · 3 nodes · fixture-1 · 3 nodes

## Node changes

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
| Remove | [kk3lb-f3yae-ba](https://dashboard.internetcomputer.org/network/nodes/kk3lb-f3yae-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
| Remove | [pgn6g-vdyai-ba](https://dashboard.internetcomputer.org/network/nodes/pgn6g-vdyai-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
| Remove | [mcane-flyam-ba](https://dashboard.internetcomputer.org/network/nodes/mcane-flyam-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
| Remove | [f7auj-utyaq-ba](https://dashboard.internetcomputer.org/network/nodes/f7auj-utyaq-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
| Add | [atwbo-elya4-ba](https://dashboard.internetcomputer.org/network/nodes/atwbo-elya4-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
| Add | [qn2ax-xtyba-ba](https://dashboard.internetcomputer.org/network/nodes/qn2ax-xtyba-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
| Add | [tjxtv-h3ybe-ba](https://dashboard.internetcomputer.org/network/nodes/tjxtv-h3ybe-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
| Add | [wfbgs-xdybi-ba](https://dashboard.internetcomputer.org/network/nodes/wfbgs-xdybi-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |

<details>
<summary>Other Nodes (2)</summary>

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
|  | [g3nhl-e3yau-ba](https://dashboard.internetcomputer.org/network/nodes/g3nhl-e3yau-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
|  | [dx3sm-udyay-ba](https://dashboard.internetcomputer.org/network/nodes/dx3sm-udyay-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |

</details>

## Decentralisation

Arrows show before → proposed; a single value is unchanged.

### Different groups represented

How many different registered groups have at least one member in this subnet?

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 1 | 2 | 2 | 2 | 2 | 2 |

### Largest group size

The most subnet nodes sharing one value, such as one provider or one country label. Several groups may tie.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 6 | 3 | 3 | 3 | 3 | 3 |

### Nakamoto coefficients

How many of the largest registered groups together contain more than one-third of the subnet's nodes? Each state uses floor(N / 3) + 1. Recorded groups do not establish independent ownership, subnet safety, execution validity or Target Topology compliance.

Node threshold: 3.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 1 | 1 | 1 | 1 | 1 | 1 |

### Distances between registered node locations

Straight-line geographic distances calculated from registered data-center coordinates, counting each pair of nodes once. These are not measured network latency or health.

| Shortest | Average | Longest |
| --- | --- | --- |
| 0 km | 3,994.7 km | 6,657.9 km |

15 of 15 pairs before and proposed.

No current Target Topology thresholds, exceptions or applicability are assumed.

<details>
<summary>Recorded country membership</summary>

| Country (recorded token) | Subnet members |
| --- | --- |
| Label 0 | 3 |
| Label 1 | 3 |

</details>

## Sources and calculation

Membership preview revision `921ed8c24d4fc842ed9e78691469572b2b8dbb27d1bdb344fc5014e69dfaab26`.

Calculation input SHA-256 `1940208b3fbf66522904218def6ac2da85a42eb538afff6a710b7aa12a782cab` · analysis v5.

The replicated calculation digest identifies the exact submitted evidence and scope. Source receipts identify the separate Registry and Governance observations.

- #990021 executable payload SHA-256 9916e32bd1bc18a2defabaec6e862f9823ea972d9d853cc60732522205694e9e
- #990022 executable payload SHA-256 c0fc5d0a390a6b4ff5c5f78ebac8e1e4337458298dbcd7557052d795ad22518f

<details>
<summary>Exact distance evidence in metres</summary>

| Distance | Before | Proposed |
| --- | --- | --- |
| Shortest | 0 | 0 |
| Average | 3994711 | 3994711 |
| Longest | 6657851 | 6657851 |

</details>

<details>
<summary>Registered geography evidence</summary>

| Data center | Original Registry region | Country token |
| --- | --- | --- |
| [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Fixture,Label 0,Synthetic site 0 | Label 0 |
| [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Fixture,Label 1,Synthetic site 1 | Label 1 |

</details>

<details>
<summary>Membership and Registry source receipts (40)</summary>

| Evidence stage | ID | Method | Item | Canister | Observed at | Argument SHA-256 | Reply SHA-256 | Bytes | Rejection |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Membership preview · Governance | 1 | get\_proposal\_info | 990021 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | c835c1a463cda20bd8ffd1f841e2e2b4f21fa5b3b3ce5f2e0bc8d1e770b71ead | a4189cad8d1166e7d900f1d8cfba228cf61d627a784c156ba7af265c19bee4b5 | 430 | — |
| Membership preview · Governance | 2 | get\_proposal\_info | 990022 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | a7b9e3e8a8f44305d1a2e6b00648fd6cf79aa59512cb7aba4cadae8011ea4a24 | f1f82bdd1dd9462f4b1bb2946955669565c527eeb3f70284a1c3a1c277dc4fd8 | 425 | — |
| Membership preview · Registry | 3 | get\_latest\_version | Registry head | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | c0bffeaab8e16948afec4ac6e56088d8072a68d0788301b53e60560e8d85ce58 | 2 | — |
| Membership preview · Registry | 4 | get\_value | subnet\_list | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | 7b015b3b4f6a5d6f2354c4392603ed1e27adb7b7422646eedd217ca2ef85edf1 | 40061793c7ab638a07e0263d0c9edc78271ddc35825f444a9714da4e659a47e1 | 9 | — |
| Membership preview · Registry | 5 | get\_value | subnet\_record\_5ag63-q3yke-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | 671ff200155d9ab6380c902d8e4d0851ba128cf352d7a8507a8b27a13c9fdea8 | ac76668724a6016ad54cebc58ac8261bb0b1a00f12e25239eaa1cfb8065a311b | 36 | — |
| Membership preview · Registry | 6 | get\_value | node\_record\_kk3lb-f3yae-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | 235e029c22e90b1165c9624669eb5a690f92499c384f7d257d1c23d85224e552 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Membership preview · Registry | 7 | get\_value | node\_record\_pgn6g-vdyai-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | d59909f87f4f1f02e34dcd60eeec13782416c9967716db86a1d9755d9c3a96b8 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Membership preview · Registry | 8 | get\_value | node\_record\_mcane-flyam-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | 6ab0dcbc3931634a0d9f0060f766ad91778ecc7308b01e304f7d091ae2acf163 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Membership preview · Registry | 9 | get\_value | node\_record\_f7auj-utyaq-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | e350bd8046ed3a4da73cfbae91cac2ece9fb9a6603c86f09c1fa72769962ae01 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Membership preview · Registry | 10 | get\_value | node\_record\_atwbo-elya4-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | 4c3aee6d0201c2dbcba37843282408c468372a17186378c17026eaf12814cd0d | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Membership preview · Registry | 11 | get\_value | node\_record\_qn2ax-xtyba-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | 4ad7dcba605553c5a3f531e51da0e5ba4fc01eb6e6d989427cead729c03fd3e1 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Membership preview · Registry | 12 | get\_value | node\_record\_tjxtv-h3ybe-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | d60d5879d0be2cec7668473a6fef8a30ad4cdc5638caa82141b03f398ce2a298 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Membership preview · Registry | 13 | get\_value | node\_record\_wfbgs-xdybi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | 17cd515a02dd9da0d9ea7f1906c1683ba6a62ef98aa3f50789817433e3443354 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Membership preview · Registry | 14 | get\_value | api\_boundary\_node\_kk3lb-f3yae-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | 571f3e204e21cfa021ebd5cefdf8ea0a53bcc09a9a4cd457ef3fd199fbfd879b | e529d73779dbecacf4f438ddca5ffaf6acb7d5b8c21f4a2768d7cc15048628a8 | 66 | — |
| Membership preview · Registry | 15 | get\_value | api\_boundary\_node\_pgn6g-vdyai-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | 873a3488af5fec23a762f1d5003d7c4422ab85d40010840db433591a1e4481da | 6fb04ee8ef77f75ca6de77bb0fe1ac9dc783fa5ee5eb63b1b5ccfa1d0f4796a5 | 66 | — |
| Membership preview · Registry | 16 | get\_value | api\_boundary\_node\_mcane-flyam-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | effcc2501b5224c111aae8edae4f032c86ff1b1971747687c3ed1a415e1f4457 | 3d1df03ab5598250df94d18e4ac38e78f9b3ab6c3aebc3532df3f25dabd74633 | 66 | — |
| Membership preview · Registry | 17 | get\_value | api\_boundary\_node\_f7auj-utyaq-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | 3ecae51ed9af3d7beddcf8f50051f3c9d5e6aa30e5cb3ac0f6d135817318984a | de15154af0b9bf0ef9d96ea00a9f81c0bc45c7e5457a30b8bf9899366d24c725 | 66 | — |
| Membership preview · Registry | 18 | get\_value | api\_boundary\_node\_atwbo-elya4-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | 771e72405a35382ad8d752f97510617216e362582ce5d89f821480e0a8410d2e | 3d60352a77a7b3ba02a5a26f868c57e7eb5ccefaa0bfd2bbb63118e9d3ecc1c1 | 66 | — |
| Membership preview · Registry | 19 | get\_value | api\_boundary\_node\_qn2ax-xtyba-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | c0d07a4602945ed6c0e6d3c2777f487e803835ba099d44cd8eb0795778d04345 | e264d15ae03e9d8816f3c4d6a72f32f4d674e412b07009968ea50e45b8beccff | 66 | — |
| Membership preview · Registry | 20 | get\_value | api\_boundary\_node\_tjxtv-h3ybe-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | b9633ee8a1cae665156a93df28756becf64d3bdc9a67ba6f3b6f0085b9ebc9cf | 86b6dee61ef4eee816a81a7375e1693530027e2773b7ce5d288d6af0fb3ca964 | 66 | — |
| Membership preview · Registry | 21 | get\_value | api\_boundary\_node\_wfbgs-xdybi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | ec2394f7ee7765b1c49fa548c1f57e036147c4e83717adf33b736e2a9d2300f6 | 99c9b969a5f6bdab9313bb92ba54e5a0f42de2c343171a743701a120a1cd1ed8 | 66 | — |
| Membership preview · Governance | 22 | get\_proposal\_info | 990021 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | c835c1a463cda20bd8ffd1f841e2e2b4f21fa5b3b3ce5f2e0bc8d1e770b71ead | a4189cad8d1166e7d900f1d8cfba228cf61d627a784c156ba7af265c19bee4b5 | 430 | — |
| Membership preview · Governance | 23 | get\_proposal\_info | 990022 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.659 UTC | a7b9e3e8a8f44305d1a2e6b00648fd6cf79aa59512cb7aba4cadae8011ea4a24 | f1f82bdd1dd9462f4b1bb2946955669565c527eeb3f70284a1c3a1c277dc4fd8 | 425 | — |
| Registry enrichment · Nodes | 1 | get\_value | node\_record\_kk3lb-f3yae-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:46.044 UTC | 235e029c22e90b1165c9624669eb5a690f92499c384f7d257d1c23d85224e552 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Registry enrichment · Nodes | 2 | get\_value | node\_record\_pgn6g-vdyai-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:46.044 UTC | d59909f87f4f1f02e34dcd60eeec13782416c9967716db86a1d9755d9c3a96b8 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Registry enrichment · Nodes | 3 | get\_value | node\_record\_mcane-flyam-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:46.044 UTC | 6ab0dcbc3931634a0d9f0060f766ad91778ecc7308b01e304f7d091ae2acf163 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Registry enrichment · Nodes | 4 | get\_value | node\_record\_f7auj-utyaq-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:46.044 UTC | e350bd8046ed3a4da73cfbae91cac2ece9fb9a6603c86f09c1fa72769962ae01 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Registry enrichment · Nodes | 5 | get\_value | node\_record\_g3nhl-e3yau-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:46.044 UTC | 670273e3c423409dcc12e21200933dabf8a21456513bab85221563b17155e213 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Registry enrichment · Nodes | 6 | get\_value | node\_record\_dx3sm-udyay-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:46.044 UTC | c70a175e9b75ff9d0a96768bbd0cb4c02d54e218ba7b61d104297d4808a720a2 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Registry enrichment · Nodes | 7 | get\_value | node\_record\_qn2ax-xtyba-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:46.044 UTC | 4ad7dcba605553c5a3f531e51da0e5ba4fc01eb6e6d989427cead729c03fd3e1 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Registry enrichment · Nodes | 8 | get\_value | node\_record\_tjxtv-h3ybe-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:46.044 UTC | d60d5879d0be2cec7668473a6fef8a30ad4cdc5638caa82141b03f398ce2a298 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Registry enrichment · Nodes | 9 | get\_value | node\_record\_atwbo-elya4-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:46.044 UTC | 4c3aee6d0201c2dbcba37843282408c468372a17186378c17026eaf12814cd0d | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Registry enrichment · Nodes | 10 | get\_value | node\_record\_wfbgs-xdybi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:46.044 UTC | 17cd515a02dd9da0d9ea7f1906c1683ba6a62ef98aa3f50789817433e3443354 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Registry enrichment · Operators | 1 | get\_value | node\_operator\_record\_d4h56-4c2fi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:46.398 UTC | d6bd293fdb86568ac703a572219f01030f1fc3a5ba20d6184771df71d95f62ed | b7a469fce576bc5f0ffe09c60c5c7547423ab90160a86d9f71c535df6364257e | 25 | — |
| Registry enrichment · Operators | 2 | get\_value | node\_operator\_record\_d3g3k-r23fi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:46.398 UTC | 4fa37126004210f138e4a470265f13e48a463775b19a800c6c043f9579067341 | bc8572c5d088d87e16d73701f59a02e3135c91965012deab1a153bd0eebf3582 | 25 | — |
| Registry enrichment · DataCenters | 1 | get\_value | data\_center\_record\_fixture-0 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:46.731 UTC | f2a1652b184f4903441c185e4f75666250e116ddfc55c9a6b6eb92e1e6b6fb55 | 2463378715bdb8a06123a9dff29e19870852dce08d95c90b7a45ce15a11d81d6 | 80 | — |
| Registry enrichment · DataCenters | 2 | get\_value | data\_center\_record\_fixture-1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:46.731 UTC | 825fd5006a70b5d13fee09bb31eedc65c9592eff95026598ae5eae75a1761222 | 42df72beb94c88c8654c293d38c6fb24216ed0975ec211e7c21238bba1c1f80a | 80 | — |
| Registry enrichment · Role | 1 | get\_value | nns\_subnet\_id | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:47.070 UTC | dcf35c4bec323ea1feb4b58dc22ae37801372bd60be9cf950ca0a27a9f8dff91 | 4cdd267ab9320daa812408894fca044891acc034f7e60a0c6d05104eda09df85 | 47 | — |
| Final Governance verification | 1 | get\_proposal\_info | 990021 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:49.406 UTC | c835c1a463cda20bd8ffd1f841e2e2b4f21fa5b3b3ce5f2e0bc8d1e770b71ead | a4189cad8d1166e7d900f1d8cfba228cf61d627a784c156ba7af265c19bee4b5 | 430 | — |
| Final Governance verification | 2 | get\_proposal\_info | 990022 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:49.406 UTC | a7b9e3e8a8f44305d1a2e6b00648fd6cf79aa59512cb7aba4cadae8011ea4a24 | f1f82bdd1dd9462f4b1bb2946955669565c527eeb3f70284a1c3a1c277dc4fd8 | 425 | — |

</details>

<details>
<summary>Accepted Governance discovery source receipts (4)</summary>

| ID | Method | Item | Canister | Observed at | Argument SHA-256 | Reply SHA-256 | Bytes | Rejection |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | get\_proposal\_info | 990021 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:49.748 UTC | c835c1a463cda20bd8ffd1f841e2e2b4f21fa5b3b3ce5f2e0bc8d1e770b71ead | a4189cad8d1166e7d900f1d8cfba228cf61d627a784c156ba7af265c19bee4b5 | 430 | — |
| 2 | get\_proposal\_info | 990022 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:49.748 UTC | a7b9e3e8a8f44305d1a2e6b00648fd6cf79aa59512cb7aba4cadae8011ea4a24 | f1f82bdd1dd9462f4b1bb2946955669565c527eeb3f70284a1c3a1c277dc4fd8 | 425 | — |
| 3 | list\_proposals | Open and adopted before None | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:49.748 UTC | 8178e19650c447132e0ca1b72f81e65df3e5200f15038b56141093b9a7e553eb | 72fe21aea0667967bc51edd827e79a4cdeff7387d0143bc39681aaf50090dd43 | 593 | — |
| 4 | list\_proposals | Open and adopted before Some(990021) | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:49.748 UTC | 2e1b281f4fc2de4dafd5c8db93c816a2a16ac1337bc9d775290647eac9a801a8 | 315ddac773cf085376eb7fb2660f5489551871d3a43812fcddc924e7cd82bee5 | 278 | — |

</details>
