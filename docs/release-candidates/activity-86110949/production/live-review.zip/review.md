# Proposal review · [#145077](https://dashboard.internetcomputer.org/proposal/145077)

Proposal #145077 · After proposal #145077 · Step 1 of 1

Subnet [5kdm2-62fc6-fwnja-hutkz-ycsnm-4z33i-woh43-4cenu-ev7mi-gii6t-4ae](https://dashboard.internetcomputer.org/network/subnets/5kdm2-62fc6-fwnja-hutkz-ycsnm-4z33i-woh43-4cenu-ev7mi-gii6t-4ae)

## Summary

Replace one node at dl1 with one at ge2. The subnet remains at 13 nodes. dl1 loses its last subnet member. ge2 membership changes 0 → 1.

13 members · Add 1 · Remove 1 · Unchanged 12

Target subnet checked; assignments in the other 97 listed subnets were not checked.

## Evidence scope

Pinned Registry version **66,271**. Governance checked after the selected comparisons.

- #145077 · Open observed 2026-11-28 10:53:07.853 UTC

- Proposed membership is conditional on the pinned evidence. Full execution validity remains unverified.

## Review checks

Conservative availability model. The fault budget is floor((N − 1) / 3). Model departing nodes unavailable in the before-state and incoming nodes still synchronizing in the proposed state. The smaller margin applies. A margin below one triggers a warning. The cumulative case keeps all earlier arrivals unavailable while they remain in the subnet. These conditional margins do not establish global assignment, execution validity or actual liveness.

### Step 1 · Proposal #145077

Add and Remove are disjoint · Add duplicates 0 · Remove duplicates 0 · Membership preconditions · Incoming assignments could not be established across the Registry roster

Conditional step margin · 3 additional faults tolerable · 4 would exceed the modeled budget

<details>
<summary>Instruction and margin arithmetic</summary>

- Duplicate Add principals · none
- Duplicate Remove principals · none
- Overlapping principals · none
- Individual step · 5kdm2-62fc6-fwnja-hutkz-ycsnm-4z33i-woh43-4cenu-ev7mi-gii6t-4ae · Before · 13 members, budget 4, modeled unavailable 1, remaining 3 · Proposed · 13 members, budget 4, modeled unavailable 1, remaining 3 · Limiting side: both states · Margin 3

</details>

Governance check incomplete · 0 references found

- Sources rrkah-fqaaa-aaaaa-aaaaq-cai, rwlgt-iiaaa-aaaaa-aaaaa-cai · 21 admitted reads

- Discovery observed 2026-11-28 10:50:36.225 UTC to 2026-11-28 10:51:46.538 UTC

- Pagination complete · 6 pages · oldest listed #340 · Open 29 · Adopted awaiting execution 21

- Title, summary and supported motion text checked for 50 proposals · Supported actions decoded 23 · Hydrated 0 · Lifecycle changed 0

- Unsupported actions 27 · Missing payloads 0 · Malformed payloads 0 · Omitted findings 0

- Findings restricted to accepted instructions for #145077 · Reused network-wide discovery.

## Map

![Map of registered node locations for the selected comparison](map.png)

Add (green) · Remove (red) · Unchanged (blue). 14 unique nodes across both states · 14/14 located. Positions use the registered data-center coordinates. The dotted halo indicates multiple node identities at the same coordinates.

Natural Earth map-unit boundaries are cartographic. Country shading uses recorded membership groups. Green shows increases and red shows decreases. A dashed border marks a country falling to zero. Small squares mark represented map units too small to see at the current zoom.

Changed sites · dl1 · 1 → 0 nodes · ge2 · 0 → 1 nodes

## Node changes

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
| Remove | [haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe](https://dashboard.internetcomputer.org/network/nodes/haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe) | [dl1](https://dashboard.internetcomputer.org/network/centers/dl1) | Flexential | [eipr5-izbom-neyqh-s3ec2-52eww-cyfpg-qfomg-3dpwj-4pffh-34xcu-7qe](https://dashboard.internetcomputer.org/network/provider/eipr5-izbom-neyqh-s3ec2-52eww-cyfpg-qfomg-3dpwj-4pffh-34xcu-7qe) | mw64v-jynex-7tu52-5a3te-ifbop-nh7y7-w7lno-ymmht-b7fmy-wfhha-gqe | 🇺🇸 United States (US) |
| Add | [ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae](https://dashboard.internetcomputer.org/network/nodes/ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae) | [ge2](https://dashboard.internetcomputer.org/network/centers/ge2) | SafeHost | [7ryes-jnj73-bsyu4-lo6h7-lbxk5-x4ien-lylws-5qwzl-hxd5f-xjh3w-mqe](https://dashboard.internetcomputer.org/network/provider/7ryes-jnj73-bsyu4-lo6h7-lbxk5-x4ien-lylws-5qwzl-hxd5f-xjh3w-mqe) | 5atxd-q4jom-dtpxr-awd3p-e562x-hpavj-godtj-g6vmz-of2c6-ildhh-fae | 🇨🇭 Switzerland (CH) |

<details>
<summary>Other Nodes (12)</summary>

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
|  | [ayf37-rq2hn-jiuvy-c2i3m-3kft2-v3jbe-c6mzo-f6yjy-sv52k-poii6-5ae](https://dashboard.internetcomputer.org/network/nodes/ayf37-rq2hn-jiuvy-c2i3m-3kft2-v3jbe-c6mzo-f6yjy-sv52k-poii6-5ae) | [sg3](https://dashboard.internetcomputer.org/network/centers/sg3) | Racks Central | [x7uok-pi537-itm37-unjn3-ewkze-kuetg-kptap-nuqak-auq7z-tn5ey-dqe](https://dashboard.internetcomputer.org/network/provider/x7uok-pi537-itm37-unjn3-ewkze-kuetg-kptap-nuqak-auq7z-tn5ey-dqe) | vicvb-nkzkt-tj2lz-yzzw4-gfcsj-3eggv-izdti-tarpt-fsojm-lgq22-wae | 🇸🇬 Singapore (SG) |
|  | [nusc3-gza5p-4iw7a-ea7xu-b6afg-r4sd3-saik7-io6zs-c36mg-q47ut-qae](https://dashboard.internetcomputer.org/network/nodes/nusc3-gza5p-4iw7a-ea7xu-b6afg-r4sd3-saik7-io6zs-c36mg-q47ut-qae) | [sj3](https://dashboard.internetcomputer.org/network/centers/sj3) | InfoObjects | [7ws2n-wqorv-vmo4m-5e222-n42c3-hk43s-ei3kp-4hpbn-xlkzo-jgv7i-tqe](https://dashboard.internetcomputer.org/network/provider/7ws2n-wqorv-vmo4m-5e222-n42c3-hk43s-ei3kp-4hpbn-xlkzo-jgv7i-tqe) | jtrpk-wokqg-aqmcn-esiq7-fip4e-dl7lv-iwdyj-cu5pm-wbg7i-4jl4t-wae | 🇺🇸 United States (US) |
|  | [zgeaf-fcq4e-fcnht-g7mpg-sb7ff-r6awk-zvkwp-gkloc-rr6jl-ghsse-mqe](https://dashboard.internetcomputer.org/network/nodes/zgeaf-fcq4e-fcnht-g7mpg-sb7ff-r6awk-zvkwp-gkloc-rr6jl-ghsse-mqe) | [ta2](https://dashboard.internetcomputer.org/network/centers/ta2) | Telia DC | [diyay-s4rfq-xnx23-zczwi-nptra-5254n-e4zn6-p7tqe-vqhzr-sd4gd-bqe](https://dashboard.internetcomputer.org/network/provider/diyay-s4rfq-xnx23-zczwi-nptra-5254n-e4zn6-p7tqe-vqhzr-sd4gd-bqe) | rhtt6-acsjc-c73k7-mnd7w-5253w-h35fr-lfknt-as6bb-rgxoy-xe4zr-dae | 🇪🇪 Estonia (EE) |
|  | [uouxk-c246i-dgxzd-ql3a5-koofn-mclrv-toplo-bg76d-l4dzk-ngb3c-nae](https://dashboard.internetcomputer.org/network/nodes/uouxk-c246i-dgxzd-ql3a5-koofn-mclrv-toplo-bg76d-l4dzk-ngb3c-nae) | [tb1](https://dashboard.internetcomputer.org/network/centers/tb1) | Cloud9 | [vegae-c4chr-aetfj-7gzuh-c23sx-u2paz-vmvbn-bcage-pu7lu-mptnn-eqe](https://dashboard.internetcomputer.org/network/provider/vegae-c4chr-aetfj-7gzuh-c23sx-u2paz-vmvbn-bcage-pu7lu-mptnn-eqe) | yhfy4-ny5ww-huz33-bkxym-eu27d-htlt4-yi77a-hvdqb-wpdlv-2cky7-uae | 🇬🇪 Georgia (GE) |
|  | [62yzt-726hf-rwk73-c3j6k-fjdls-7oqh5-exbnn-bvrsn-2soat-m4vg3-7ae](https://dashboard.internetcomputer.org/network/nodes/62yzt-726hf-rwk73-c3j6k-fjdls-7oqh5-exbnn-bvrsn-2soat-m4vg3-7ae) | [to2](https://dashboard.internetcomputer.org/network/centers/to2) | Cyxtera | [7at4h-nhtvt-a4s55-jigss-wr2ha-ysxkn-e6w7x-7ggnm-qd3d5-ry66r-cae](https://dashboard.internetcomputer.org/network/provider/7at4h-nhtvt-a4s55-jigss-wr2ha-ysxkn-e6w7x-7ggnm-qd3d5-ry66r-cae) | 4lp6i-khv7q-lkgk3-hhrc6-ysjag-korh7-ysojw-7gv3h-glhdz-rpjrt-sqe | 🇨🇦 Canada (CA) |
|  | [tu7cd-aljf3-56j73-xdusu-fyjps-sgkoi-5w3fx-p3vvd-tusca-w2vyl-bqe](https://dashboard.internetcomputer.org/network/nodes/tu7cd-aljf3-56j73-xdusu-fyjps-sgkoi-5w3fx-p3vvd-tusca-w2vyl-bqe) | [mn2](https://dashboard.internetcomputer.org/network/centers/mn2) | NEXTDC | [ihbuj-erwnc-tkjux-tqtnv-zkoar-uniy2-sk2go-xfpkc-znbb4-seukm-wqe](https://dashboard.internetcomputer.org/network/provider/ihbuj-erwnc-tkjux-tqtnv-zkoar-uniy2-sk2go-xfpkc-znbb4-seukm-wqe) | l5lhp-734i5-tbott-vipvc-vud2f-pfh7r-g3227-tgkdj-4rggm-abc2e-cae | 🇦🇺 Australia (AU) |
|  | [oswv7-a355p-a5jlp-ko7pj-arrs2-rghho-dti4z-xgptn-szn55-jjr46-uqe](https://dashboard.internetcomputer.org/network/nodes/oswv7-a355p-a5jlp-ko7pj-arrs2-rghho-dti4z-xgptn-szn55-jjr46-uqe) | [ty3](https://dashboard.internetcomputer.org/network/centers/ty3) | Equinix | [sixix-2nyqd-t2k2v-vlsyz-dssko-ls4hl-hyij4-y7mdp-ja6cj-nsmpf-yae](https://dashboard.internetcomputer.org/network/provider/sixix-2nyqd-t2k2v-vlsyz-dssko-ls4hl-hyij4-y7mdp-ja6cj-nsmpf-yae) | a5glg-n6ul6-rkuc7-idthk-fb2fe-d5m75-4g4l7-22yko-h27pr-q3a7k-lae | 🇯🇵 Japan (JP) |
|  | [ihoip-fmbnl-mm4fa-pu7hu-2sbx2-mzl2f-tgzje-unnjg-bgcac-3apmo-gqe](https://dashboard.internetcomputer.org/network/nodes/ihoip-fmbnl-mm4fa-pu7hu-2sbx2-mzl2f-tgzje-unnjg-bgcac-3apmo-gqe) | [sg1](https://dashboard.internetcomputer.org/network/centers/sg1) | Telin | [6nbcy-kprg6-ax3db-kh3cz-7jllk-oceyh-jznhs-riguq-fvk6z-6tsds-rqe](https://dashboard.internetcomputer.org/network/provider/6nbcy-kprg6-ax3db-kh3cz-7jllk-oceyh-jznhs-riguq-fvk6z-6tsds-rqe) | d4bin-5o2wg-ycbdq-yljr7-45pjv-ptf6d-v243j-vg6x5-dlo7t-yqu62-5qe | 🇸🇬 Singapore (SG) |
|  | [zos66-lmcn7-satbv-gcdzj-q3cdf-4n6zc-2hlei-gc453-uoh7r-4sj3w-vqe](https://dashboard.internetcomputer.org/network/nodes/zos66-lmcn7-satbv-gcdzj-q3cdf-4n6zc-2hlei-gc453-uoh7r-4sj3w-vqe) | [sh1](https://dashboard.internetcomputer.org/network/centers/sh1) | Digital Realty | [bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe](https://dashboard.internetcomputer.org/network/provider/bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe) | lgp6d-brhlv-35izu-khc6p-rfszo-zdwng-xbtkh-xyvjg-y3due-7ha7t-uae | 🇸🇪 Sweden (SE) |
|  | [fbypf-pftue-r2nbt-pueee-s454b-ycsuw-pjqqn-h3rh4-vlfpo-tokd5-mae](https://dashboard.internetcomputer.org/network/nodes/fbypf-pftue-r2nbt-pueee-s454b-ycsuw-pjqqn-h3rh4-vlfpo-tokd5-mae) | [pl2](https://dashboard.internetcomputer.org/network/centers/pl2) | Yotta | [zy4m7-z5mhs-zfkpl-zlsjl-blrbx-mvvmq-5z4zu-mf7eq-hhv7o-ezfro-3ae](https://dashboard.internetcomputer.org/network/provider/zy4m7-z5mhs-zfkpl-zlsjl-blrbx-mvvmq-5z4zu-mf7eq-hhv7o-ezfro-3ae) | 7rw6b-6r7qv-al3uk-rimg7-ifkjv-hettz-lhmly-t55g7-xrwac-25ayy-wae | 🇮🇳 India (IN) |
|  | [ocvcv-56eg5-gxibh-dcgpo-unhwq-4bwmo-x7q3h-stwf2-ycfex-gdr2a-kae](https://dashboard.internetcomputer.org/network/nodes/ocvcv-56eg5-gxibh-dcgpo-unhwq-4bwmo-x7q3h-stwf2-ycfex-gdr2a-kae) | [jb2](https://dashboard.internetcomputer.org/network/centers/jb2) | Africa Data Centres | [nmdd6-rouxw-55leh-wcbkn-kejit-njvje-p4s6e-v64d3-nlbjb-vipul-mae](https://dashboard.internetcomputer.org/network/provider/nmdd6-rouxw-55leh-wcbkn-kejit-njvje-p4s6e-v64d3-nlbjb-vipul-mae) | 3bohy-zygmq-6novb-wm65r-3k3y2-deh42-7emld-zhqo7-xl2oa-iextm-fae | 🇿🇦 South Africa (ZA) |
|  | [wq5v7-ngito-7ztqs-zlf2v-ibk6f-e54em-t3hou-x24kz-v5j77-6vo72-kqe](https://dashboard.internetcomputer.org/network/nodes/wq5v7-ngito-7ztqs-zlf2v-ibk6f-e54em-t3hou-x24kz-v5j77-6vo72-kqe) | [lj1](https://dashboard.internetcomputer.org/network/centers/lj1) | Posita.si | [wdjjk-blh44-lxm74-ojj43-rvgf4-j5rie-nm6xs-xvnuv-j3ptn-25t4v-6ae](https://dashboard.internetcomputer.org/network/provider/wdjjk-blh44-lxm74-ojj43-rvgf4-j5rie-nm6xs-xvnuv-j3ptn-25t4v-6ae) | gl27f-y5srq-yy5ot-v4x5z-y2a2s-sgoor-l4gjg-qv4x4-v2olb-dz4dc-wae | 🇸🇮 Slovenia (SI) |

</details>

## Decentralisation

Arrows show before → proposed; a single value is unchanged.

### Different groups represented

How many different registered groups have at least one member in this subnet?

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 5 | 11 → 12 | 13 | 13 | 13 | 13 |

### Largest group size

The most subnet nodes sharing one value, such as one provider or one country label. Several groups may tie.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 5 | 2 | 1 | 1 | 1 | 1 |

### Nakamoto coefficients

How many of the largest registered groups together contain more than one-third of the subnet's nodes? Each state uses floor(N / 3) + 1. Recorded groups do not establish independent ownership, subnet safety, execution validity or Target Topology compliance.

Node threshold: 5.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 1 | 3 → 4 | 5 | 5 | 5 | 5 |

### Distances between registered node locations

Straight-line geographic distances calculated from registered data-center coordinates, counting each pair of nodes once. These are not measured network latency or health.

| Shortest | Average | Longest |
| --- | --- | --- |
| 14.0 km | 8,913.3 km → 8,397.9 km | 16,948.9 km |

78 of 78 pairs before and proposed.

No current Target Topology thresholds, exceptions or applicability are assumed.

<details>
<summary>Recorded country membership</summary>

| Country (recorded token) | Subnet members |
| --- | --- |
| 🇦🇺 Australia (AU) | 1 |
| 🇨🇦 Canada (CA) | 1 |
| 🇨🇭 Switzerland (CH) | 0 → 1 |
| 🇪🇪 Estonia (EE) | 1 |
| 🇬🇪 Georgia (GE) | 1 |
| 🇮🇳 India (IN) | 1 |
| 🇯🇵 Japan (JP) | 1 |
| 🇸🇪 Sweden (SE) | 1 |
| 🇸🇬 Singapore (SG) | 2 |
| 🇸🇮 Slovenia (SI) | 1 |
| 🇺🇸 United States (US) | 2 → 1 |
| 🇿🇦 South Africa (ZA) | 1 |

</details>

## Sources and calculation

Membership preview revision `02225bfb0d7a93538e64b61a290b474ce93b4ac441a06ff75802256074296b63`.

Calculation input SHA-256 `b94e6112f0b6c3db1c4b57465a072c58b7802a0535e21688453fe4728b09cbb3` · analysis v5.

The replicated calculation digest identifies the exact submitted evidence and scope. Source receipts identify the separate Registry and Governance observations.

- #145077 executable payload SHA-256 7b30eb7aa652f5192d7b07e28912caf75289a5d16c87c7bfe16037ea86b69050

<details>
<summary>Exact distance evidence in metres</summary>

| Distance | Before | Proposed |
| --- | --- | --- |
| Shortest | 13952 | 13952 |
| Average | 8913267 | 8397901 |
| Longest | 16948908 | 16948908 |

</details>

<details>
<summary>Registered geography evidence</summary>

| Data center | Original Registry region | Country token |
| --- | --- | --- |
| [dl1](https://dashboard.internetcomputer.org/network/centers/dl1) | North America,US,Texas | US |
| [ge2](https://dashboard.internetcomputer.org/network/centers/ge2) | Europe,CH,Geneva | CH |
| [sg3](https://dashboard.internetcomputer.org/network/centers/sg3) | Asia,SG,Singapore | SG |
| [sj3](https://dashboard.internetcomputer.org/network/centers/sj3) | North America,US,California | US |
| [ta2](https://dashboard.internetcomputer.org/network/centers/ta2) | Europe,EE,Tallinn | EE |
| [tb1](https://dashboard.internetcomputer.org/network/centers/tb1) | Asia,GE,Tbilisi | GE |
| [to2](https://dashboard.internetcomputer.org/network/centers/to2) | North America,CA,Ontario | CA |
| [mn2](https://dashboard.internetcomputer.org/network/centers/mn2) | Oceania,AU,Melbourne | AU |
| [ty3](https://dashboard.internetcomputer.org/network/centers/ty3) | Asia,JP,Tokyo | JP |
| [sg1](https://dashboard.internetcomputer.org/network/centers/sg1) | Asia,SG,Singapore | SG |
| [sh1](https://dashboard.internetcomputer.org/network/centers/sh1) | Europe,SE,Stockholm | SE |
| [pl2](https://dashboard.internetcomputer.org/network/centers/pl2) | Asia,IN,Panvel | IN |
| [jb2](https://dashboard.internetcomputer.org/network/centers/jb2) | Africa,ZA,Gauteng | ZA |
| [lj1](https://dashboard.internetcomputer.org/network/centers/lj1) | Europe,SI,Ljubljana | SI |

</details>

<details>
<summary>Membership and Registry source receipts (53)</summary>

| Evidence stage | ID | Method | Item | Canister | Observed at | Argument SHA-256 | Reply SHA-256 | Bytes | Rejection |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Membership preview · Governance | 1 | get\_proposal\_info | 145077 | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:52:19.358 UTC | c176c9ea5ce96ebcd18f9074f6ddd8cf31e58dfcf488925f9f0e1ffd70150bab | d1a27ec58bbe265e075d947b3a9f15ea7501f1a64a5ca96a67d4eec467dcc778 | 7405 | — |
| Membership preview · Registry | 2 | get\_latest\_version | Registry head | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:21.980 UTC | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | 256e00f2bc1bf7f52469666a4ebbe0194825fd8f3c8d8efbc1311da2984ff438 | 4 | — |
| Membership preview · Registry | 3 | get\_value | subnet\_list | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:24.180 UTC | 1caf90b8a29ab63c2c9d0bd529d684d2f8031d2eff69231ddaf2aa5ff9e14822 | e700ca41381ba571f790b439875b923b4845fc269cfdb27ba1cb7dff6643f2b1 | 3055 | — |
| Membership preview · Registry | 4 | get\_value | subnet\_record\_5kdm2-62fc6-fwnja-hutkz-ycsnm-4z33i-woh43-4cenu-ev7mi-gii6t-4ae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:26.773 UTC | 6dc116fe705d50da113ad99c12b3015196e9e5b297c7d216a6a3c1b07758ee44 | 8a1f98eaed40644a5df8d19ae788235ceaa51cb51f66269535341c1c1f792041 | 496 | — |
| Membership preview · Registry | 5 | get\_value | node\_record\_haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:29.381 UTC | c0e03f3556c6f65ede582f79a5fb438c19de8ca13c00b8972fdc7a1ccc73be28 | 3bf2975c0c1ed7a5f53c39e99b09dd2cc9ff510b5fd655274929c97cf667da0c | 245 | — |
| Membership preview · Registry | 6 | get\_value | node\_record\_ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:29.381 UTC | b2c38f7b1ed1a9bd5bab64727aa25393e4df3cdfd49c58f9858e8469e5209c1e | dc31d0aa28b9dac3dad08d0187c25cee04a5710d9c3750ee6ac11a5b9d0e44cb | 231 | — |
| Membership preview · Registry | 7 | get\_value | api\_boundary\_node\_haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:32.912 UTC | 53d4e00b1aeef3d88a6515a0ac6e861cfa2ce56afe4c80426cfc17a8519ba6b6 | f159c97ddb388b6642dc649bba1a0a27ba298976e2d19d4fe2259d8f0ffd469e | 91 | — |
| Membership preview · Registry | 8 | get\_value | api\_boundary\_node\_ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:32.912 UTC | 80ea7997f6a31fe6c903aa369bf21d6a9c8df0683b88c3bdb44a829544b56250 | 85232bd7d85929f4ad59310de70f498f6e0d509b11fee4c9572c7f8027fa47ef | 91 | — |
| Membership preview · Governance | 9 | get\_proposal\_info | 145077 | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:52:35.512 UTC | c176c9ea5ce96ebcd18f9074f6ddd8cf31e58dfcf488925f9f0e1ffd70150bab | cd135504ba35522517e39ce236e360c2266427e9676552591a1e6cc0c52a1478 | 7405 | — |
| Registry enrichment · Nodes | 1 | get\_value | node\_record\_ayf37-rq2hn-jiuvy-c2i3m-3kft2-v3jbe-c6mzo-f6yjy-sv52k-poii6-5ae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:39.920 UTC | 4b564dcfc06f39819bfbc552de2ffd0d9c367751ea0a7c415015612ba5c99428 | 7a13411b346fbf7431ba58a949c4d9e83fa4eec53c20b7ec405dbba17bb3b27e | 180 | — |
| Registry enrichment · Nodes | 2 | get\_value | node\_record\_nusc3-gza5p-4iw7a-ea7xu-b6afg-r4sd3-saik7-io6zs-c36mg-q47ut-qae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:39.920 UTC | a92ce200ba8e0b7628d280dc8b2e10d983a466826d73c462cf816d52f16986e3 | ec6c88916e796d48b35e45989d5fb4cb6c637d23a4cf39975551b359d082f0cb | 178 | — |
| Registry enrichment · Nodes | 3 | get\_value | node\_record\_fbypf-pftue-r2nbt-pueee-s454b-ycsuw-pjqqn-h3rh4-vlfpo-tokd5-mae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:39.920 UTC | 436e94f1006ae2ed6dd4b5aad108918a5c03f075ce90de7539a08be40815455a | 63164ab676a82f040f5d341061ae5fe7b66cf55c3a8b582482be8c99bd1ab720 | 180 | — |
| Registry enrichment · Nodes | 4 | get\_value | node\_record\_zgeaf-fcq4e-fcnht-g7mpg-sb7ff-r6awk-zvkwp-gkloc-rr6jl-ghsse-mqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:39.920 UTC | 4edd3664021727ce3efc29640bf2bc20b61b3a2ddc3ea3a298d87c44bfe38321 | 0f87f853f0b6989f3d82fd17f21e9ec935c495f7c7a006a515c22b462f2446fb | 174 | — |
| Registry enrichment · Nodes | 5 | get\_value | node\_record\_uouxk-c246i-dgxzd-ql3a5-koofn-mclrv-toplo-bg76d-l4dzk-ngb3c-nae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:39.920 UTC | edb0f6ee00eadf26c2ccf92ac672aba085430ef764c62655a96713ee4b04bdb0 | a78445b3111f3a31af22c1c1d6171f15b0bdab6189ee629d1ee1d18b64387a9d | 174 | — |
| Registry enrichment · Nodes | 6 | get\_value | node\_record\_haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:39.920 UTC | c0e03f3556c6f65ede582f79a5fb438c19de8ca13c00b8972fdc7a1ccc73be28 | 3bf2975c0c1ed7a5f53c39e99b09dd2cc9ff510b5fd655274929c97cf667da0c | 245 | — |
| Registry enrichment · Nodes | 7 | get\_value | node\_record\_tu7cd-aljf3-56j73-xdusu-fyjps-sgkoi-5w3fx-p3vvd-tusca-w2vyl-bqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:39.920 UTC | 4620956946c22af9436c01deb2d2cc6e0af41b85542a02e5ce666a0c8628bddd | 0ccf240850bd9de7558835b2cdb22dd87303adda01bbc062bde835078de4d9d6 | 178 | — |
| Registry enrichment · Nodes | 8 | get\_value | node\_record\_62yzt-726hf-rwk73-c3j6k-fjdls-7oqh5-exbnn-bvrsn-2soat-m4vg3-7ae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:39.920 UTC | c50d7d50b238c030c7f1980ab69485ccb3a2e3319d27f3f5ac2f2161839c283d | a98c3bd41ca7a3d61b39d2e16efe7ee5f42ff8a841040cfb0bbda4273523a886 | 251 | — |
| Registry enrichment · Nodes | 9 | get\_value | node\_record\_ihoip-fmbnl-mm4fa-pu7hu-2sbx2-mzl2f-tgzje-unnjg-bgcac-3apmo-gqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:42.592 UTC | 6835f5896655f5a14a1ca25f2ad2dae45084c743d296a52e12a29ff3fff32e8b | 56cf7d3554c76967daebe23ece33b9c424264380cbcbbf6ec4720b389b02b4f6 | 180 | — |
| Registry enrichment · Nodes | 10 | get\_value | node\_record\_ocvcv-56eg5-gxibh-dcgpo-unhwq-4bwmo-x7q3h-stwf2-ycfex-gdr2a-kae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:42.592 UTC | 44e47f1be3025adc775421adad56f776e86467aefaaecb904587494c855b82f3 | 6c33d7067c02f8b870a942929a7ff126188df8af9fa93b40c9fe702ba843f456 | 180 | — |
| Registry enrichment · Nodes | 11 | get\_value | node\_record\_zos66-lmcn7-satbv-gcdzj-q3cdf-4n6zc-2hlei-gc453-uoh7r-4sj3w-vqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:42.592 UTC | 0e70aabae4c237c2f64f977cc2db4ecc1d69f86adbacb55e993e525a189897f3 | b03c333111717ee2c97018d2691fa903ea88cce162c369f5accf5aa0f5973362 | 184 | — |
| Registry enrichment · Nodes | 12 | get\_value | node\_record\_oswv7-a355p-a5jlp-ko7pj-arrs2-rghho-dti4z-xgptn-szn55-jjr46-uqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:42.592 UTC | 204c59672c72de29a4db540b9d09f27f9d70cb988409887057b0b47d7e958b53 | 2f244d753babdb191829ffd675f867582a4acc63f063400e533bcbeb271988a7 | 180 | — |
| Registry enrichment · Nodes | 13 | get\_value | node\_record\_wq5v7-ngito-7ztqs-zlf2v-ibk6f-e54em-t3hou-x24kz-v5j77-6vo72-kqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:42.592 UTC | d2dd623a39c682f61a4ce1c6e908876c4f2819c502229e48104f5d5640bd02f1 | 66df3f5ec6a63b1ac5f6fbc7ef924f12a9b9d2e7d6efe275b97a9f4cff57e65a | 178 | — |
| Registry enrichment · Nodes | 14 | get\_value | node\_record\_ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:42.592 UTC | b2c38f7b1ed1a9bd5bab64727aa25393e4df3cdfd49c58f9858e8469e5209c1e | dc31d0aa28b9dac3dad08d0187c25cee04a5710d9c3750ee6ac11a5b9d0e44cb | 231 | — |
| Registry enrichment · Operators | 1 | get\_value | node\_operator\_record\_vicvb-nkzkt-tj2lz-yzzw4-gfcsj-3eggv-izdti-tarpt-fsojm-lgq22-wae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:47.095 UTC | f51d984f6a6d55601a680665c0508920d1ec3d1dcd5aad58f4e89e5e8cfc8fd5 | 74524f4e0d2dfeb212e54508286e6ba4655c127fb7df49e27ec65e3b94a430df | 109 | — |
| Registry enrichment · Operators | 2 | get\_value | node\_operator\_record\_jtrpk-wokqg-aqmcn-esiq7-fip4e-dl7lv-iwdyj-cu5pm-wbg7i-4jl4t-wae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:47.095 UTC | d44c1443c22a8c7877cd53849357810a39db4a1a25d6e128072610c54ebe6c0c | 062f7237a6310b21827142faa3d7003ae741febab3f65467e676bec3944e1d38 | 111 | — |
| Registry enrichment · Operators | 3 | get\_value | node\_operator\_record\_7rw6b-6r7qv-al3uk-rimg7-ifkjv-hettz-lhmly-t55g7-xrwac-25ayy-wae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:47.095 UTC | 5df0174e35d3561a6f729223628b0bf812c186de37f1c185fed557a4d28f74bb | c3be55698ca63e14b767c582e6e52ca7d62e43a2839332ec503ae7aa9217b0dc | 111 | — |
| Registry enrichment · Operators | 4 | get\_value | node\_operator\_record\_rhtt6-acsjc-c73k7-mnd7w-5253w-h35fr-lfknt-as6bb-rgxoy-xe4zr-dae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:47.095 UTC | 5c78e143119d6d28bf9cc21bf005d03c847c45f9681a02ab85c83f2bb72b0665 | 7a60333ead9adb13ce3cb37fea51b9faeaf199d60fce0752ec695acad9fa5425 | 109 | — |
| Registry enrichment · Operators | 5 | get\_value | node\_operator\_record\_yhfy4-ny5ww-huz33-bkxym-eu27d-htlt4-yi77a-hvdqb-wpdlv-2cky7-uae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:47.095 UTC | 77e11ace924e21abf39d7ceb3681d8f2bb7eb5fbdfd2839aa680eafae8d5207d | 150593eea924e0fa1c830473c60497b28d7ca2f1773bba29b5350370ad55a552 | 111 | — |
| Registry enrichment · Operators | 6 | get\_value | node\_operator\_record\_mw64v-jynex-7tu52-5a3te-ifbop-nh7y7-w7lno-ymmht-b7fmy-wfhha-gqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:47.095 UTC | 1bec91d8a7ef1d10fbdaf9400ba50ebe4885f8a020744fbed67d0b229ed56aa2 | 9e807809b50c46f444d850166529b66e5d0d22c627909bae03e84e0cf4465284 | 111 | — |
| Registry enrichment · Operators | 7 | get\_value | node\_operator\_record\_l5lhp-734i5-tbott-vipvc-vud2f-pfh7r-g3227-tgkdj-4rggm-abc2e-cae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:47.095 UTC | 5e5bc347ddd5a1429f6e951b8cec389aaa156a0b0d711e6f4187ad588a8a6f25 | 870a6d6179dd65e901e02a2c2f7c67aba57d6f4e5a458a8c5078ad5998331f5e | 111 | — |
| Registry enrichment · Operators | 8 | get\_value | node\_operator\_record\_4lp6i-khv7q-lkgk3-hhrc6-ysjag-korh7-ysojw-7gv3h-glhdz-rpjrt-sqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:47.095 UTC | 4b81c4c392b8b9114703b2bcf68245a8e70a6086de0bd61634924335613d9ef0 | 1c6bda60eae8cdff26d68fd39a03abc7a4a3d5a693b95fb47240be9e38353c81 | 111 | — |
| Registry enrichment · Operators | 9 | get\_value | node\_operator\_record\_d4bin-5o2wg-ycbdq-yljr7-45pjv-ptf6d-v243j-vg6x5-dlo7t-yqu62-5qe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:49.698 UTC | 705d6cafe4c17068acc13c34b987edcc34b14bc0996499425b83669095922b14 | 605f0773da9d12d3a9428068393a1a7c258702ca68243fe5bdee8db153e02aaa | 111 | — |
| Registry enrichment · Operators | 10 | get\_value | node\_operator\_record\_3bohy-zygmq-6novb-wm65r-3k3y2-deh42-7emld-zhqo7-xl2oa-iextm-fae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:49.698 UTC | 95742a5b28c2da88b2ad0569b5a781ff638f8f979c3c9e986b021a7d59e2fbcb | 55f1550a690609159b3bdbc1d34f5c1a122b5c43252024d19d08f8f461ff4185 | 111 | — |
| Registry enrichment · Operators | 11 | get\_value | node\_operator\_record\_lgp6d-brhlv-35izu-khc6p-rfszo-zdwng-xbtkh-xyvjg-y3due-7ha7t-uae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:49.698 UTC | c51244dd449c3a90e10380448c04c73fc4f73402cc4ebd15cfe8ca22720084f4 | 8b2fbe78cc4b1377882bb74555264106dd4c5970f199b579868fc3e5a41245fc | 111 | — |
| Registry enrichment · Operators | 12 | get\_value | node\_operator\_record\_a5glg-n6ul6-rkuc7-idthk-fb2fe-d5m75-4g4l7-22yko-h27pr-q3a7k-lae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:49.698 UTC | 7071cacc8bbe88e870f1578122d16b5505e213fca19140fe23b7681e74263608 | ca3dc094aa5bf974475b42b231448e3809b20828259d66d6528e1dd3c05ca456 | 111 | — |
| Registry enrichment · Operators | 13 | get\_value | node\_operator\_record\_gl27f-y5srq-yy5ot-v4x5z-y2a2s-sgoor-l4gjg-qv4x4-v2olb-dz4dc-wae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:49.698 UTC | ff49e2911b22c44d92643cdf53ad941ea46594999d424db998f2d4efd1ba873a | 1fa4d72537af8fbd1798916221dde161175a7fad9a85f05b40e303dc74d705c1 | 111 | — |
| Registry enrichment · Operators | 14 | get\_value | node\_operator\_record\_5atxd-q4jom-dtpxr-awd3p-e562x-hpavj-godtj-g6vmz-of2c6-ildhh-fae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:49.698 UTC | 3b58a1e6604e7415368e3c5ef523f46ca592419f37299ce0f53949ed73d38034 | 1388360b56112f1080e9e265c5876cad17e78f9dfb72f6bdaa76175bd01542aa | 111 | — |
| Registry enrichment · DataCenters | 1 | get\_value | data\_center\_record\_sg3 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:53.715 UTC | d135eaf854d32d1c7a5b411cfd236fdc2ff101f9e38abb4654447929bc8446f1 | 90929f77df0b87158be9d169b7a4530d3702cdbcf5a548deaf9d1c9a98d34e66 | 57 | — |
| Registry enrichment · DataCenters | 2 | get\_value | data\_center\_record\_sj3 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:53.715 UTC | 840ce8c0e4e72f0c0d0a3e3ea410669c7f98c8c8fb13804a8c3c7c67151f58af | 544c70ff00ec165e5dfa5984b2a8948e18198a318a237fc98acd1b278d5b748f | 65 | — |
| Registry enrichment · DataCenters | 3 | get\_value | data\_center\_record\_pl2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:53.715 UTC | cd868f4dc2e6aefee4ba5f3e2b9c570c046f3057e1f0153e41b2890bc64e306a | 7e0739d8f49ab5e841be5444a4bf280c278bf3fc5b6c1a29c3c7178cd235bc97 | 46 | — |
| Registry enrichment · DataCenters | 4 | get\_value | data\_center\_record\_ta2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:53.715 UTC | 6f57b8171f0e04bb53d0547ec4a5195a2ed3782b269cd975fcb14418574321a9 | 657ac5bb67a5a177a95839ecc47da108483804f91d73ab9d15795af35862975a | 52 | — |
| Registry enrichment · DataCenters | 5 | get\_value | data\_center\_record\_tb1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:53.715 UTC | 01c24848e27b58e86b4b7fe42fcf1afa5919e75bf384a8bd28d1746a9184b562 | f0d69ba00d6458422c91d6b4d642fed99468654e2a9eb64f7a231bd3a592958d | 48 | — |
| Registry enrichment · DataCenters | 6 | get\_value | data\_center\_record\_dl1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:53.715 UTC | d9a8deb3dfa420f2ba4e3665a0bb7a6fdda483b30592a8dd4d634b45ad8bd8a7 | 570fa1dfc7c9ae7e05f1781a760e9c465be126482cc23cd77369d86b3b103dfe | 59 | — |
| Registry enrichment · DataCenters | 7 | get\_value | data\_center\_record\_mn2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:53.715 UTC | a9da66eb5afe1edf68f3991cced5758f7daa224033b5271762ecb548f98c6af4 | fcd7ea30f65e5626fc407494a5a67c98a1c9107c39bb4a404d12e002d4751982 | 53 | — |
| Registry enrichment · DataCenters | 8 | get\_value | data\_center\_record\_to2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:53.715 UTC | 87fc8a87107a9199555ae32520437311f65188c6221e3d2692973682b79f12f2 | 7161762007c951239545c9fc2ea667c99df4da49bb96ee366972bceaf74e6741 | 58 | — |
| Registry enrichment · DataCenters | 9 | get\_value | data\_center\_record\_sg1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:55.849 UTC | 9c79399aa9d4313738655ff1dee3b53ce52900ad1adfb2d120f85f4ea28ad709 | 8063f1b111f69a286f34d0ee712ad6a834f57a52f62aab5634039a231095e7c2 | 49 | — |
| Registry enrichment · DataCenters | 10 | get\_value | data\_center\_record\_jb2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:55.849 UTC | 99c107b94c7eee8e92ad694625450df99d8dcbc08896bdff2c4f9bb8e187e843 | c3de5004f3e0bab997fdb6a247ebeebcefdf8185b1d61f52ed5b634cf48f2fa9 | 63 | — |
| Registry enrichment · DataCenters | 11 | get\_value | data\_center\_record\_sh1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:55.849 UTC | b4bbae7c9d7691636ef4220280a8c74f9c0f4575c2eed69cc9137ea84161a036 | 5efaa12dbed1f6f6ec61857abab3f001b8e7c8193e92b72642dbe71707ae36c9 | 60 | — |
| Registry enrichment · DataCenters | 12 | get\_value | data\_center\_record\_ty3 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:55.849 UTC | 27a1d77c2dd132f80d34f31c6b0f73a499abc05a6011db253c72ffa13e8d2672 | 9b914fd2c10cfb81862c10844447af01e280a5af3008521561e21955cbc5c0c3 | 47 | — |
| Registry enrichment · DataCenters | 13 | get\_value | data\_center\_record\_lj1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:55.849 UTC | 8d1999e8039f63948988acb295218c9ad2e0c693b2815ee168f8eb8de18f4fcf | 5f6dae6011b9f61e3f1c0a7710009816800e54292d1ffc313b541ab4b5d6e9db | 55 | — |
| Registry enrichment · DataCenters | 14 | get\_value | data\_center\_record\_ge2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:52:55.849 UTC | ab18d49bb6082b2c05c66979c1fb5d1bb937ec6b2669c0fbc6d44414b69e42b0 | f5fe58753652335ca955fa15826fe946c69cd3d4350511c5d5916827829d0e78 | 51 | — |
| Registry enrichment · Role | 1 | get\_value | nns\_subnet\_id | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:53:00.797 UTC | 96f2ca7fe338be6fe25289bbf87ea5f62bd68e082a4d15906cde3412be29c9e1 | 74ca3bc2b0e0a7a0f6c02c9a4f286cbd1616ef3b3ce2cae7ecf2495d691d6154 | 37 | — |
| Final Governance verification | 1 | get\_proposal\_info | 145077 | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:53:07.853 UTC | c176c9ea5ce96ebcd18f9074f6ddd8cf31e58dfcf488925f9f0e1ffd70150bab | 23cf041daf5c6335787f518ac333c6e78d4d5c36a59bb228662750f6eba0377a | 7405 | — |

</details>

<details>
<summary>Accepted Governance discovery source receipts (21)</summary>

| ID | Method | Item | Canister | Observed at | Argument SHA-256 | Reply SHA-256 | Bytes | Rejection |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | list\_proposals | Open and adopted before None | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:50:38.408 UTC | 8178e19650c447132e0ca1b72f81e65df3e5200f15038b56141093b9a7e553eb | 9680c704e3a406ea18e36e0c98a0b6917981af6f7ededf75b83d559de03be0cb | 40616 | — |
| 2 | list\_proposals | Open and adopted before Some(145072) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:50:41.038 UTC | aa80da650b49c62fbec334b60793fa82bfd49ecf264febd305c8c17a5c17cf00 | 6e8d4362e91ad043c8ebafb608ec3e9b560c02b7cd5737f1438ffd66459003a3 | 54421 | — |
| 3 | list\_proposals | Open and adopted before Some(145062) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:50:44.264 UTC | 9e3a2e6a598604d6c95480bfdb3e4aa3df06549b8324b4439e8603396c0279ae | 10ef06aa8648bc3e3579cf01fd9b3c6e22edb818a834b86983c9264733b3e5f7 | 46297 | — |
| 4 | list\_proposals | Open and adopted before Some(4570) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:50:47.423 UTC | ce0ed7e76562155297b3205ac5c351d60ad2445d43fd7e73f365de492bd36607 | e7526b511990ca317ad44bea6329d58680d3dde017d8244f44a3bd8a8b95ea5a | 8998 | — |
| 5 | list\_proposals | Open and adopted before Some(1520) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:50:50.523 UTC | b6515ac79a94d09698c9b7c9c276a67d6be5a54bc15556fed4af152210e7fa63 | d26de1dc6a3cd89e8a040fac13c7333799593756fa201dcd6368452bb2ed72f5 | 13959 | — |
| 6 | list\_proposals | Open and adopted before Some(340) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:50:52.659 UTC | 6aa61d071a144ad5e73cf212b24645bb51cfdac8308c2ad14b233613dd5953a4 | 3548dbeb53d501d199e613b3427784c8a3f8b9b34ff3cfee6ddd2870c411c693 | 2670 | — |
| 7 | list\_proposals | Accepting votes before None | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:50:55.598 UTC | ae14a60cc74949b43e63aacb3f4f1b94c44904b0e5db97bc77fbab632327c4e8 | 1a9e87c2382a1a87554d9b5643fb0ca0fe845d0ed61ecab1a8fe4834e3d03065 | 40616 | — |
| 8 | list\_proposals | Accepting votes before Some(145072) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:50:59.265 UTC | c1e883688abdd9e98abc5e00c059cdfd9c2a36d35e7855288bd31e99eaa619af | 6e8d4362e91ad043c8ebafb608ec3e9b560c02b7cd5737f1438ffd66459003a3 | 54421 | — |
| 9 | list\_proposals | Accepting votes before Some(145062) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:51:02.166 UTC | c8b50401a057461afe50e0a6c82686d2837c66fe44bb458d242482c76186c6ad | 01c7d0e2528c2af0e13fee44ed75a95b103623483693601cc632ab9bb01e4bd9 | 46430 | — |
| 10 | list\_proposals | Accepting votes before Some(145052) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:51:05.255 UTC | 895f82386f0da491b87fb362283eb8f7bd017b8b03be90b7b2ad81c50f205a81 | e9f76a647a1e079d18870095877db7e1dd33c3df4b8fa51eb8db8eb087dd1e2d | 7849 | — |
| 11 | list\_proposals | Accepting votes before Some(145037) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:51:08.814 UTC | fe8e520ca1497d481a0acdcc44a300eb1c41ad7bc4850261c81ca1377cddfe0e | 70ec9d2b37e0266045edb3ee8f1d60ecfd995ccaa69817c3b574e49511809ca7 | 7849 | — |
| 12 | list\_proposals | Accepting votes before Some(145027) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:51:11.498 UTC | 801bd3c33ea81cc8e52b25e6e8f5f3015f0b908c08c8312088891b35719d45b5 | b9de76810ce09f7210cfe31938f33ce4f5ac0e5ec750471f82fd0219f952474d | 8210 | — |
| 13 | list\_proposals | Accepting votes before Some(145017) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:51:14.170 UTC | 6eb2a1f0f185e42314a5ec16c3022b7fa74084ffe96457ccdaea1526df66e74e | a63e7c1d6be54106da69ea61024fb382ed87025673081b5dcfbc6d5eb0277c60 | 8332 | — |
| 14 | list\_proposals | Accepting votes before Some(145007) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:51:17.859 UTC | 1247538bf966cebe96d5d7446f6a76e136ff1112239d59d2bb55d40a3406fa7e | 16f2cd7d2be35eadc47feb9eaa7b166455770f5ff25e03ac2abaf3d0457d5145 | 7987 | — |
| 15 | list\_proposals | Accepting votes before Some(144997) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:51:21.566 UTC | a62c62105e3681c0aa3e02c4e8734b4601c8bbd9ef059d796e03e909e961180c | a18b0664855c5626657ffbe6514fb5fe5cd8b3550fc6b2ed4a19e5f7b74a726c | 8956 | — |
| 16 | list\_proposals | Accepting votes before Some(144987) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:51:24.176 UTC | 0ff9eb701317bcfd3b3e31e5d2d5b7ce217048c0702f58c1c573d8994ec73750 | 85aa89e805a2be06411a010982db359c0584bec2e7deb0be78302c2c0e3ea90c | 11026 | — |
| 17 | list\_proposals | Accepting votes before Some(144977) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:51:27.292 UTC | c3ffcf8d521b577c421ece276989c1a53509cee99b7cd134b32ceb990e44bcb2 | 92fccefb5434863e716f40484cb2d31f81dd27662b4ee7d4e61e659a13d5b31e | 12098 | — |
| 18 | list\_proposals | Accepting votes before Some(144967) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:51:30.704 UTC | 52cc9cb10d07492aad15df54327328cad48aff75d24fa130325afd0ef18d8245 | abc3bf95fb1521f0f39b09e0466ece7f5e4c91a0d8fc33b2f21123a91e0548ce | 3184 | — |
| 19 | list\_proposals | Accepting votes before Some(144966) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 10:51:37.810 UTC | 91f9d85d03572786322b05f5978515dcb18a5dc10519a37e2ef54d943fbb7b2d | 3548dbeb53d501d199e613b3427784c8a3f8b9b34ff3cfee6ddd2870c411c693 | 2670 | — |
| 20 | get\_latest\_version | Registry head | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:51:42.125 UTC | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | 256e00f2bc1bf7f52469666a4ebbe0194825fd8f3c8d8efbc1311da2984ff438 | 4 | — |
| 21 | get\_value | subnet\_list | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 10:51:46.538 UTC | 1caf90b8a29ab63c2c9d0bd529d684d2f8031d2eff69231ddaf2aa5ff9e14822 | e700ca41381ba571f790b439875b923b4845fc269cfdb27ba1cb7dff6643f2b1 | 3055 | — |

</details>
