# Proposal review · [#145077](https://dashboard.internetcomputer.org/proposal/145077)

Proposal #145077 · After proposal #145077 · Step 1 of 1

Subnet [5kdm2-62fc6-fwnja-hutkz-ycsnm-4z33i-woh43-4cenu-ev7mi-gii6t-4ae](https://dashboard.internetcomputer.org/network/subnets/5kdm2-62fc6-fwnja-hutkz-ycsnm-4z33i-woh43-4cenu-ev7mi-gii6t-4ae)

Bundled test case · Historical replay · Recorded Open proposal · Registry 66,264

## Summary

Replace one node at dl1 with one at ge2. The subnet remains at 13 nodes. dl1 loses its last subnet member. ge2 membership changes 0 → 1.

13 members · Add 1 · Remove 1 · Unchanged 12

Target subnet checked; assignments in the other 97 listed subnets were not checked.

## Evidence scope

Pinned Registry version **66,264**. Governance checked after the selected comparisons.

- #145077 · Recorded status: Open · Original Governance observation 2026-11-27 20:50:51 UTC · Fixture backend observed 2026-11-28 08:35:58.247 UTC

- Proposed membership is conditional on the pinned evidence. Full execution validity remains unverified.

Original Registry observations 2026-11-27 20:50:52 UTC to 2026-11-27 22:03:48.852 UTC.

## Review checks

Conservative availability model. The fault budget is floor((N − 1) / 3). Model departing nodes unavailable in the before-state and incoming nodes still synchronizing in the proposed state. The smaller margin applies. A margin below one triggers a warning. The cumulative case keeps all earlier arrivals unavailable while they remain in the subnet. These conditional margins do not establish global assignment, execution validity or actual liveness.

### Step 1 · Proposal #145077

Add and Remove are disjoint · Add duplicates 0 · Remove duplicates 0 · Membership preconditions · Incoming assignments could not be established across the Registry roster

Conditional step margin · 3 additional faults tolerable · 4 would exceed the modeled budget

<details>
<summary>Instruction and margin arithmetic</summary>

- Duplicate Add principals · none
- Duplicate Remove principals · none
- Overlapping principals · none
- Individual step · 5kdm2-62fc6-fwnja-hutkz-ycsnm-4z33i-woh43-4cenu-ev7mi-gii6t-4ae · Before · 13 members, budget 4, modeled unavailable 1, remaining 3 · Proposed · 13 members, budget 4, modeled unavailable 1, remaining 3 · Limiting side: both states · Margin 3

</details>

Governance check incomplete · This historical review has no bundled cross-proposal observation.

## Map

![Map of registered node locations for the selected comparison](map.png)

Add (green) · Remove (red) · Unchanged (blue). 14 unique nodes across both states · 14/14 located. Positions use the registered data-center coordinates. The dotted halo indicates multiple node identities at the same coordinates.

Natural Earth map-unit boundaries are cartographic. Country shading uses recorded membership groups. Green shows increases and red shows decreases. A dashed border marks a country falling to zero. Small squares mark represented map units too small to see at the current zoom.

Changed sites · dl1 · 1 → 0 nodes · ge2 · 0 → 1 nodes

## Node changes

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
| Remove | [haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe](https://dashboard.internetcomputer.org/network/nodes/haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe) | [dl1](https://dashboard.internetcomputer.org/network/centers/dl1) | Flexential | [eipr5-izbom-neyqh-s3ec2-52eww-cyfpg-qfomg-3dpwj-4pffh-34xcu-7qe](https://dashboard.internetcomputer.org/network/provider/eipr5-izbom-neyqh-s3ec2-52eww-cyfpg-qfomg-3dpwj-4pffh-34xcu-7qe) | mw64v-jynex-7tu52-5a3te-ifbop-nh7y7-w7lno-ymmht-b7fmy-wfhha-gqe | 🇺🇸 United States (US) |
| Add | [ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae](https://dashboard.internetcomputer.org/network/nodes/ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae) | [ge2](https://dashboard.internetcomputer.org/network/centers/ge2) | SafeHost | [7ryes-jnj73-bsyu4-lo6h7-lbxk5-x4ien-lylws-5qwzl-hxd5f-xjh3w-mqe](https://dashboard.internetcomputer.org/network/provider/7ryes-jnj73-bsyu4-lo6h7-lbxk5-x4ien-lylws-5qwzl-hxd5f-xjh3w-mqe) | 5atxd-q4jom-dtpxr-awd3p-e562x-hpavj-godtj-g6vmz-of2c6-ildhh-fae | 🇨🇭 Switzerland (CH) |

<details>
<summary>Other Nodes (12)</summary>

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
|  | [ayf37-rq2hn-jiuvy-c2i3m-3kft2-v3jbe-c6mzo-f6yjy-sv52k-poii6-5ae](https://dashboard.internetcomputer.org/network/nodes/ayf37-rq2hn-jiuvy-c2i3m-3kft2-v3jbe-c6mzo-f6yjy-sv52k-poii6-5ae) | [sg3](https://dashboard.internetcomputer.org/network/centers/sg3) | Racks Central | [x7uok-pi537-itm37-unjn3-ewkze-kuetg-kptap-nuqak-auq7z-tn5ey-dqe](https://dashboard.internetcomputer.org/network/provider/x7uok-pi537-itm37-unjn3-ewkze-kuetg-kptap-nuqak-auq7z-tn5ey-dqe) | vicvb-nkzkt-tj2lz-yzzw4-gfcsj-3eggv-izdti-tarpt-fsojm-lgq22-wae | 🇸🇬 Singapore (SG) |
|  | [nusc3-gza5p-4iw7a-ea7xu-b6afg-r4sd3-saik7-io6zs-c36mg-q47ut-qae](https://dashboard.internetcomputer.org/network/nodes/nusc3-gza5p-4iw7a-ea7xu-b6afg-r4sd3-saik7-io6zs-c36mg-q47ut-qae) | [sj3](https://dashboard.internetcomputer.org/network/centers/sj3) | InfoObjects | [7ws2n-wqorv-vmo4m-5e222-n42c3-hk43s-ei3kp-4hpbn-xlkzo-jgv7i-tqe](https://dashboard.internetcomputer.org/network/provider/7ws2n-wqorv-vmo4m-5e222-n42c3-hk43s-ei3kp-4hpbn-xlkzo-jgv7i-tqe) | jtrpk-wokqg-aqmcn-esiq7-fip4e-dl7lv-iwdyj-cu5pm-wbg7i-4jl4t-wae | 🇺🇸 United States (US) |
|  | [zgeaf-fcq4e-fcnht-g7mpg-sb7ff-r6awk-zvkwp-gkloc-rr6jl-ghsse-mqe](https://dashboard.internetcomputer.org/network/nodes/zgeaf-fcq4e-fcnht-g7mpg-sb7ff-r6awk-zvkwp-gkloc-rr6jl-ghsse-mqe) | [ta2](https://dashboard.internetcomputer.org/network/centers/ta2) | Telia DC | [diyay-s4rfq-xnx23-zczwi-nptra-5254n-e4zn6-p7tqe-vqhzr-sd4gd-bqe](https://dashboard.internetcomputer.org/network/provider/diyay-s4rfq-xnx23-zczwi-nptra-5254n-e4zn6-p7tqe-vqhzr-sd4gd-bqe) | rhtt6-acsjc-c73k7-mnd7w-5253w-h35fr-lfknt-as6bb-rgxoy-xe4zr-dae | 🇪🇪 Estonia (EE) |
|  | [uouxk-c246i-dgxzd-ql3a5-koofn-mclrv-toplo-bg76d-l4dzk-ngb3c-nae](https://dashboard.internetcomputer.org/network/nodes/uouxk-c246i-dgxzd-ql3a5-koofn-mclrv-toplo-bg76d-l4dzk-ngb3c-nae) | [tb1](https://dashboard.internetcomputer.org/network/centers/tb1) | Cloud9 | [vegae-c4chr-aetfj-7gzuh-c23sx-u2paz-vmvbn-bcage-pu7lu-mptnn-eqe](https://dashboard.internetcomputer.org/network/provider/vegae-c4chr-aetfj-7gzuh-c23sx-u2paz-vmvbn-bcage-pu7lu-mptnn-eqe) | yhfy4-ny5ww-huz33-bkxym-eu27d-htlt4-yi77a-hvdqb-wpdlv-2cky7-uae | 🇬🇪 Georgia (GE) |
|  | [62yzt-726hf-rwk73-c3j6k-fjdls-7oqh5-exbnn-bvrsn-2soat-m4vg3-7ae](https://dashboard.internetcomputer.org/network/nodes/62yzt-726hf-rwk73-c3j6k-fjdls-7oqh5-exbnn-bvrsn-2soat-m4vg3-7ae) | [to2](https://dashboard.internetcomputer.org/network/centers/to2) | Cyxtera | [7at4h-nhtvt-a4s55-jigss-wr2ha-ysxkn-e6w7x-7ggnm-qd3d5-ry66r-cae](https://dashboard.internetcomputer.org/network/provider/7at4h-nhtvt-a4s55-jigss-wr2ha-ysxkn-e6w7x-7ggnm-qd3d5-ry66r-cae) | 4lp6i-khv7q-lkgk3-hhrc6-ysjag-korh7-ysojw-7gv3h-glhdz-rpjrt-sqe | 🇨🇦 Canada (CA) |
|  | [tu7cd-aljf3-56j73-xdusu-fyjps-sgkoi-5w3fx-p3vvd-tusca-w2vyl-bqe](https://dashboard.internetcomputer.org/network/nodes/tu7cd-aljf3-56j73-xdusu-fyjps-sgkoi-5w3fx-p3vvd-tusca-w2vyl-bqe) | [mn2](https://dashboard.internetcomputer.org/network/centers/mn2) | NEXTDC | [ihbuj-erwnc-tkjux-tqtnv-zkoar-uniy2-sk2go-xfpkc-znbb4-seukm-wqe](https://dashboard.internetcomputer.org/network/provider/ihbuj-erwnc-tkjux-tqtnv-zkoar-uniy2-sk2go-xfpkc-znbb4-seukm-wqe) | l5lhp-734i5-tbott-vipvc-vud2f-pfh7r-g3227-tgkdj-4rggm-abc2e-cae | 🇦🇺 Australia (AU) |
|  | [oswv7-a355p-a5jlp-ko7pj-arrs2-rghho-dti4z-xgptn-szn55-jjr46-uqe](https://dashboard.internetcomputer.org/network/nodes/oswv7-a355p-a5jlp-ko7pj-arrs2-rghho-dti4z-xgptn-szn55-jjr46-uqe) | [ty3](https://dashboard.internetcomputer.org/network/centers/ty3) | Equinix | [sixix-2nyqd-t2k2v-vlsyz-dssko-ls4hl-hyij4-y7mdp-ja6cj-nsmpf-yae](https://dashboard.internetcomputer.org/network/provider/sixix-2nyqd-t2k2v-vlsyz-dssko-ls4hl-hyij4-y7mdp-ja6cj-nsmpf-yae) | a5glg-n6ul6-rkuc7-idthk-fb2fe-d5m75-4g4l7-22yko-h27pr-q3a7k-lae | 🇯🇵 Japan (JP) |
|  | [ihoip-fmbnl-mm4fa-pu7hu-2sbx2-mzl2f-tgzje-unnjg-bgcac-3apmo-gqe](https://dashboard.internetcomputer.org/network/nodes/ihoip-fmbnl-mm4fa-pu7hu-2sbx2-mzl2f-tgzje-unnjg-bgcac-3apmo-gqe) | [sg1](https://dashboard.internetcomputer.org/network/centers/sg1) | Telin | [6nbcy-kprg6-ax3db-kh3cz-7jllk-oceyh-jznhs-riguq-fvk6z-6tsds-rqe](https://dashboard.internetcomputer.org/network/provider/6nbcy-kprg6-ax3db-kh3cz-7jllk-oceyh-jznhs-riguq-fvk6z-6tsds-rqe) | d4bin-5o2wg-ycbdq-yljr7-45pjv-ptf6d-v243j-vg6x5-dlo7t-yqu62-5qe | 🇸🇬 Singapore (SG) |
|  | [zos66-lmcn7-satbv-gcdzj-q3cdf-4n6zc-2hlei-gc453-uoh7r-4sj3w-vqe](https://dashboard.internetcomputer.org/network/nodes/zos66-lmcn7-satbv-gcdzj-q3cdf-4n6zc-2hlei-gc453-uoh7r-4sj3w-vqe) | [sh1](https://dashboard.internetcomputer.org/network/centers/sh1) | Digital Realty | [bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe](https://dashboard.internetcomputer.org/network/provider/bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe) | lgp6d-brhlv-35izu-khc6p-rfszo-zdwng-xbtkh-xyvjg-y3due-7ha7t-uae | 🇸🇪 Sweden (SE) |
|  | [fbypf-pftue-r2nbt-pueee-s454b-ycsuw-pjqqn-h3rh4-vlfpo-tokd5-mae](https://dashboard.internetcomputer.org/network/nodes/fbypf-pftue-r2nbt-pueee-s454b-ycsuw-pjqqn-h3rh4-vlfpo-tokd5-mae) | [pl2](https://dashboard.internetcomputer.org/network/centers/pl2) | Yotta | [zy4m7-z5mhs-zfkpl-zlsjl-blrbx-mvvmq-5z4zu-mf7eq-hhv7o-ezfro-3ae](https://dashboard.internetcomputer.org/network/provider/zy4m7-z5mhs-zfkpl-zlsjl-blrbx-mvvmq-5z4zu-mf7eq-hhv7o-ezfro-3ae) | 7rw6b-6r7qv-al3uk-rimg7-ifkjv-hettz-lhmly-t55g7-xrwac-25ayy-wae | 🇮🇳 India (IN) |
|  | [ocvcv-56eg5-gxibh-dcgpo-unhwq-4bwmo-x7q3h-stwf2-ycfex-gdr2a-kae](https://dashboard.internetcomputer.org/network/nodes/ocvcv-56eg5-gxibh-dcgpo-unhwq-4bwmo-x7q3h-stwf2-ycfex-gdr2a-kae) | [jb2](https://dashboard.internetcomputer.org/network/centers/jb2) | Africa Data Centres | [nmdd6-rouxw-55leh-wcbkn-kejit-njvje-p4s6e-v64d3-nlbjb-vipul-mae](https://dashboard.internetcomputer.org/network/provider/nmdd6-rouxw-55leh-wcbkn-kejit-njvje-p4s6e-v64d3-nlbjb-vipul-mae) | 3bohy-zygmq-6novb-wm65r-3k3y2-deh42-7emld-zhqo7-xl2oa-iextm-fae | 🇿🇦 South Africa (ZA) |
|  | [wq5v7-ngito-7ztqs-zlf2v-ibk6f-e54em-t3hou-x24kz-v5j77-6vo72-kqe](https://dashboard.internetcomputer.org/network/nodes/wq5v7-ngito-7ztqs-zlf2v-ibk6f-e54em-t3hou-x24kz-v5j77-6vo72-kqe) | [lj1](https://dashboard.internetcomputer.org/network/centers/lj1) | Posita.si | [wdjjk-blh44-lxm74-ojj43-rvgf4-j5rie-nm6xs-xvnuv-j3ptn-25t4v-6ae](https://dashboard.internetcomputer.org/network/provider/wdjjk-blh44-lxm74-ojj43-rvgf4-j5rie-nm6xs-xvnuv-j3ptn-25t4v-6ae) | gl27f-y5srq-yy5ot-v4x5z-y2a2s-sgoor-l4gjg-qv4x4-v2olb-dz4dc-wae | 🇸🇮 Slovenia (SI) |

</details>

## Decentralisation

Arrows show before → proposed; a single value is unchanged.

### Different groups represented

How many different registered groups have at least one member in this subnet?

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 5 | 11 → 12 | 13 | 13 | 13 | 13 |

### Largest group size

The most subnet nodes sharing one value, such as one provider or one country label. Several groups may tie.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 5 | 2 | 1 | 1 | 1 | 1 |

### Nakamoto coefficients

How many of the largest registered groups together contain more than one-third of the subnet's nodes? Each state uses floor(N / 3) + 1. Recorded groups do not establish independent ownership, subnet safety, execution validity or Target Topology compliance.

Node threshold: 5.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 1 | 3 → 4 | 5 | 5 | 5 | 5 |

### Distances between registered node locations

Straight-line geographic distances calculated from registered data-center coordinates, counting each pair of nodes once. These are not measured network latency or health.

| Shortest | Average | Longest |
| --- | --- | --- |
| 14.0 km | 8,913.3 km → 8,397.9 km | 16,948.9 km |

78 of 78 pairs before and proposed.

No current Target Topology thresholds, exceptions or applicability are assumed.

<details>
<summary>Recorded country membership</summary>

| Country (recorded token) | Subnet members |
| --- | --- |
| 🇦🇺 Australia (AU) | 1 |
| 🇨🇦 Canada (CA) | 1 |
| 🇨🇭 Switzerland (CH) | 0 → 1 |
| 🇪🇪 Estonia (EE) | 1 |
| 🇬🇪 Georgia (GE) | 1 |
| 🇮🇳 India (IN) | 1 |
| 🇯🇵 Japan (JP) | 1 |
| 🇸🇪 Sweden (SE) | 1 |
| 🇸🇬 Singapore (SG) | 2 |
| 🇸🇮 Slovenia (SI) | 1 |
| 🇺🇸 United States (US) | 2 → 1 |
| 🇿🇦 South Africa (ZA) | 1 |

</details>

## Sources and calculation

Membership preview revision `eaf863ace43af6bd59a41d7d9425cc5250157c42ba73690c15770d6142af4731`.

Calculation input SHA-256 `e378f37bc77fa8b4707b082f390545f7749eb456f4331df04a566acd72f0eb83` · analysis v5.

The replicated calculation digest identifies the exact submitted evidence and scope. Source receipts identify the separate Registry and Governance observations.

- #145077 executable payload SHA-256 7b30eb7aa652f5192d7b07e28912caf75289a5d16c87c7bfe16037ea86b69050

<details>
<summary>Exact distance evidence in metres</summary>

| Distance | Before | Proposed |
| --- | --- | --- |
| Shortest | 13952 | 13952 |
| Average | 8913267 | 8397901 |
| Longest | 16948908 | 16948908 |

</details>

<details>
<summary>Registered geography evidence</summary>

| Data center | Original Registry region | Country token |
| --- | --- | --- |
| [dl1](https://dashboard.internetcomputer.org/network/centers/dl1) | North America,US,Texas | US |
| [ge2](https://dashboard.internetcomputer.org/network/centers/ge2) | Europe,CH,Geneva | CH |
| [sg3](https://dashboard.internetcomputer.org/network/centers/sg3) | Asia,SG,Singapore | SG |
| [sj3](https://dashboard.internetcomputer.org/network/centers/sj3) | North America,US,California | US |
| [ta2](https://dashboard.internetcomputer.org/network/centers/ta2) | Europe,EE,Tallinn | EE |
| [tb1](https://dashboard.internetcomputer.org/network/centers/tb1) | Asia,GE,Tbilisi | GE |
| [to2](https://dashboard.internetcomputer.org/network/centers/to2) | North America,CA,Ontario | CA |
| [mn2](https://dashboard.internetcomputer.org/network/centers/mn2) | Oceania,AU,Melbourne | AU |
| [ty3](https://dashboard.internetcomputer.org/network/centers/ty3) | Asia,JP,Tokyo | JP |
| [sg1](https://dashboard.internetcomputer.org/network/centers/sg1) | Asia,SG,Singapore | SG |
| [sh1](https://dashboard.internetcomputer.org/network/centers/sh1) | Europe,SE,Stockholm | SE |
| [pl2](https://dashboard.internetcomputer.org/network/centers/pl2) | Asia,IN,Panvel | IN |
| [jb2](https://dashboard.internetcomputer.org/network/centers/jb2) | Africa,ZA,Gauteng | ZA |
| [lj1](https://dashboard.internetcomputer.org/network/centers/lj1) | Europe,SI,Ljubljana | SI |

</details>

<details>
<summary>Membership and Registry source receipts (53)</summary>

| Evidence stage | ID | Method | Item | Canister | Observed at | Argument SHA-256 | Reply SHA-256 | Bytes | Rejection |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Membership preview · Governance | 1 | get\_proposal\_info | 145077 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:54.933 UTC | c176c9ea5ce96ebcd18f9074f6ddd8cf31e58dfcf488925f9f0e1ffd70150bab | 06b3a2f48273ccc3c113b89a8a913ab7462268646f1266a25ccd08b7fdccc410 | 7425 | — |
| Membership preview · Registry | 2 | get\_latest\_version | Registry head | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:54.933 UTC | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | 78dbea3c701c2af3efb51551d46818c01b53abd04e04978f116df49d8d5d38c4 | 4 | — |
| Membership preview · Registry | 3 | get\_value | subnet\_list | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:54.933 UTC | 9fd3bbbfa00f480d64f709a13ebabf8746783f6fa118a25082ac171b7f75f54d | e700ca41381ba571f790b439875b923b4845fc269cfdb27ba1cb7dff6643f2b1 | 3055 | — |
| Membership preview · Registry | 4 | get\_value | subnet\_record\_5kdm2-62fc6-fwnja-hutkz-ycsnm-4z33i-woh43-4cenu-ev7mi-gii6t-4ae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:54.933 UTC | cf0076a85272c7644db54bd501af4a00e072c1fb59ca3febc5437cd68af6dec5 | 8a1f98eaed40644a5df8d19ae788235ceaa51cb51f66269535341c1c1f792041 | 496 | — |
| Membership preview · Registry | 5 | get\_value | node\_record\_haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:54.933 UTC | 4511e6f8b66d1d0cdffe0c4d73bf6f7a1d30820c333841c0d6163159be8f8516 | 3bf2975c0c1ed7a5f53c39e99b09dd2cc9ff510b5fd655274929c97cf667da0c | 245 | — |
| Membership preview · Registry | 6 | get\_value | node\_record\_ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:54.933 UTC | 85830f6a301896185c951d6e811cbee5c73b391b505b9e56b022245d1778e390 | dc31d0aa28b9dac3dad08d0187c25cee04a5710d9c3750ee6ac11a5b9d0e44cb | 231 | — |
| Membership preview · Registry | 7 | get\_value | api\_boundary\_node\_haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:54.933 UTC | 759d8260d40e2e6cf6eee0c04595a778dbc3fbae269cdb8c2b6de62a8ccc4234 | 0498d94b2e26beb1b374582e9b9463536cca019faf3c09b5077803cc32a2f3a3 | 91 | — |
| Membership preview · Registry | 8 | get\_value | api\_boundary\_node\_ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:54.933 UTC | 75127b30f7cea22cc34e3e035e487e2518fbb0e4d08cb21808bf76070cac750e | 7293afa89d738fce16dd32596430a6c20ea5d62ce0d600fb7848e410d9b508c0 | 91 | — |
| Membership preview · Governance | 9 | get\_proposal\_info | 145077 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:54.933 UTC | c176c9ea5ce96ebcd18f9074f6ddd8cf31e58dfcf488925f9f0e1ffd70150bab | 06b3a2f48273ccc3c113b89a8a913ab7462268646f1266a25ccd08b7fdccc410 | 7425 | — |
| Registry enrichment · Nodes | 1 | get\_value | node\_record\_ayf37-rq2hn-jiuvy-c2i3m-3kft2-v3jbe-c6mzo-f6yjy-sv52k-poii6-5ae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:55.465 UTC | da989f8c73e2ff6cfa5749c0a01ee849c1ac62ecdfa0bfddbbe9ef692869cb59 | 7a13411b346fbf7431ba58a949c4d9e83fa4eec53c20b7ec405dbba17bb3b27e | 180 | — |
| Registry enrichment · Nodes | 2 | get\_value | node\_record\_nusc3-gza5p-4iw7a-ea7xu-b6afg-r4sd3-saik7-io6zs-c36mg-q47ut-qae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:55.465 UTC | a61b538abfc62aac91d9b07e755ea158e0e28e22891f7267ea669fe4c82bc517 | ec6c88916e796d48b35e45989d5fb4cb6c637d23a4cf39975551b359d082f0cb | 178 | — |
| Registry enrichment · Nodes | 3 | get\_value | node\_record\_fbypf-pftue-r2nbt-pueee-s454b-ycsuw-pjqqn-h3rh4-vlfpo-tokd5-mae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:55.465 UTC | ade54c3c0ad509c00b806f5596ff88fa6690fd34ae594d351b474c0a7fff6f5e | 63164ab676a82f040f5d341061ae5fe7b66cf55c3a8b582482be8c99bd1ab720 | 180 | — |
| Registry enrichment · Nodes | 4 | get\_value | node\_record\_zgeaf-fcq4e-fcnht-g7mpg-sb7ff-r6awk-zvkwp-gkloc-rr6jl-ghsse-mqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:55.465 UTC | 4f2437e7b7122f3e439da36ea6e6674262da9e673fdbea9d8635dd1f8b1c281d | 0f87f853f0b6989f3d82fd17f21e9ec935c495f7c7a006a515c22b462f2446fb | 174 | — |
| Registry enrichment · Nodes | 5 | get\_value | node\_record\_uouxk-c246i-dgxzd-ql3a5-koofn-mclrv-toplo-bg76d-l4dzk-ngb3c-nae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:55.465 UTC | 55391a0a153b41d14b574123f2d28c914ae3429e4a0d115edc70ff4d83abf159 | a78445b3111f3a31af22c1c1d6171f15b0bdab6189ee629d1ee1d18b64387a9d | 174 | — |
| Registry enrichment · Nodes | 6 | get\_value | node\_record\_haeka-mchv4-zwg3j-d3sz2-k5z2x-ulfmb-kflyu-ezzlz-ckc3d-ako5j-uqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:55.465 UTC | 4511e6f8b66d1d0cdffe0c4d73bf6f7a1d30820c333841c0d6163159be8f8516 | 3bf2975c0c1ed7a5f53c39e99b09dd2cc9ff510b5fd655274929c97cf667da0c | 245 | — |
| Registry enrichment · Nodes | 7 | get\_value | node\_record\_tu7cd-aljf3-56j73-xdusu-fyjps-sgkoi-5w3fx-p3vvd-tusca-w2vyl-bqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:55.465 UTC | b701eb000df27b79742e5004acb9153a50bab4de0c08459ef0f4af145f41e0eb | 0ccf240850bd9de7558835b2cdb22dd87303adda01bbc062bde835078de4d9d6 | 178 | — |
| Registry enrichment · Nodes | 8 | get\_value | node\_record\_62yzt-726hf-rwk73-c3j6k-fjdls-7oqh5-exbnn-bvrsn-2soat-m4vg3-7ae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:55.465 UTC | 74e4f348567f641331d1dce9d06086f996333da546b8c8929209e5881996e679 | a98c3bd41ca7a3d61b39d2e16efe7ee5f42ff8a841040cfb0bbda4273523a886 | 251 | — |
| Registry enrichment · Nodes | 9 | get\_value | node\_record\_ihoip-fmbnl-mm4fa-pu7hu-2sbx2-mzl2f-tgzje-unnjg-bgcac-3apmo-gqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:55.465 UTC | b5d6dbe82013f6e8a2fd5ac7328b037da174d1ad08d87edb9c565ae459474a37 | 56cf7d3554c76967daebe23ece33b9c424264380cbcbbf6ec4720b389b02b4f6 | 180 | — |
| Registry enrichment · Nodes | 10 | get\_value | node\_record\_ocvcv-56eg5-gxibh-dcgpo-unhwq-4bwmo-x7q3h-stwf2-ycfex-gdr2a-kae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:55.465 UTC | b80b2aea75ae8c3851f004a04b5f0838bcda5a750287bcc772d385a5078e6291 | 6c33d7067c02f8b870a942929a7ff126188df8af9fa93b40c9fe702ba843f456 | 180 | — |
| Registry enrichment · Nodes | 11 | get\_value | node\_record\_zos66-lmcn7-satbv-gcdzj-q3cdf-4n6zc-2hlei-gc453-uoh7r-4sj3w-vqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:55.465 UTC | 1a6b039702d07464be7518326dc16a24974ffd34b0546945af7eba70bb098630 | b03c333111717ee2c97018d2691fa903ea88cce162c369f5accf5aa0f5973362 | 184 | — |
| Registry enrichment · Nodes | 12 | get\_value | node\_record\_oswv7-a355p-a5jlp-ko7pj-arrs2-rghho-dti4z-xgptn-szn55-jjr46-uqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:55.465 UTC | 1efcd4a20b21eda35594434518589c9914836493dba814539340e156d37460f4 | 2f244d753babdb191829ffd675f867582a4acc63f063400e533bcbeb271988a7 | 180 | — |
| Registry enrichment · Nodes | 13 | get\_value | node\_record\_wq5v7-ngito-7ztqs-zlf2v-ibk6f-e54em-t3hou-x24kz-v5j77-6vo72-kqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:55.465 UTC | f7b555ab9c6bac9028c988ba30999a61f0d75e5c0fe3910e35cdb054a89315c1 | 66df3f5ec6a63b1ac5f6fbc7ef924f12a9b9d2e7d6efe275b97a9f4cff57e65a | 178 | — |
| Registry enrichment · Nodes | 14 | get\_value | node\_record\_ssfqq-s2yvo-mtunz-ok6ih-wbtxo-p42ie-mlm2u-g33bu-fm6kj-rpz2s-kae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:55.465 UTC | 85830f6a301896185c951d6e811cbee5c73b391b505b9e56b022245d1778e390 | dc31d0aa28b9dac3dad08d0187c25cee04a5710d9c3750ee6ac11a5b9d0e44cb | 231 | — |
| Registry enrichment · Operators | 1 | get\_value | node\_operator\_record\_vicvb-nkzkt-tj2lz-yzzw4-gfcsj-3eggv-izdti-tarpt-fsojm-lgq22-wae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.033 UTC | c159bcfaa56e30a010aea2e8c8dc439604fcab530bddca776c0a08f1de59ffe9 | 74524f4e0d2dfeb212e54508286e6ba4655c127fb7df49e27ec65e3b94a430df | 109 | — |
| Registry enrichment · Operators | 2 | get\_value | node\_operator\_record\_jtrpk-wokqg-aqmcn-esiq7-fip4e-dl7lv-iwdyj-cu5pm-wbg7i-4jl4t-wae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.033 UTC | d4e77fa0d3c2996b905aaa1d8f6f6b2fb08e81f988addc291c21b50a5b87b0e3 | 062f7237a6310b21827142faa3d7003ae741febab3f65467e676bec3944e1d38 | 111 | — |
| Registry enrichment · Operators | 3 | get\_value | node\_operator\_record\_7rw6b-6r7qv-al3uk-rimg7-ifkjv-hettz-lhmly-t55g7-xrwac-25ayy-wae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.033 UTC | 2521bc00d37efebae1ec2d71d01c5ce3dcfb29a2da7c0d864d7edc239ef64fe5 | c3be55698ca63e14b767c582e6e52ca7d62e43a2839332ec503ae7aa9217b0dc | 111 | — |
| Registry enrichment · Operators | 4 | get\_value | node\_operator\_record\_rhtt6-acsjc-c73k7-mnd7w-5253w-h35fr-lfknt-as6bb-rgxoy-xe4zr-dae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.033 UTC | 8811623590d9b1ca147a9176235939da0698e8c83dd7c1359cd8a30cc5cc70a9 | 7a60333ead9adb13ce3cb37fea51b9faeaf199d60fce0752ec695acad9fa5425 | 109 | — |
| Registry enrichment · Operators | 5 | get\_value | node\_operator\_record\_yhfy4-ny5ww-huz33-bkxym-eu27d-htlt4-yi77a-hvdqb-wpdlv-2cky7-uae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.033 UTC | 148190c619294bcbdf7d69358c56d6b7b906816472b84cc180180d45ad43ec91 | 150593eea924e0fa1c830473c60497b28d7ca2f1773bba29b5350370ad55a552 | 111 | — |
| Registry enrichment · Operators | 6 | get\_value | node\_operator\_record\_mw64v-jynex-7tu52-5a3te-ifbop-nh7y7-w7lno-ymmht-b7fmy-wfhha-gqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.033 UTC | 6a77318b4701b53de692fec56cd105c2f9630b321afb580cd6cba4617881b9ac | 9e807809b50c46f444d850166529b66e5d0d22c627909bae03e84e0cf4465284 | 111 | — |
| Registry enrichment · Operators | 7 | get\_value | node\_operator\_record\_l5lhp-734i5-tbott-vipvc-vud2f-pfh7r-g3227-tgkdj-4rggm-abc2e-cae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.033 UTC | 77fb3055ed2de139d2f9d70e2e5bce76dde9b89be728c5e58ef3f776697ea42f | 870a6d6179dd65e901e02a2c2f7c67aba57d6f4e5a458a8c5078ad5998331f5e | 111 | — |
| Registry enrichment · Operators | 8 | get\_value | node\_operator\_record\_4lp6i-khv7q-lkgk3-hhrc6-ysjag-korh7-ysojw-7gv3h-glhdz-rpjrt-sqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.033 UTC | 1cf43bd19f04ef76d889bc036d5a63ac3fa205e9f5c8695bcb866796f5cf0715 | 1c6bda60eae8cdff26d68fd39a03abc7a4a3d5a693b95fb47240be9e38353c81 | 111 | — |
| Registry enrichment · Operators | 9 | get\_value | node\_operator\_record\_d4bin-5o2wg-ycbdq-yljr7-45pjv-ptf6d-v243j-vg6x5-dlo7t-yqu62-5qe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.033 UTC | 294f6d2624c403d80ac2510033520d21c55e23078f932d969bb0948328bad951 | 605f0773da9d12d3a9428068393a1a7c258702ca68243fe5bdee8db153e02aaa | 111 | — |
| Registry enrichment · Operators | 10 | get\_value | node\_operator\_record\_3bohy-zygmq-6novb-wm65r-3k3y2-deh42-7emld-zhqo7-xl2oa-iextm-fae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.033 UTC | ac371eedbb9b00ebc8ee22f7c0674660f7b3bb277b5e99bb59dff2286fd73d75 | 55f1550a690609159b3bdbc1d34f5c1a122b5c43252024d19d08f8f461ff4185 | 111 | — |
| Registry enrichment · Operators | 11 | get\_value | node\_operator\_record\_lgp6d-brhlv-35izu-khc6p-rfszo-zdwng-xbtkh-xyvjg-y3due-7ha7t-uae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.033 UTC | be65a71fa4e31d70f87bd1c86c56fb0a540d70c2d298260f01ce4e70d0d16deb | 8b2fbe78cc4b1377882bb74555264106dd4c5970f199b579868fc3e5a41245fc | 111 | — |
| Registry enrichment · Operators | 12 | get\_value | node\_operator\_record\_a5glg-n6ul6-rkuc7-idthk-fb2fe-d5m75-4g4l7-22yko-h27pr-q3a7k-lae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.033 UTC | f0965367af44e4516f49e4af92caf38da0a5243b3f3f1ec3f810e610c3a5f5f2 | ca3dc094aa5bf974475b42b231448e3809b20828259d66d6528e1dd3c05ca456 | 111 | — |
| Registry enrichment · Operators | 13 | get\_value | node\_operator\_record\_gl27f-y5srq-yy5ot-v4x5z-y2a2s-sgoor-l4gjg-qv4x4-v2olb-dz4dc-wae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.033 UTC | f69f7faee0b9daf604b79680bf50ea5164985b520fed3961598767a965f92cae | 1fa4d72537af8fbd1798916221dde161175a7fad9a85f05b40e303dc74d705c1 | 111 | — |
| Registry enrichment · Operators | 14 | get\_value | node\_operator\_record\_5atxd-q4jom-dtpxr-awd3p-e562x-hpavj-godtj-g6vmz-of2c6-ildhh-fae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.033 UTC | 462bdcc817c6d1748399e1029fd9c2a4ad73e54985a90e9dc830676b66e7bbd1 | 1388360b56112f1080e9e265c5876cad17e78f9dfb72f6bdaa76175bd01542aa | 111 | — |
| Registry enrichment · DataCenters | 1 | get\_value | data\_center\_record\_sg3 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.568 UTC | 846e434252b242dd1131624a08c29aeaa97dfaa23ee6b89ae31976002ecaf10d | 90929f77df0b87158be9d169b7a4530d3702cdbcf5a548deaf9d1c9a98d34e66 | 57 | — |
| Registry enrichment · DataCenters | 2 | get\_value | data\_center\_record\_sj3 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.568 UTC | ed1f5903f98b939888f392da4e13bd88a64bf6f3cd58fb882d5782920e3efa89 | 544c70ff00ec165e5dfa5984b2a8948e18198a318a237fc98acd1b278d5b748f | 65 | — |
| Registry enrichment · DataCenters | 3 | get\_value | data\_center\_record\_pl2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.568 UTC | c7856a3de91e85e06a4e5fb69a50f6ebd1352f37ca8eac36003c469b6860c3b9 | 7e0739d8f49ab5e841be5444a4bf280c278bf3fc5b6c1a29c3c7178cd235bc97 | 46 | — |
| Registry enrichment · DataCenters | 4 | get\_value | data\_center\_record\_ta2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.568 UTC | 69707cb1db6a4175a0953b37f2830225732c2dae6061708c609e00ede1ebc62a | 657ac5bb67a5a177a95839ecc47da108483804f91d73ab9d15795af35862975a | 52 | — |
| Registry enrichment · DataCenters | 5 | get\_value | data\_center\_record\_tb1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.568 UTC | 0903bd7c224269bb65be8a2878cf601ec7266b312b82500ae8026c69e2798ba5 | f0d69ba00d6458422c91d6b4d642fed99468654e2a9eb64f7a231bd3a592958d | 48 | — |
| Registry enrichment · DataCenters | 6 | get\_value | data\_center\_record\_dl1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.568 UTC | 001808cb9a5b87964e6b5518d56d97e6de4106fd151a7536ab058198ae137dd2 | 570fa1dfc7c9ae7e05f1781a760e9c465be126482cc23cd77369d86b3b103dfe | 59 | — |
| Registry enrichment · DataCenters | 7 | get\_value | data\_center\_record\_mn2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.568 UTC | dc715887a53001cd63033b12d32f258c5fedcbe388e03ec43418da0f7524c891 | fcd7ea30f65e5626fc407494a5a67c98a1c9107c39bb4a404d12e002d4751982 | 53 | — |
| Registry enrichment · DataCenters | 8 | get\_value | data\_center\_record\_to2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.568 UTC | ca57c552011898604f57da0b4b718ebba93de31b5d73ff6da171124f33a40ec9 | 7161762007c951239545c9fc2ea667c99df4da49bb96ee366972bceaf74e6741 | 58 | — |
| Registry enrichment · DataCenters | 9 | get\_value | data\_center\_record\_sg1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.568 UTC | fbb45caa983dbd7f148acd290ec86ff2a0e6f242122887cfbf05e5b08282119a | 8063f1b111f69a286f34d0ee712ad6a834f57a52f62aab5634039a231095e7c2 | 49 | — |
| Registry enrichment · DataCenters | 10 | get\_value | data\_center\_record\_jb2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.568 UTC | 82fc5eeec25b8e03efa5f016efa1403023a2f90d569f84c6affe295d1a0ea018 | c3de5004f3e0bab997fdb6a247ebeebcefdf8185b1d61f52ed5b634cf48f2fa9 | 63 | — |
| Registry enrichment · DataCenters | 11 | get\_value | data\_center\_record\_sh1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.568 UTC | 10a0889e8d68e424defa292e40aa54cdda7e733696453a2cd6658dc019350f2d | 5efaa12dbed1f6f6ec61857abab3f001b8e7c8193e92b72642dbe71707ae36c9 | 60 | — |
| Registry enrichment · DataCenters | 12 | get\_value | data\_center\_record\_ty3 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.568 UTC | 8cbf8bf4008363b40eadea14fd570a1b115824613c40488ff6be760a02b87bb3 | 9b914fd2c10cfb81862c10844447af01e280a5af3008521561e21955cbc5c0c3 | 47 | — |
| Registry enrichment · DataCenters | 13 | get\_value | data\_center\_record\_lj1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.568 UTC | 238d36818e671f2af67366713d4f7105d4ba194a03b6b84154e9fcfee322132a | 5f6dae6011b9f61e3f1c0a7710009816800e54292d1ffc313b541ab4b5d6e9db | 55 | — |
| Registry enrichment · DataCenters | 14 | get\_value | data\_center\_record\_ge2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:56.568 UTC | 355ef508fcc38d1b604d2d7beae4e31ecf7eee19736915b7d02faed9276af1bf | f5fe58753652335ca955fa15826fe946c69cd3d4350511c5d5916827829d0e78 | 51 | — |
| Registry enrichment · Role | 1 | get\_value | nns\_subnet\_id | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:57.129 UTC | 530c568408732b0aeda20003da2fe4d5a328e13e47694849e5b3980182ff0de1 | 74ca3bc2b0e0a7a0f6c02c9a4f286cbd1616ef3b3ce2cae7ecf2495d691d6154 | 37 | — |
| Final Governance verification | 1 | get\_proposal\_info | 145077 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:58.247 UTC | c176c9ea5ce96ebcd18f9074f6ddd8cf31e58dfcf488925f9f0e1ffd70150bab | 06b3a2f48273ccc3c113b89a8a913ab7462268646f1266a25ccd08b7fdccc410 | 7425 | — |

</details>
