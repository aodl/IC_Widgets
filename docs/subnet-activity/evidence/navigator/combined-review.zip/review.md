# Proposal review · [#990022](https://dashboard.internetcomputer.org/proposal/990022) + [#990021](https://dashboard.internetcomputer.org/proposal/990021)

Proposal #990022 then Proposal #990021 · After proposal #990021 · Step 2 of 2

Subnet [5ag63-q3yke-ba](https://dashboard.internetcomputer.org/network/subnets/5ag63-q3yke-ba)

Bundled test case · Synthetic scenario · Constructed Open proposal · Registry 100

## Summary

Add 4 and remove 4 nodes. The subnet remains at 6 nodes.

6 members · Add 4 · Remove 4 · Unchanged 2

Checked all 1 listed subnet memberships. Full execution validity remains unverified.

- NNS role was not recorded at the pinned version

## Evidence scope

Pinned Registry version **100**. Governance checked after the selected comparisons.

- #990021 · Constructed status: Open · Synthetic Governance action · Fixture backend observed 2026-11-28 08:35:53.414 UTC
- #990022 · Constructed status: Open · Synthetic Governance action · Fixture backend observed 2026-11-28 08:35:53.414 UTC

- NNS role was not recorded at the pinned version
- Proposed membership is conditional on the pinned evidence. Full execution validity remains unverified.

Original Registry observation times unavailable for this replay.

## Review checks

Conservative availability model. The fault budget is floor((N − 1) / 3). Model departing nodes unavailable in the before-state and incoming nodes still synchronizing in the proposed state. The smaller margin applies. A margin below one triggers a warning. The cumulative case keeps all earlier arrivals unavailable while they remain in the subnet. These conditional margins do not establish global assignment, execution validity or actual liveness.

### Step 1 · Proposal #990022

Add and Remove are disjoint · Add duplicates 0 · Remove duplicates 0 · Membership preconditions · Established within the checked membership scope

Conditional step margin · Warning · modeled fault budget exceeded by 2

- Duplicate Add principals · none

- Duplicate Remove principals · none

- Overlapping principals · none

- 5ag63-q3yke-ba · Before · 6 members, budget 1, modeled unavailable 3, remaining -2 · Proposed · 5 members, budget 1, modeled unavailable 2, remaining -1

### Step 2 · Proposal #990021

Add and Remove overlap · removal wins under the upstream simulation · Add duplicates 1 · Remove duplicates 1 · Membership preconditions · Established within the checked membership scope

Conditional step margin · Warning · modeled fault budget exceeded by 1

Cumulative unsynchronized arrivals · Warning · modeled fault budget exceeded by 3

- Duplicate Add principals · kk3lb-f3yae-ba

- Duplicate Remove principals · kk3lb-f3yae-ba

- Overlapping principals · kk3lb-f3yae-ba

- 5ag63-q3yke-ba · Before · 5 members, budget 1, modeled unavailable 1, remaining 0 · Proposed · 6 members, budget 1, modeled unavailable 2, remaining -1

Governance check complete within the supported evidence · 0 references found

- Sources uxrrr-q7777-77774-qaaaq-cai · 4 admitted reads

- Discovery observed 2026-11-28 08:35:53.916 UTC to 2026-11-28 08:35:53.916 UTC

- Pagination complete · 2 pages · oldest listed #990021 · Open 2 · Adopted awaiting execution 0

- Title, summary and supported motion text checked for 2 proposals · Supported actions decoded 2 · Hydrated 0 · Lifecycle changed 0

- Unsupported actions 0 · Missing payloads 0 · Malformed payloads 0 · Omitted findings 0

## Map

![Map of registered node locations for the selected comparison](map.png)

Add (green) · Remove (red) · Unchanged (blue). 10 unique nodes across both states · 10/10 located. Positions use the registered data-center coordinates. The dotted halo indicates multiple node identities at the same coordinates.

Natural Earth map-unit boundaries are cartographic. Country shading uses recorded membership groups. Green shows increases and red shows decreases. A dashed border marks a country falling to zero. Small squares mark represented map units too small to see at the current zoom.

Unmatched recorded country labels remain in the distribution.

Changed sites · fixture-0 · 3 nodes · fixture-1 · 3 nodes

## Node changes

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
| Remove | [kk3lb-f3yae-ba](https://dashboard.internetcomputer.org/network/nodes/kk3lb-f3yae-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
| Remove | [pgn6g-vdyai-ba](https://dashboard.internetcomputer.org/network/nodes/pgn6g-vdyai-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
| Remove | [mcane-flyam-ba](https://dashboard.internetcomputer.org/network/nodes/mcane-flyam-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
| Remove | [f7auj-utyaq-ba](https://dashboard.internetcomputer.org/network/nodes/f7auj-utyaq-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
| Add | [atwbo-elya4-ba](https://dashboard.internetcomputer.org/network/nodes/atwbo-elya4-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
| Add | [qn2ax-xtyba-ba](https://dashboard.internetcomputer.org/network/nodes/qn2ax-xtyba-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
| Add | [tjxtv-h3ybe-ba](https://dashboard.internetcomputer.org/network/nodes/tjxtv-h3ybe-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
| Add | [wfbgs-xdybi-ba](https://dashboard.internetcomputer.org/network/nodes/wfbgs-xdybi-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |

<details>
<summary>Other Nodes (2)</summary>

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
|  | [g3nhl-e3yau-ba](https://dashboard.internetcomputer.org/network/nodes/g3nhl-e3yau-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
|  | [dx3sm-udyay-ba](https://dashboard.internetcomputer.org/network/nodes/dx3sm-udyay-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |

</details>

## Decentralisation

Arrows show before → proposed; a single value is unchanged.

### Different groups represented

How many different registered groups have at least one member in this subnet?

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 1 | 2 | 2 | 2 | 2 | 2 |

### Largest group size

The most subnet nodes sharing one value, such as one provider or one country label. Several groups may tie.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 6 | 3 | 3 | 3 | 3 | 3 |

### Nakamoto coefficients

How many of the largest registered groups together contain more than one-third of the subnet's nodes? Each state uses floor(N / 3) + 1. Recorded groups do not establish independent ownership, subnet safety, execution validity or Target Topology compliance.

Node threshold: 3.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 1 | 1 | 1 | 1 | 1 | 1 |

### Distances between registered node locations

Straight-line geographic distances calculated from registered data-center coordinates, counting each pair of nodes once. These are not measured network latency or health.

| Shortest | Average | Longest |
| --- | --- | --- |
| 0 km | 3,994.7 km | 6,657.9 km |

15 of 15 pairs before and proposed.

No current Target Topology thresholds, exceptions or applicability are assumed.

<details>
<summary>Recorded country membership</summary>

| Country (recorded token) | Subnet members |
| --- | --- |
| Label 0 | 3 |
| Label 1 | 3 |

</details>

## Sources and calculation

Membership preview revision `62d308d2ba9d62ba5f2feb5aa5145ae6eb62ddc779a9fa4256a063f3b4034792`.

Calculation input SHA-256 `c3f29d509cba2c7a68391263d236ea11646578408062d04769be350a6cd5d078` · analysis v5.

The replicated calculation digest identifies the exact submitted evidence and scope. Source receipts identify the separate Registry and Governance observations.

- #990021 executable payload SHA-256 9916e32bd1bc18a2defabaec6e862f9823ea972d9d853cc60732522205694e9e
- #990022 executable payload SHA-256 c0fc5d0a390a6b4ff5c5f78ebac8e1e4337458298dbcd7557052d795ad22518f

<details>
<summary>Exact distance evidence in metres</summary>

| Distance | Before | Proposed |
| --- | --- | --- |
| Shortest | 0 | 0 |
| Average | 3994711 | 3994711 |
| Longest | 6657851 | 6657851 |

</details>

<details>
<summary>Registered geography evidence</summary>

| Data center | Original Registry region | Country token |
| --- | --- | --- |
| [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Fixture,Label 0,Synthetic site 0 | Label 0 |
| [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Fixture,Label 1,Synthetic site 1 | Label 1 |

</details>

<details>
<summary>Session source receipts (40)</summary>

| Method | Item | Canister | Fixture capture time | Reply SHA-256 or issue |
| --- | --- | --- | --- | --- |
| get\_proposal\_info | 990021 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | 7b7a713f442cbfed0c60389f56582acbb91ba4f978798e15dc6578a4004df60b |
| get\_proposal\_info | 990022 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | 120f3f4398fef9072af68799aab080ebf4d86c7e00760cc854cd772bd49aaeee |
| get\_latest\_version | Registry head | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | c0bffeaab8e16948afec4ac6e56088d8072a68d0788301b53e60560e8d85ce58 |
| get\_value | subnet\_list | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | 40061793c7ab638a07e0263d0c9edc78271ddc35825f444a9714da4e659a47e1 |
| get\_value | subnet\_record\_5ag63-q3yke-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | ac76668724a6016ad54cebc58ac8261bb0b1a00f12e25239eaa1cfb8065a311b |
| get\_value | node\_record\_kk3lb-f3yae-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_pgn6g-vdyai-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_mcane-flyam-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_f7auj-utyaq-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_atwbo-elya4-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_qn2ax-xtyba-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_tjxtv-h3ybe-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_wfbgs-xdybi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | api\_boundary\_node\_kk3lb-f3yae-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | e529d73779dbecacf4f438ddca5ffaf6acb7d5b8c21f4a2768d7cc15048628a8 |
| get\_value | api\_boundary\_node\_pgn6g-vdyai-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | 6fb04ee8ef77f75ca6de77bb0fe1ac9dc783fa5ee5eb63b1b5ccfa1d0f4796a5 |
| get\_value | api\_boundary\_node\_mcane-flyam-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | 3d1df03ab5598250df94d18e4ac38e78f9b3ab6c3aebc3532df3f25dabd74633 |
| get\_value | api\_boundary\_node\_f7auj-utyaq-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | de15154af0b9bf0ef9d96ea00a9f81c0bc45c7e5457a30b8bf9899366d24c725 |
| get\_value | api\_boundary\_node\_atwbo-elya4-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | 3d60352a77a7b3ba02a5a26f868c57e7eb5ccefaa0bfd2bbb63118e9d3ecc1c1 |
| get\_value | api\_boundary\_node\_qn2ax-xtyba-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | e264d15ae03e9d8816f3c4d6a72f32f4d674e412b07009968ea50e45b8beccff |
| get\_value | api\_boundary\_node\_tjxtv-h3ybe-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | 86b6dee61ef4eee816a81a7375e1693530027e2773b7ce5d288d6af0fb3ca964 |
| get\_value | api\_boundary\_node\_wfbgs-xdybi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | 99c9b969a5f6bdab9313bb92ba54e5a0f42de2c343171a743701a120a1cd1ed8 |
| get\_proposal\_info | 990021 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | 7b7a713f442cbfed0c60389f56582acbb91ba4f978798e15dc6578a4004df60b |
| get\_proposal\_info | 990022 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:47.374 UTC | 120f3f4398fef9072af68799aab080ebf4d86c7e00760cc854cd772bd49aaeee |
| get\_value | node\_record\_kk3lb-f3yae-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:48.009 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_pgn6g-vdyai-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:48.009 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_mcane-flyam-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:48.009 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_f7auj-utyaq-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:48.009 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_g3nhl-e3yau-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:48.009 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_dx3sm-udyay-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:48.009 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_qn2ax-xtyba-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:48.009 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_tjxtv-h3ybe-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:48.009 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_atwbo-elya4-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:48.009 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_wfbgs-xdybi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:48.009 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_operator\_record\_d4h56-4c2fi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:48.636 UTC | b7a469fce576bc5f0ffe09c60c5c7547423ab90160a86d9f71c535df6364257e |
| get\_value | node\_operator\_record\_d3g3k-r23fi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:48.636 UTC | bc8572c5d088d87e16d73701f59a02e3135c91965012deab1a153bd0eebf3582 |
| get\_value | data\_center\_record\_fixture-0 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:49.141 UTC | 2463378715bdb8a06123a9dff29e19870852dce08d95c90b7a45ce15a11d81d6 |
| get\_value | data\_center\_record\_fixture-1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:49.141 UTC | 42df72beb94c88c8654c293d38c6fb24216ed0975ec211e7c21238bba1c1f80a |
| get\_value | nns\_subnet\_id | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:49.761 UTC | 4cdd267ab9320daa812408894fca044891acc034f7e60a0c6d05104eda09df85 |
| get\_proposal\_info | 990021 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:53.414 UTC | 7b7a713f442cbfed0c60389f56582acbb91ba4f978798e15dc6578a4004df60b |
| get\_proposal\_info | 990022 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 08:35:53.414 UTC | 120f3f4398fef9072af68799aab080ebf4d86c7e00760cc854cd772bd49aaeee |

</details>
