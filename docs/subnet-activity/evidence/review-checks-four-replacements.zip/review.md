# Proposal review · [#990011](https://dashboard.internetcomputer.org/proposal/990011)

Proposal #990011 · After proposal #990011 · Step 1 of 1

Subnet [5ag63-q3yke-ba](https://dashboard.internetcomputer.org/network/subnets/5ag63-q3yke-ba)

Bundled test case · Synthetic scenario · Constructed Open proposal · Registry 100

## Summary

Add 4 and remove 4 nodes. The subnet remains at 13 nodes.

13 members · Add 4 · Remove 4 · Unchanged 9

Checked all 1 listed subnet memberships. Full execution validity remains unverified.

- NNS role was not recorded at the pinned version

## Evidence scope

Pinned Registry version **100**. Governance checked after the selected comparisons.

- #990011 · Constructed status: Open · Synthetic Governance action · Fixture backend observed 2026-11-27 21:03:03.023 UTC

- NNS role was not recorded at the pinned version
- Proposed membership is conditional on the pinned evidence. Full execution validity remains unverified.

Original Registry observation times unavailable for this replay.

## Review checks

Conservative availability model. The fault budget is floor((N − 1) / 3). Model departing nodes unavailable in the before-state and incoming nodes still synchronizing in the proposed state. The smaller margin applies. A margin below one triggers a warning. These assumptions do not establish actual availability or liveness.

### Step 1 · Proposal #990011

Add and Remove are disjoint · Add duplicates 0 · Remove duplicates 0 · Membership preconditions · Established within the checked membership scope

Warning · zero margin. One further fault would exceed the modeled budget

- Duplicate Add principals · none

- Duplicate Remove principals · none

- Overlapping principals · none

- 5ag63-q3yke-ba · Before · 13 members, budget 4, modeled unavailable 4, remaining 0 · Proposed · 13 members, budget 4, modeled unavailable 4, remaining 0

Governance check incomplete · 0 references found

- Governance source uxrrr-q7777-77774-qaaaq-cai · 4 admitted source reads

- Discovery observed 2026-11-27 21:03:03.743 UTC to 2026-11-27 21:03:03.743 UTC

- Pagination complete · 2 pages · oldest listed #990011 · Open 2 · Adopted awaiting execution 0

- Title, summary and supported motion text checked for 2 proposals · Supported actions decoded 1 · Hydrated 1 · Lifecycle changed 0

- Unsupported actions 0 · Missing payloads 1 · Malformed payloads 0 · Omitted findings 0

- Proposal #990012 has no available executable payload.

## Map

![Map of registered node locations for the selected comparison](map.png)

Add (green) · Remove (red) · Unchanged (blue). 17 unique nodes across both states · 17/17 located. Positions use the registered data-center coordinates. The dotted halo indicates multiple node identities at the same coordinates.

Natural Earth map-unit boundaries are cartographic. Country shading uses recorded membership groups. Green shows increases and red shows decreases. A dashed border marks a country falling to zero. Small squares mark represented map units too small to see at the current zoom.

Unmatched recorded country labels remain in the distribution.

Changed sites · fixture-0 · 7 nodes · fixture-1 · 6 nodes

## Node changes

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
| Remove | [kk3lb-f3yae-ba](https://dashboard.internetcomputer.org/network/nodes/kk3lb-f3yae-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
| Remove | [pgn6g-vdyai-ba](https://dashboard.internetcomputer.org/network/nodes/pgn6g-vdyai-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
| Remove | [mcane-flyam-ba](https://dashboard.internetcomputer.org/network/nodes/mcane-flyam-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
| Remove | [f7auj-utyaq-ba](https://dashboard.internetcomputer.org/network/nodes/f7auj-utyaq-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
| Add | [2uxky-wdyby-ba](https://dashboard.internetcomputer.org/network/nodes/2uxky-wdyby-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
| Add | [zq2z2-glyb4-ba](https://dashboard.internetcomputer.org/network/nodes/zq2z2-glyb4-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
| Add | [afxzh-b3yca-ba](https://dashboard.internetcomputer.org/network/nodes/afxzh-b3yca-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
| Add | [db2kf-rtyce-ba](https://dashboard.internetcomputer.org/network/nodes/db2kf-rtyce-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |

<details>
<summary>Other Nodes (9)</summary>

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
|  | [g3nhl-e3yau-ba](https://dashboard.internetcomputer.org/network/nodes/g3nhl-e3yau-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
|  | [dx3sm-udyay-ba](https://dashboard.internetcomputer.org/network/nodes/dx3sm-udyay-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
|  | [atwbo-elya4-ba](https://dashboard.internetcomputer.org/network/nodes/atwbo-elya4-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
|  | [qn2ax-xtyba-ba](https://dashboard.internetcomputer.org/network/nodes/qn2ax-xtyba-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
|  | [tjxtv-h3ybe-ba](https://dashboard.internetcomputer.org/network/nodes/tjxtv-h3ybe-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
|  | [wfbgs-xdybi-ba](https://dashboard.internetcomputer.org/network/nodes/wfbgs-xdybi-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
|  | [vbmvq-hlybm-ba](https://dashboard.internetcomputer.org/network/nodes/vbmvq-hlybm-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
|  | [44mm5-wtybq-ba](https://dashboard.internetcomputer.org/network/nodes/44mm5-wtybq-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
|  | [7yb77-g3ybu-ba](https://dashboard.internetcomputer.org/network/nodes/7yb77-g3ybu-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |

</details>

## Decentralisation

Arrows show before → proposed; a single value is unchanged.

### Different groups represented

How many different registered groups have at least one member in this subnet?

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 1 | 2 | 2 | 2 | 2 | 2 |

### Largest group size

The most subnet nodes sharing one value, such as one provider or one country label. Several groups may tie.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 13 | 7 | 7 | 7 | 7 | 7 |

### Nakamoto coefficients

How many of the largest registered groups together contain more than one-third of the subnet's nodes? Each state uses floor(N / 3) + 1. Recorded groups do not establish independent ownership, subnet safety, execution validity or Target Topology compliance.

Node threshold: 5.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 1 | 1 | 1 | 1 | 1 | 1 |

### Distances between registered node locations

Straight-line geographic distances calculated from registered data-center coordinates, counting each pair of nodes once. These are not measured network latency or health.

| Shortest | Average | Longest |
| --- | --- | --- |
| 0 km | 3,585.0 km | 6,657.9 km |

78 of 78 pairs before and proposed.

No current Target Topology thresholds, exceptions or applicability are assumed.

<details>
<summary>Recorded country membership</summary>

| Country (recorded token) | Subnet members |
| --- | --- |
| Label 0 | 7 |
| Label 1 | 6 |

</details>

## Sources and calculation

Membership preview revision `b8f5268925ebdd8b34dee34bc9a099e5f12dbc1fbab8fcc372168aa77257cde9`.

Calculation input SHA-256 `329e40281e12f3fe07354a6cd06cbd25dc6de2b7f0850e8916e7163ed6d1ba33` · analysis v5.

The replicated calculation digest identifies the exact submitted evidence and scope. Source receipts identify the separate Registry and Governance observations.

- #990011 executable payload SHA-256 4b807560a6a8e75401798b83a5386b92ccfbdeebf490a0ae1292c43db4899ec1

<details>
<summary>Exact distance evidence in metres</summary>

| Distance | Before | Proposed |
| --- | --- | --- |
| Shortest | 0 | 0 |
| Average | 3584997 | 3584997 |
| Longest | 6657851 | 6657851 |

</details>

<details>
<summary>Registered geography evidence</summary>

| Data center | Original Registry region | Country token |
| --- | --- | --- |
| [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Fixture,Label 0,Synthetic site 0 | Label 0 |
| [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Fixture,Label 1,Synthetic site 1 | Label 1 |

</details>

<details>
<summary>Session source receipts (44)</summary>

| Method | Item | Canister | Fixture capture time | Reply SHA-256 or issue |
| --- | --- | --- | --- | --- |
| get\_proposal\_info | 990011 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | 548a0cd79052e5e6386fb93f7bc44a6cb720b22ff2774e07c4f28ba2fa484db8 |
| get\_latest\_version | Registry head | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | c0bffeaab8e16948afec4ac6e56088d8072a68d0788301b53e60560e8d85ce58 |
| get\_value | subnet\_list | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | 40061793c7ab638a07e0263d0c9edc78271ddc35825f444a9714da4e659a47e1 |
| get\_value | subnet\_record\_5ag63-q3yke-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | f518a8db3a5cd45d6a3cb7f3338014b81b364561d521e4eaf8de2a9feb905d4e |
| get\_value | node\_record\_kk3lb-f3yae-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_pgn6g-vdyai-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_mcane-flyam-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_f7auj-utyaq-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_2uxky-wdyby-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_zq2z2-glyb4-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_afxzh-b3yca-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_db2kf-rtyce-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | api\_boundary\_node\_kk3lb-f3yae-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | e529d73779dbecacf4f438ddca5ffaf6acb7d5b8c21f4a2768d7cc15048628a8 |
| get\_value | api\_boundary\_node\_pgn6g-vdyai-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | 6fb04ee8ef77f75ca6de77bb0fe1ac9dc783fa5ee5eb63b1b5ccfa1d0f4796a5 |
| get\_value | api\_boundary\_node\_mcane-flyam-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | 3d1df03ab5598250df94d18e4ac38e78f9b3ab6c3aebc3532df3f25dabd74633 |
| get\_value | api\_boundary\_node\_f7auj-utyaq-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | de15154af0b9bf0ef9d96ea00a9f81c0bc45c7e5457a30b8bf9899366d24c725 |
| get\_value | api\_boundary\_node\_2uxky-wdyby-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | 258bb64fae2f80a40d71481d8f44c333a54cc4ca8dcd83843ef61a12f1aea69a |
| get\_value | api\_boundary\_node\_zq2z2-glyb4-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | aeeeebd00c4f208437fae3789190f505d411271857052979b81205b050c3dc1a |
| get\_value | api\_boundary\_node\_afxzh-b3yca-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | 4bb10a22d6ab34079337fd0b5ea9cbedf8f5271d7e9fc6f6c6a27f489ff9a196 |
| get\_value | api\_boundary\_node\_db2kf-rtyce-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | eca77d053773859288f509bb0a34795a27f820c95f8ce7555a5aedcc6adeb9e3 |
| get\_proposal\_info | 990011 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:58.209 UTC | 548a0cd79052e5e6386fb93f7bc44a6cb720b22ff2774e07c4f28ba2fa484db8 |
| get\_value | node\_record\_kk3lb-f3yae-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_pgn6g-vdyai-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_mcane-flyam-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_f7auj-utyaq-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_g3nhl-e3yau-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_dx3sm-udyay-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_atwbo-elya4-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_qn2ax-xtyba-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_tjxtv-h3ybe-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_wfbgs-xdybi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_vbmvq-hlybm-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_44mm5-wtybq-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_7yb77-g3ybu-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_2uxky-wdyby-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_zq2z2-glyb4-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_record\_afxzh-b3yca-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f |
| get\_value | node\_record\_db2kf-rtyce-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.063 UTC | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a |
| get\_value | node\_operator\_record\_d4h56-4c2fi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.952 UTC | b7a469fce576bc5f0ffe09c60c5c7547423ab90160a86d9f71c535df6364257e |
| get\_value | node\_operator\_record\_d3g3k-r23fi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:02:59.952 UTC | bc8572c5d088d87e16d73701f59a02e3135c91965012deab1a153bd0eebf3582 |
| get\_value | data\_center\_record\_fixture-0 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:03:00.673 UTC | 2463378715bdb8a06123a9dff29e19870852dce08d95c90b7a45ce15a11d81d6 |
| get\_value | data\_center\_record\_fixture-1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:03:00.673 UTC | 42df72beb94c88c8654c293d38c6fb24216ed0975ec211e7c21238bba1c1f80a |
| get\_value | nns\_subnet\_id | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:03:01.356 UTC | 4cdd267ab9320daa812408894fca044891acc034f7e60a0c6d05104eda09df85 |
| get\_proposal\_info | 990011 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-27 21:03:03.023 UTC | 548a0cd79052e5e6386fb93f7bc44a6cb720b22ff2774e07c4f28ba2fa484db8 |

</details>
