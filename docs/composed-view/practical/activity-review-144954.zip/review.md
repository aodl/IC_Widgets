# Proposal review · [#144954](https://dashboard.internetcomputer.org/proposal/144954)

Proposal #144954 · After proposal #144954 · Step 1 of 1

Subnet [tdb26-jop6k-aogll-7ltgs-eruif-6kk7m-qpktf-gdiqx-mxtrf-vb5e6-eqe](https://dashboard.internetcomputer.org/network/subnets/tdb26-jop6k-aogll-7ltgs-eruif-6kk7m-qpktf-gdiqx-mxtrf-vb5e6-eqe)

Disposable composition rehearsal · fixture evidence · Registry 66,013

## Summary

Replace one node at zh2 with one at sh1. The subnet remains at 40 nodes. zh2 loses its last subnet member. sh1 membership changes 2 → 3. Both changed nodes have the same registered provider.

40 members · Add 1 · Remove 1 · Unchanged 39

Target subnet checked; assignments in the other 95 listed subnets were not checked.

## Evidence scope

Pinned Registry version **66,013**. Governance checked after the selected comparisons.

- #144954 · Fixture status: Open · Local replay served 2026-11-28 11:25:29.505 UTC

- Proposed membership is conditional on the pinned evidence. Full execution validity remains unverified.

Original Registry observation times unavailable for this replay.

## Review checks

Conservative availability model. The fault budget is floor((N − 1) / 3). Model departing nodes unavailable in the before-state and incoming nodes still synchronizing in the proposed state. The smaller margin applies. A margin below one triggers a warning. The cumulative case keeps all earlier arrivals unavailable while they remain in the subnet. These conditional margins do not establish global assignment, execution validity or actual liveness.

### Step 1 · Proposal #144954

Add and Remove are disjoint · Add duplicates 0 · Remove duplicates 0 · Membership preconditions · Incoming assignments could not be established across the Registry roster

Conditional step margin · 12 additional faults tolerable · 13 would exceed the modeled budget

<details>
<summary>Instruction and margin arithmetic</summary>

- Duplicate Add principals · none
- Duplicate Remove principals · none
- Overlapping principals · none
- Individual step · tdb26-jop6k-aogll-7ltgs-eruif-6kk7m-qpktf-gdiqx-mxtrf-vb5e6-eqe · Before · 40 members, budget 13, modeled unavailable 1, remaining 12 · Proposed · 40 members, budget 13, modeled unavailable 1, remaining 12 · Limiting side: both states · Margin 12

</details>

Governance check incomplete · Refresh failed · another on-demand request is running

## Map

![Map of registered node locations for the selected comparison](map.png)

Add (green) · Remove (red) · Unchanged (blue). 41 unique nodes across both states · 41/41 located. Positions use the registered data-center coordinates. The dotted halo indicates multiple node identities at the same coordinates.

Natural Earth map-unit boundaries are cartographic. Country shading uses recorded membership groups. Green shows increases and red shows decreases. A dashed border marks a country falling to zero. Small squares mark represented map units too small to see at the current zoom.

Changed sites · sh1 · 2 → 3 nodes · zh2 · 1 → 0 nodes

## Node changes

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
| Remove | [tg4ec-b2g4p-h42kd-k7zvb-6rls2-i2q7l-gtr4h-ymr6v-rrez4-w6fao-oqe](https://dashboard.internetcomputer.org/network/nodes/tg4ec-b2g4p-h42kd-k7zvb-6rls2-i2q7l-gtr4h-ymr6v-rrez4-w6fao-oqe) | [zh2](https://dashboard.internetcomputer.org/network/centers/zh2) | Everyware | [bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe](https://dashboard.internetcomputer.org/network/provider/bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe) | s7dud-dfedw-dmrax-rjvop-5k4qw-htm4w-gj7ak-j2itz-txwwn-o5ymv-tae | 🇨🇭 Switzerland (CH) |
| Add | [kaoz3-4okcl-24amq-v5y4k-vim56-4njvo-fwvyk-v4grq-kuqum-7zm3p-4qe](https://dashboard.internetcomputer.org/network/nodes/kaoz3-4okcl-24amq-v5y4k-vim56-4njvo-fwvyk-v4grq-kuqum-7zm3p-4qe) | [sh1](https://dashboard.internetcomputer.org/network/centers/sh1) | Digital Realty | [bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe](https://dashboard.internetcomputer.org/network/provider/bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe) | lgp6d-brhlv-35izu-khc6p-rfszo-zdwng-xbtkh-xyvjg-y3due-7ha7t-uae | 🇸🇪 Sweden (SE) |

<details>
<summary>Other Nodes (39)</summary>

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
|  | [nuass-yihti-wszdr-r7qze-32dgz-osovf-pracd-hg5tt-mwlhf-rvuyq-4ae](https://dashboard.internetcomputer.org/network/nodes/nuass-yihti-wszdr-r7qze-32dgz-osovf-pracd-hg5tt-mwlhf-rvuyq-4ae) | [jb2](https://dashboard.internetcomputer.org/network/centers/jb2) | Africa Data Centres | [nmdd6-rouxw-55leh-wcbkn-kejit-njvje-p4s6e-v64d3-nlbjb-vipul-mae](https://dashboard.internetcomputer.org/network/provider/nmdd6-rouxw-55leh-wcbkn-kejit-njvje-p4s6e-v64d3-nlbjb-vipul-mae) | 3bohy-zygmq-6novb-wm65r-3k3y2-deh42-7emld-zhqo7-xl2oa-iextm-fae | 🇿🇦 South Africa (ZA) |
|  | [ncr4b-rasb7-tueb3-n4uos-5nxou-3wbxv-xmyt3-wfdsd-vu4b6-5x3cp-aqe](https://dashboard.internetcomputer.org/network/nodes/ncr4b-rasb7-tueb3-n4uos-5nxou-3wbxv-xmyt3-wfdsd-vu4b6-5x3cp-aqe) | [ld1](https://dashboard.internetcomputer.org/network/centers/ld1) | Latitude.sh | [i3cfo-s2tgu-qe5ym-wk7e6-y7ura-pptgu-kevuf-2feh7-z4enq-5hz4s-mqe](https://dashboard.internetcomputer.org/network/provider/i3cfo-s2tgu-qe5ym-wk7e6-y7ura-pptgu-kevuf-2feh7-z4enq-5hz4s-mqe) | raiov-7se2a-qvvut-fosrr-ewckg-wwvx5-yiyih-msga4-kibn2-tel4j-uae | 🇬🇧 United Kingdom (UK) |
|  | [jyh32-azcnn-mwosu-urewl-m3pyx-6pmlq-lu5fu-vqjyl-gwx3j-zqrjr-gae](https://dashboard.internetcomputer.org/network/nodes/jyh32-azcnn-mwosu-urewl-m3pyx-6pmlq-lu5fu-vqjyl-gwx3j-zqrjr-gae) | [bu1](https://dashboard.internetcomputer.org/network/centers/bu1) | M247 | [i7dto-bgkj2-xo5dx-cyrb7-zkk5y-q46eh-gz6iq-qkgyc-w4qte-scgtb-6ae](https://dashboard.internetcomputer.org/network/provider/i7dto-bgkj2-xo5dx-cyrb7-zkk5y-q46eh-gz6iq-qkgyc-w4qte-scgtb-6ae) | c5ssg-eh22p-pmsn6-fpjzj-k5nql-mx5mc-7gb4a-4klco-c4f37-ydnfp-bae | 🇷🇴 Romania (RO) |
|  | [yahq2-6rnmm-n7ubm-q76zd-256dl-5f7k6-jxx5l-njyo2-hl7tk-sqcet-6ae](https://dashboard.internetcomputer.org/network/nodes/yahq2-6rnmm-n7ubm-q76zd-256dl-5f7k6-jxx5l-njyo2-hl7tk-sqcet-6ae) | [ar1](https://dashboard.internetcomputer.org/network/centers/ar1) | SyT - Servicios y Telecomunicaciones S.A. | [s5nvr-ipdxf-xg6wd-ofacm-7tl4i-nwjzx-uulum-cugwb-kbpsa-wrsgs-cae](https://dashboard.internetcomputer.org/network/provider/s5nvr-ipdxf-xg6wd-ofacm-7tl4i-nwjzx-uulum-cugwb-kbpsa-wrsgs-cae) | 5p6xp-glfoz-fgh6d-4rx7e-hix7t-c4vcp-u2xhn-gv4mm-fkozw-6mntb-7qe | 🇦🇷 Argentina (AR) |
|  | [himck-kjpb3-eih7e-knfcr-tkz7f-qzx45-i6xwm-obvn7-fw2hv-2zuy7-aqe](https://dashboard.internetcomputer.org/network/nodes/himck-kjpb3-eih7e-knfcr-tkz7f-qzx45-i6xwm-obvn7-fw2hv-2zuy7-aqe) | [ge1](https://dashboard.internetcomputer.org/network/centers/ge1) | HighDC | [7ryes-jnj73-bsyu4-lo6h7-lbxk5-x4ien-lylws-5qwzl-hxd5f-xjh3w-mqe](https://dashboard.internetcomputer.org/network/provider/7ryes-jnj73-bsyu4-lo6h7-lbxk5-x4ien-lylws-5qwzl-hxd5f-xjh3w-mqe) | yngfj-akg4s-nectt-whzgk-5zqbw-z3e5u-zuycn-zqygi-xz4vt-244v6-zae | 🇨🇭 Switzerland (CH) |
|  | [gj6gc-mbslq-bt63y-72b7h-xs2xw-6vyuj-frvp3-tx375-dsqx5-wem6o-vqe](https://dashboard.internetcomputer.org/network/nodes/gj6gc-mbslq-bt63y-72b7h-xs2xw-6vyuj-frvp3-tx375-dsqx5-wem6o-vqe) | [lj2](https://dashboard.internetcomputer.org/network/centers/lj2) | Anonstake | [kos24-5xact-6aror-uofg2-tnvt6-dq3bk-c2c5z-jtptt-jbqvc-lmegy-qae](https://dashboard.internetcomputer.org/network/provider/kos24-5xact-6aror-uofg2-tnvt6-dq3bk-c2c5z-jtptt-jbqvc-lmegy-qae) | eu5wc-g7r7l-zzy2o-227af-hfvin-orflw-4vdlf-j7gks-n5wrj-zezt7-tqe | 🇸🇮 Slovenia (SI) |
|  | [jmuoq-7kbey-cbtmm-zlz6t-chwt6-dk7ly-d3jim-5nuu4-y5tou-l5egg-7qe](https://dashboard.internetcomputer.org/network/nodes/jmuoq-7kbey-cbtmm-zlz6t-chwt6-dk7ly-d3jim-5nuu4-y5tou-l5egg-7qe) | [bc1](https://dashboard.internetcomputer.org/network/centers/bc1) | Cyxtera | [7at4h-nhtvt-a4s55-jigss-wr2ha-ysxkn-e6w7x-7ggnm-qd3d5-ry66r-cae](https://dashboard.internetcomputer.org/network/provider/7at4h-nhtvt-a4s55-jigss-wr2ha-ysxkn-e6w7x-7ggnm-qd3d5-ry66r-cae) | feb2q-mgxwe-okz7r-juws2-mahg4-wflqu-oeflf-kvh4r-qaqit-hbqpg-uqe | 🇨🇦 Canada (CA) |
|  | [nf7qq-vkm72-lttne-dsnke-3x73z-ofybh-ogahy-vyvta-dgbny-s5dr7-qqe](https://dashboard.internetcomputer.org/network/nodes/nf7qq-vkm72-lttne-dsnke-3x73z-ofybh-ogahy-vyvta-dgbny-s5dr7-qqe) | [sj3](https://dashboard.internetcomputer.org/network/centers/sj3) | InfoObjects | [7ws2n-wqorv-vmo4m-5e222-n42c3-hk43s-ei3kp-4hpbn-xlkzo-jgv7i-tqe](https://dashboard.internetcomputer.org/network/provider/7ws2n-wqorv-vmo4m-5e222-n42c3-hk43s-ei3kp-4hpbn-xlkzo-jgv7i-tqe) | jtrpk-wokqg-aqmcn-esiq7-fip4e-dl7lv-iwdyj-cu5pm-wbg7i-4jl4t-wae | 🇺🇸 United States (US) |
|  | [5iihd-fkroy-ow5zp-hlvwz-bsgbl-mecta-kxubm-6adxr-ckcu6-prsus-fqe](https://dashboard.internetcomputer.org/network/nodes/5iihd-fkroy-ow5zp-hlvwz-bsgbl-mecta-kxubm-6adxr-ckcu6-prsus-fqe) | [hk4](https://dashboard.internetcomputer.org/network/centers/hk4) | hkntt | [cgmhq-c4zja-yov4u-zeyao-64ua5-idlhb-ezcgr-cultv-3vqjs-dhwo7-rqe](https://dashboard.internetcomputer.org/network/provider/cgmhq-c4zja-yov4u-zeyao-64ua5-idlhb-ezcgr-cultv-3vqjs-dhwo7-rqe) | aaxec-cijpz-vzdwe-546fi-vahtf-s2awa-ldn7q-mzl2j-gmvhz-56zlq-mqe | 🇭🇰 Hong Kong (HK) |
|  | [sekkk-e24lo-s2zu3-5ltyu-kbzqs-44bpv-klm7l-72g2n-z7zxu-2pqpu-pae](https://dashboard.internetcomputer.org/network/nodes/sekkk-e24lo-s2zu3-5ltyu-kbzqs-44bpv-klm7l-72g2n-z7zxu-2pqpu-pae) | [hk3](https://dashboard.internetcomputer.org/network/centers/hk3) | hkcolo | [4fedi-eu6ue-nd7ts-vnof5-hzg66-hgzl7-liy5n-3otyp-h7ipw-owycg-uae](https://dashboard.internetcomputer.org/network/provider/4fedi-eu6ue-nd7ts-vnof5-hzg66-hgzl7-liy5n-3otyp-h7ipw-owycg-uae) | 4lbqo-vgpoe-kemak-voout-777uo-kk74n-fnct3-pc4eg-3txi3-7cghf-rqe | 🇭🇰 Hong Kong (HK) |
|  | [gvm7l-ds4n6-vkyjn-gwalp-3vdo6-qfmq7-pxhu4-zvqcu-ozvb7-qz3gr-vqe](https://dashboard.internetcomputer.org/network/nodes/gvm7l-ds4n6-vkyjn-gwalp-3vdo6-qfmq7-pxhu4-zvqcu-ozvb7-qz3gr-vqe) | [tv1](https://dashboard.internetcomputer.org/network/centers/tv1) | Interhost | [6sq7t-knkul-fko6h-xzvnf-ktbvr-jhx7r-hapzr-kjlek-whugy-zt6ip-xqe](https://dashboard.internetcomputer.org/network/provider/6sq7t-knkul-fko6h-xzvnf-ktbvr-jhx7r-hapzr-kjlek-whugy-zt6ip-xqe) | lis4o-siuek-6zrm6-g5pkh-lswnt-ttsd4-henvb-d6mit-lgfpr-lynph-xae | 🇮🇱 Israel (IL) |
|  | [k2ovz-ptdmz-hzmkh-ntfqn-evhux-ktxz4-26jg6-qjjsa-rpgal-wkdjo-kqe](https://dashboard.internetcomputer.org/network/nodes/k2ovz-ptdmz-hzmkh-ntfqn-evhux-ktxz4-26jg6-qjjsa-rpgal-wkdjo-kqe) | [rg3](https://dashboard.internetcomputer.org/network/centers/rg3) | Nano | [diyay-s4rfq-xnx23-zczwi-nptra-5254n-e4zn6-p7tqe-vqhzr-sd4gd-bqe](https://dashboard.internetcomputer.org/network/provider/diyay-s4rfq-xnx23-zczwi-nptra-5254n-e4zn6-p7tqe-vqhzr-sd4gd-bqe) | bftbl-quva3-hsn2r-qsjde-goegh-rupku-gb7xx-utj6e-lswl4-hclva-bqe | 🇱🇻 Latvia (LV) |
|  | [ulhxy-qlokv-5iual-yizlo-dtlmi-aavz5-bi7ez-kjwqz-la64z-cxjuk-fae](https://dashboard.internetcomputer.org/network/nodes/ulhxy-qlokv-5iual-yizlo-dtlmi-aavz5-bi7ez-kjwqz-la64z-cxjuk-fae) | [br2](https://dashboard.internetcomputer.org/network/centers/br2) | AtlasEdge | [rbn2y-6vfsb-gv35j-4cyvy-pzbdu-e5aum-jzjg6-5b4n5-vuguf-ycubq-zae](https://dashboard.internetcomputer.org/network/provider/rbn2y-6vfsb-gv35j-4cyvy-pzbdu-e5aum-jzjg6-5b4n5-vuguf-ycubq-zae) | oorkg-ilned-36bwb-vyprm-56g55-hp6xq-gucq3-fmn2i-44a4e-txzlp-gqe | 🇧🇪 Belgium (BE) |
|  | [lxgqb-dlqzi-schn4-i2mha-qh6re-eq3c2-3k6cn-oqumg-jkmgk-d4gex-3qe](https://dashboard.internetcomputer.org/network/nodes/lxgqb-dlqzi-schn4-i2mha-qh6re-eq3c2-3k6cn-oqumg-jkmgk-d4gex-3qe) | [cm1](https://dashboard.internetcomputer.org/network/centers/cm1) | OrionStellar | [eybf4-6t6bb-unfb2-h2hhn-rrfi2-cd2vs-phksn-jdmbn-i463m-4lzds-vqe](https://dashboard.internetcomputer.org/network/provider/eybf4-6t6bb-unfb2-h2hhn-rrfi2-cd2vs-phksn-jdmbn-i463m-4lzds-vqe) | ywjtr-pq5wc-m6foq-tyxvk-2a3wc-dlg3k-aaebf-6rk2d-5yvn7-tf743-gqe | 🇱🇰 Sri Lanka (LK) |
|  | [4mfcc-d3te7-zk2in-n5hm2-tcquv-bgc2e-obpbh-xp5jc-7boqr-oidte-jqe](https://dashboard.internetcomputer.org/network/nodes/4mfcc-d3te7-zk2in-n5hm2-tcquv-bgc2e-obpbh-xp5jc-7boqr-oidte-jqe) | [hk1](https://dashboard.internetcomputer.org/network/centers/hk1) | Unicom | [g2ax6-jrkmb-3zuh3-jibtb-q5xoq-njrgo-5utbc-j2o7g-zfq2w-yyhky-dqe](https://dashboard.internetcomputer.org/network/provider/g2ax6-jrkmb-3zuh3-jibtb-q5xoq-njrgo-5utbc-j2o7g-zfq2w-yyhky-dqe) | z6cfb-dbya3-nh4pm-nyteq-76n7d-xzi27-tf3cg-t7sz7-244qt-6rnjy-3ae | 🇭🇰 Hong Kong (HK) |
|  | [w2sev-mtuls-aa7m5-cdjgi-5vipg-2jn7i-4awvf-o6suu-73ebs-sw5db-kqe](https://dashboard.internetcomputer.org/network/nodes/w2sev-mtuls-aa7m5-cdjgi-5vipg-2jn7i-4awvf-o6suu-73ebs-sw5db-kqe) | [pl2](https://dashboard.internetcomputer.org/network/centers/pl2) | Yotta | [zy4m7-z5mhs-zfkpl-zlsjl-blrbx-mvvmq-5z4zu-mf7eq-hhv7o-ezfro-3ae](https://dashboard.internetcomputer.org/network/provider/zy4m7-z5mhs-zfkpl-zlsjl-blrbx-mvvmq-5z4zu-mf7eq-hhv7o-ezfro-3ae) | 7rw6b-6r7qv-al3uk-rimg7-ifkjv-hettz-lhmly-t55g7-xrwac-25ayy-wae | 🇮🇳 India (IN) |
|  | [vysyd-tlwq5-f5vfi-kw2jc-ziylz-di2s5-sf4p3-iflm7-vyvjv-hz3b3-pae](https://dashboard.internetcomputer.org/network/nodes/vysyd-tlwq5-f5vfi-kw2jc-ziylz-di2s5-sf4p3-iflm7-vyvjv-hz3b3-pae) | [kr2](https://dashboard.internetcomputer.org/network/centers/kr2) | Gasan | [64xe5-tx2s3-4gjmj-pnozr-fejw2-77y5y-rhcjk-glnmx-62brf-qin5q-pqe](https://dashboard.internetcomputer.org/network/provider/64xe5-tx2s3-4gjmj-pnozr-fejw2-77y5y-rhcjk-glnmx-62brf-qin5q-pqe) | 5dwhe-vpbuf-zz5ml-ylu6k-7y2z2-36ywv-5e4wf-advxd-3endk-icvg4-cae | 🇰🇷 South Korea (KR) |
|  | [zatyv-4l26n-3lecc-xpeme-ul34o-yiye2-3d447-aiiz4-5pxtm-v44nh-cqe](https://dashboard.internetcomputer.org/network/nodes/zatyv-4l26n-3lecc-xpeme-ul34o-yiye2-3d447-aiiz4-5pxtm-v44nh-cqe) | [mb1](https://dashboard.internetcomputer.org/network/centers/mb1) | Posita.si | [wdjjk-blh44-lxm74-ojj43-rvgf4-j5rie-nm6xs-xvnuv-j3ptn-25t4v-6ae](https://dashboard.internetcomputer.org/network/provider/wdjjk-blh44-lxm74-ojj43-rvgf4-j5rie-nm6xs-xvnuv-j3ptn-25t4v-6ae) | 3xiew-2wo3x-tnbn2-o7kok-wwsnw-7koo2-gna5r-rlrt3-zotsh-dwpg6-kae | 🇸🇮 Slovenia (SI) |
|  | [isegs-i4akf-kb7st-hnqjn-4col7-qxpph-pncbs-25hiy-5pwsu-nyw3x-xae](https://dashboard.internetcomputer.org/network/nodes/isegs-i4akf-kb7st-hnqjn-4col7-qxpph-pncbs-25hiy-5pwsu-nyw3x-xae) | [kr1](https://dashboard.internetcomputer.org/network/centers/kr1) | KT | [r3yjn-kthmg-pfgmb-2fngg-5c7d7-t6kqg-wi37r-j7gy6-iee64-kjdja-jae](https://dashboard.internetcomputer.org/network/provider/r3yjn-kthmg-pfgmb-2fngg-5c7d7-t6kqg-wi37r-j7gy6-iee64-kjdja-jae) | iubpe-vrzpt-cdf5f-kkzhq-rgp63-dkbfo-fje7f-6aknf-jekzg-3s7tv-oae | 🇰🇷 South Korea (KR) |
|  | [6hvx2-ymemx-tmykh-vxyic-bgfhv-2lcmt-3oy4x-rysuf-rnerz-vqokw-sqe](https://dashboard.internetcomputer.org/network/nodes/6hvx2-ymemx-tmykh-vxyic-bgfhv-2lcmt-3oy4x-rysuf-rnerz-vqokw-sqe) | [nm1](https://dashboard.internetcomputer.org/network/centers/nm1) | Rivram | [ulyfm-vkxtj-o42dg-e4nam-l4tzf-37wci-ggntw-4ma7y-d267g-ywxi6-iae](https://dashboard.internetcomputer.org/network/provider/ulyfm-vkxtj-o42dg-e4nam-l4tzf-37wci-ggntw-4ma7y-d267g-ywxi6-iae) | mpmyf-juliu-5qwcu-ofamg-es7ug-4mjt4-w5lht-dbrfb-ualjm-hcwmn-pae | 🇮🇳 India (IN) |
|  | [5mpdi-v4qj2-64are-tbe6r-6335g-6tksh-c7uzq-w3xyz-o4p5g-rwnll-vqe](https://dashboard.internetcomputer.org/network/nodes/5mpdi-v4qj2-64are-tbe6r-6335g-6tksh-c7uzq-w3xyz-o4p5g-rwnll-vqe) | [ty3](https://dashboard.internetcomputer.org/network/centers/ty3) | Equinix | [sixix-2nyqd-t2k2v-vlsyz-dssko-ls4hl-hyij4-y7mdp-ja6cj-nsmpf-yae](https://dashboard.internetcomputer.org/network/provider/sixix-2nyqd-t2k2v-vlsyz-dssko-ls4hl-hyij4-y7mdp-ja6cj-nsmpf-yae) | a5glg-n6ul6-rkuc7-idthk-fb2fe-d5m75-4g4l7-22yko-h27pr-q3a7k-lae | 🇯🇵 Japan (JP) |
|  | [v6r7h-luxm5-nxusv-bvhek-sis7i-sitrx-ezprf-j2lp3-2tnlt-2m6yt-zae](https://dashboard.internetcomputer.org/network/nodes/v6r7h-luxm5-nxusv-bvhek-sis7i-sitrx-ezprf-j2lp3-2tnlt-2m6yt-zae) | [dr1](https://dashboard.internetcomputer.org/network/centers/dr1) | FiberState | [trxbq-wy5xi-3y27q-bkpaf-mhi2m-puexs-yatgt-nhwiy-dh6jy-rolw5-zqe](https://dashboard.internetcomputer.org/network/provider/trxbq-wy5xi-3y27q-bkpaf-mhi2m-puexs-yatgt-nhwiy-dh6jy-rolw5-zqe) | nhr3z-ekrj4-7usls-kmdbv-esy2j-3wvez-ck46k-qpdn6-i23c2-5xkgr-dae | 🇺🇸 United States (US) |
|  | [2nehn-z42p7-36s7j-qqcz6-sy5rb-euhte-necpl-egqsv-hdoph-gx7qd-6ae](https://dashboard.internetcomputer.org/network/nodes/2nehn-z42p7-36s7j-qqcz6-sy5rb-euhte-necpl-egqsv-hdoph-gx7qd-6ae) | [im1](https://dashboard.internetcomputer.org/network/centers/im1) | Manx Telecom | [rpfvr-s3kuw-xdqrr-pvuuj-hc7hl-olytw-yxlie-fmr74-sr572-6gdqx-iqe](https://dashboard.internetcomputer.org/network/provider/rpfvr-s3kuw-xdqrr-pvuuj-hc7hl-olytw-yxlie-fmr74-sr572-6gdqx-iqe) | 4isre-d3zxy-xpque-tagdf-xdzjp-hk7x3-szquu-kuwej-52cfy-f6jwc-zqe | 🇮🇲 Isle of Man (IM) |
|  | [3zfpk-du6xx-yg7j5-h7c5w-6rr7z-cmkbf-pfos7-lhu65-svdmj-co7nc-cae](https://dashboard.internetcomputer.org/network/nodes/3zfpk-du6xx-yg7j5-h7c5w-6rr7z-cmkbf-pfos7-lhu65-svdmj-co7nc-cae) | [sg3](https://dashboard.internetcomputer.org/network/centers/sg3) | Racks Central | [x7uok-pi537-itm37-unjn3-ewkze-kuetg-kptap-nuqak-auq7z-tn5ey-dqe](https://dashboard.internetcomputer.org/network/provider/x7uok-pi537-itm37-unjn3-ewkze-kuetg-kptap-nuqak-auq7z-tn5ey-dqe) | vicvb-nkzkt-tj2lz-yzzw4-gfcsj-3eggv-izdti-tarpt-fsojm-lgq22-wae | 🇸🇬 Singapore (SG) |
|  | [2ftux-ivgjc-t4i2d-lq5hs-myjdg-3h2pz-l2ddl-nsxfc-wlaq7-fkbc5-6ae](https://dashboard.internetcomputer.org/network/nodes/2ftux-ivgjc-t4i2d-lq5hs-myjdg-3h2pz-l2ddl-nsxfc-wlaq7-fkbc5-6ae) | [sl1](https://dashboard.internetcomputer.org/network/centers/sl1) | Megazone Cloud | [4dibr-2alzr-h6kva-bvwn2-yqgsl-o577t-od46o-v275p-a2zov-tcw4f-eae](https://dashboard.internetcomputer.org/network/provider/4dibr-2alzr-h6kva-bvwn2-yqgsl-o577t-od46o-v275p-a2zov-tcw4f-eae) | ukji3-ju5bx-ty5r7-qwk4p-eobil-isp26-fsomg-44kwf-j4ew7-ozkqy-wqe | 🇰🇷 South Korea (KR) |
|  | [nj7re-dvkal-yq25a-opp2g-5y3qy-3ena4-opd5j-22uir-eaakx-ljk7k-6ae](https://dashboard.internetcomputer.org/network/nodes/nj7re-dvkal-yq25a-opp2g-5y3qy-3ena4-opd5j-22uir-eaakx-ljk7k-6ae) | [nd1](https://dashboard.internetcomputer.org/network/centers/nd1) | Marvelous Web3 DC | [pa5mu-yxsey-b4yrk-bodka-dhjnm-a3nx4-w2grw-3b766-ddr6e-nupu4-pqe](https://dashboard.internetcomputer.org/network/provider/pa5mu-yxsey-b4yrk-bodka-dhjnm-a3nx4-w2grw-3b766-ddr6e-nupu4-pqe) | ihcmc-o45dd-elg2s-ntnhr-l4c35-datk6-gsyeb-m77as-yjzd2-4qyxz-xqe | 🇮🇳 India (IN) |
|  | [tbzjp-lv2kb-xhel7-36r77-rfa3z-6iox2-c4ttr-cppwv-naxob-n3arn-fae](https://dashboard.internetcomputer.org/network/nodes/tbzjp-lv2kb-xhel7-36r77-rfa3z-6iox2-c4ttr-cppwv-naxob-n3arn-fae) | [im2](https://dashboard.internetcomputer.org/network/centers/im2) | Continent8 | [glrjs-2dbzh-owbdd-fpp5e-eweoz-nsuto-e3jmk-tl42c-wem4f-qfpfa-qqe](https://dashboard.internetcomputer.org/network/provider/glrjs-2dbzh-owbdd-fpp5e-eweoz-nsuto-e3jmk-tl42c-wem4f-qfpfa-qqe) | ylbc3-d72nf-cv76h-era7m-zefob-r5kyw-kvdtp-xq4ep-nthfy-ml5ua-iae | 🇮🇲 Isle of Man (IM) |
|  | [5veru-kf3gn-vjdxg-drid6-qpl2s-ojbxd-i73zf-kded7-7e4q3-5vuni-3qe](https://dashboard.internetcomputer.org/network/nodes/5veru-kf3gn-vjdxg-drid6-qpl2s-ojbxd-i73zf-kded7-7e4q3-5vuni-3qe) | [es1](https://dashboard.internetcomputer.org/network/centers/es1) | Adam | [w4buy-lgwzr-pccs7-huzhh-qqnws-rns75-iaoox-jolrm-xs2ra-vdu3o-2qe](https://dashboard.internetcomputer.org/network/provider/w4buy-lgwzr-pccs7-huzhh-qqnws-rns75-iaoox-jolrm-xs2ra-vdu3o-2qe) | 6zkgt-w7agd-kpvte-mia3x-sxucz-u2r7k-vfphb-tyhvv-i6hsm-h2ueo-uqe | 🇪🇸 Spain (ES) |
|  | [dw2ac-qodm4-snxe5-bnat5-2nu2z-mmogu-7gps7-z4gon-zadqs-3dbqh-pae](https://dashboard.internetcomputer.org/network/nodes/dw2ac-qodm4-snxe5-bnat5-2nu2z-mmogu-7gps7-z4gon-zadqs-3dbqh-pae) | [fm1](https://dashboard.internetcomputer.org/network/centers/fm1) | Hurricane Electric | [hk7eo-22zam-kqmsx-dtfbj-k5i6f-jg65h-micpf-2cztc-t2eqk-efgvx-vqe](https://dashboard.internetcomputer.org/network/provider/hk7eo-22zam-kqmsx-dtfbj-k5i6f-jg65h-micpf-2cztc-t2eqk-efgvx-vqe) | hoqyg-qkf6b-ulmyi-zfk6z-fuvlo-pekr6-goigz-qweij-xhghd-vibjl-jqe | 🇺🇸 United States (US) |
|  | [mae7q-ggnbj-xb52f-hvest-dgqoc-whvsq-yui5d-5cys2-zeold-l5ydx-oae](https://dashboard.internetcomputer.org/network/nodes/mae7q-ggnbj-xb52f-hvest-dgqoc-whvsq-yui5d-5cys2-zeold-l5ydx-oae) | [bn1](https://dashboard.internetcomputer.org/network/centers/bn1) | Master Internet | [efem5-kmwaw-xose7-zzhgg-6bfif-twmcw-csg7a-lmqvn-wrdou-mjwlb-vqe](https://dashboard.internetcomputer.org/network/provider/efem5-kmwaw-xose7-zzhgg-6bfif-twmcw-csg7a-lmqvn-wrdou-mjwlb-vqe) | zc635-ppr46-ap6eg-pghtn-wtnxz-6czvv-a4uxm-adjgb-wtoh4-2ddnl-uae | 🇨🇿 Czechia (CZ) |
|  | [24fcm-3onfs-cykax-al4jb-gvdd3-u76zl-ht6ef-hcsbc-xwf54-xbrym-xae](https://dashboard.internetcomputer.org/network/nodes/24fcm-3onfs-cykax-al4jb-gvdd3-u76zl-ht6ef-hcsbc-xwf54-xbrym-xae) | [bt1](https://dashboard.internetcomputer.org/network/centers/bt1) | Baltneta | [4jjya-hlyyc-s766p-fd6gr-d6tvv-vo3ah-j5ptx-i73gw-mwgyd-rw6w2-rae](https://dashboard.internetcomputer.org/network/provider/4jjya-hlyyc-s766p-fd6gr-d6tvv-vo3ah-j5ptx-i73gw-mwgyd-rw6w2-rae) | mbnsu-w4xfc-pmdok-r2lwo-wxfr4-gigu5-4idcm-5uuuy-znvby-biiny-jqe | 🇱🇹 Lithuania (LT) |
|  | [u4zo2-i6nsc-mowwj-lf6az-s6rdo-caskt-a6yx6-fke5w-qyezs-lyqvn-tqe](https://dashboard.internetcomputer.org/network/nodes/u4zo2-i6nsc-mowwj-lf6az-s6rdo-caskt-a6yx6-fke5w-qyezs-lyqvn-tqe) | [sc1](https://dashboard.internetcomputer.org/network/centers/sc1) | NEXTDC | [unqqg-no4b2-vbyad-ytik2-t3vly-3e57q-aje2t-sjb5l-bd4ke-chggn-uqe](https://dashboard.internetcomputer.org/network/provider/unqqg-no4b2-vbyad-ytik2-t3vly-3e57q-aje2t-sjb5l-bd4ke-chggn-uqe) | f3toa-2qbnz-67mnl-ws76t-asi36-oz7vd-w5xjx-u5n75-jchls-uhioe-6qe | 🇦🇺 Australia (AU) |
|  | [anudy-m6vfi-lphxb-sazpy-la4ti-2hriw-c67ny-butfn-axcel-otvuh-oqe](https://dashboard.internetcomputer.org/network/nodes/anudy-m6vfi-lphxb-sazpy-la4ti-2hriw-c67ny-butfn-axcel-otvuh-oqe) | [mtl1](https://dashboard.internetcomputer.org/network/centers/mtl1) | Leaseweb | [7uioy-xitfw-yqcko-5gpya-3lpsw-dw7zt-dyyyf-wfqif-jvi76-fdbkg-cqe](https://dashboard.internetcomputer.org/network/provider/7uioy-xitfw-yqcko-5gpya-3lpsw-dw7zt-dyyyf-wfqif-jvi76-fdbkg-cqe) | ueggl-7wvx2-2eezj-mgjrg-w6tmy-ngmye-xxbwu-gumli-hdf7u-zzpng-3ae | 🇨🇦 Canada (CA) |
|  | [lh2af-66zso-76kqu-d57ag-jca5d-yvmfo-rcabh-ptlvj-ltfdf-kyg6q-lqe](https://dashboard.internetcomputer.org/network/nodes/lh2af-66zso-76kqu-d57ag-jca5d-yvmfo-rcabh-ptlvj-ltfdf-kyg6q-lqe) | [li2](https://dashboard.internetcomputer.org/network/centers/li2) | Edgoo Networks | [mjnyf-lzqq6-s7fzb-62rqm-xzvge-5oa26-humwp-dvwxp-jxxkf-hoel7-fqe](https://dashboard.internetcomputer.org/network/provider/mjnyf-lzqq6-s7fzb-62rqm-xzvge-5oa26-humwp-dvwxp-jxxkf-hoel7-fqe) | nvocp-jlbys-d44wi-od3pv-iws4n-2nll3-73hqk-koh72-3obvg-kt5v3-fae | 🇵🇹 Portugal (PT) |
|  | [urnku-x7qn7-gt2mu-kueib-duqoz-xcdgj-hsnwl-5q32r-w3vqp-on6lq-gae](https://dashboard.internetcomputer.org/network/nodes/urnku-x7qn7-gt2mu-kueib-duqoz-xcdgj-hsnwl-5q32r-w3vqp-on6lq-gae) | [ct2](https://dashboard.internetcomputer.org/network/centers/ct2) | Teraco | [py2kr-ipr2p-ryh66-x3a3v-5ts6u-7rfhf-alkna-ueffh-hz5ox-lt6du-qqe](https://dashboard.internetcomputer.org/network/provider/py2kr-ipr2p-ryh66-x3a3v-5ts6u-7rfhf-alkna-ueffh-hz5ox-lt6du-qqe) | x7fjr-ngws7-jpjtq-e3c7s-735uk-gyusv-ppoeh-n4xhg-fwjck-um6pf-fae | 🇿🇦 South Africa (ZA) |
|  | [5gcqu-upr5b-ol3fj-vz273-3ov5j-s2dzp-d3n4o-c3rdz-rnhto-tovcx-zqe](https://dashboard.internetcomputer.org/network/nodes/5gcqu-upr5b-ol3fj-vz273-3ov5j-s2dzp-d3n4o-c3rdz-rnhto-tovcx-zqe) | [sh1](https://dashboard.internetcomputer.org/network/centers/sh1) | Digital Realty | [bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe](https://dashboard.internetcomputer.org/network/provider/bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe) | lgp6d-brhlv-35izu-khc6p-rfszo-zdwng-xbtkh-xyvjg-y3due-7ha7t-uae | 🇸🇪 Sweden (SE) |
|  | [oxevh-yptgl-yzu2p-w6dyn-lr6jc-b2xaq-aatz2-yyfot-hm4pr-ucvh6-gae](https://dashboard.internetcomputer.org/network/nodes/oxevh-yptgl-yzu2p-w6dyn-lr6jc-b2xaq-aatz2-yyfot-hm4pr-ucvh6-gae) | [zh5](https://dashboard.internetcomputer.org/network/centers/zh5) | Green.ch | [hzqcb-iiagd-4erjo-qn7rq-syqro-zztl6-cpble-atnkd-2c6bg-bxjoa-qae](https://dashboard.internetcomputer.org/network/provider/hzqcb-iiagd-4erjo-qn7rq-syqro-zztl6-cpble-atnkd-2c6bg-bxjoa-qae) | ap2qh-n5jrf-vpjj6-i5pap-qxnhr-4tnar-yodpw-kh6fy-c5w4z-gibij-5ae | 🇨🇭 Switzerland (CH) |
|  | [q4ksz-lpvfy-ikkem-wyuaa-abopq-nmu5k-ovh6h-xfoqk-hx3x3-g2bk6-4qe](https://dashboard.internetcomputer.org/network/nodes/q4ksz-lpvfy-ikkem-wyuaa-abopq-nmu5k-ovh6h-xfoqk-hx3x3-g2bk6-4qe) | [jb3](https://dashboard.internetcomputer.org/network/centers/jb3) | Xneelo | [mme7u-zxs3z-jq3un-fbaly-nllcz-toct2-l2kp3-larrb-gti4r-u2bmo-dae](https://dashboard.internetcomputer.org/network/provider/mme7u-zxs3z-jq3un-fbaly-nllcz-toct2-l2kp3-larrb-gti4r-u2bmo-dae) | ymenq-4sr5h-3imm6-kjjw6-2knuy-ntmlu-oqf5k-vdnzv-z427q-gqdot-sae | 🇿🇦 South Africa (ZA) |
|  | [uafcv-c76tx-jzddu-wxygw-4yzkm-nyr7u-iwk57-bwind-wmupb-2wos6-4qe](https://dashboard.internetcomputer.org/network/nodes/uafcv-c76tx-jzddu-wxygw-4yzkm-nyr7u-iwk57-bwind-wmupb-2wos6-4qe) | [sh1](https://dashboard.internetcomputer.org/network/centers/sh1) | Digital Realty | [bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe](https://dashboard.internetcomputer.org/network/provider/bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe) | lgp6d-brhlv-35izu-khc6p-rfszo-zdwng-xbtkh-xyvjg-y3due-7ha7t-uae | 🇸🇪 Sweden (SE) |

</details>

## Decentralisation

Arrows show before → proposed; a single value is unchanged.

### Different groups represented

How many different registered groups have at least one member in this subnet?

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 6 | 24 | 39 → 38 | 39 → 38 | 38 | 39 → 38 |

### Largest group size

The most subnet nodes sharing one value, such as one provider or one country label. Several groups may tie.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 17 | 3 | 2 → 3 | 2 → 3 | 3 | 2 → 3 |

### Nakamoto coefficients

How many of the largest registered groups together contain more than one-third of the subnet's nodes? Each state uses floor(N / 3) + 1. Recorded groups do not establish independent ownership, subnet safety, execution validity or Target Topology compliance.

Node threshold: 14.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 1 | 5 | 13 → 12 | 13 → 12 | 12 | 13 → 12 |

### Distances between registered node locations

Straight-line geographic distances calculated from registered data-center coordinates, counting each pair of nodes once. These are not measured network latency or health.

| Shortest | Average | Longest |
| --- | --- | --- |
| 0 km | 7,367.0 km → 7,361.8 km | 19,461.4 km |

780 of 780 pairs before and proposed.

No current Target Topology thresholds, exceptions or applicability are assumed.

<details>
<summary>Recorded country membership</summary>

| Country (recorded token) | Subnet members |
| --- | --- |
| 🇦🇷 Argentina (AR) | 1 |
| 🇦🇺 Australia (AU) | 1 |
| 🇧🇪 Belgium (BE) | 1 |
| 🇨🇦 Canada (CA) | 2 |
| 🇨🇭 Switzerland (CH) | 3 → 2 |
| 🇨🇿 Czechia (CZ) | 1 |
| 🇪🇸 Spain (ES) | 1 |
| 🇭🇰 Hong Kong (HK) | 3 |
| 🇮🇱 Israel (IL) | 1 |
| 🇮🇲 Isle of Man (IM) | 2 |
| 🇮🇳 India (IN) | 3 |
| 🇯🇵 Japan (JP) | 1 |
| 🇰🇷 South Korea (KR) | 3 |
| 🇱🇰 Sri Lanka (LK) | 1 |
| 🇱🇹 Lithuania (LT) | 1 |
| 🇱🇻 Latvia (LV) | 1 |
| 🇵🇹 Portugal (PT) | 1 |
| 🇷🇴 Romania (RO) | 1 |
| 🇸🇪 Sweden (SE) | 2 → 3 |
| 🇸🇬 Singapore (SG) | 1 |
| 🇸🇮 Slovenia (SI) | 2 |
| 🇬🇧 United Kingdom (UK) | 1 |
| 🇺🇸 United States (US) | 3 |
| 🇿🇦 South Africa (ZA) | 3 |

</details>

## Sources and calculation

Membership preview revision `9939de336b68d593d1d85ef127188bc198c536a25e026d97942981db896e4ee8`.

Calculation input SHA-256 `d36e52a6af1396a70933c3a3f0c43d745a4a55d7dd4d2b112fbefbf7071e698a` · analysis v5.

The replicated calculation digest identifies the exact submitted evidence and scope. Source receipts identify the separate Registry and Governance observations.

- #144954 executable payload SHA-256 f2875737ce603f9f03b65366f23abd880fdba50e42e7f685ee2dbfb3815db37b

<details>
<summary>Exact distance evidence in metres</summary>

| Distance | Before | Proposed |
| --- | --- | --- |
| Shortest | 0 | 0 |
| Average | 7367029 | 7361847 |
| Longest | 19461421 | 19461421 |

</details>

<details>
<summary>Registered geography evidence</summary>

| Data center | Original Registry region | Country token |
| --- | --- | --- |
| [zh2](https://dashboard.internetcomputer.org/network/centers/zh2) | Europe,CH,Zurich | CH |
| [sh1](https://dashboard.internetcomputer.org/network/centers/sh1) | Europe,SE,Stockholm | SE |
| [jb2](https://dashboard.internetcomputer.org/network/centers/jb2) | Africa,ZA,Gauteng | ZA |
| [ld1](https://dashboard.internetcomputer.org/network/centers/ld1) | Europe,UK,London | UK |
| [bu1](https://dashboard.internetcomputer.org/network/centers/bu1) | Europe,RO,Bucuresti | RO |
| [ar1](https://dashboard.internetcomputer.org/network/centers/ar1) | South America,AR,CABA | AR |
| [ge1](https://dashboard.internetcomputer.org/network/centers/ge1) | Europe,CH,Geneva | CH |
| [lj2](https://dashboard.internetcomputer.org/network/centers/lj2) | Europe,SI,Ljubljana | SI |
| [bc1](https://dashboard.internetcomputer.org/network/centers/bc1) | North America,CA,British Columbia | CA |
| [sj3](https://dashboard.internetcomputer.org/network/centers/sj3) | North America,US,California | US |
| [hk4](https://dashboard.internetcomputer.org/network/centers/hk4) | Asia,HK,HongKong | HK |
| [hk3](https://dashboard.internetcomputer.org/network/centers/hk3) | Asia,HK,HongKong | HK |
| [tv1](https://dashboard.internetcomputer.org/network/centers/tv1) | Asia,IL,Tel Aviv | IL |
| [rg3](https://dashboard.internetcomputer.org/network/centers/rg3) | Europe,LV,Riga | LV |
| [br2](https://dashboard.internetcomputer.org/network/centers/br2) | Europe,BE,Brussels Capital | BE |
| [cm1](https://dashboard.internetcomputer.org/network/centers/cm1) | Asia,LK,Colombo | LK |
| [hk1](https://dashboard.internetcomputer.org/network/centers/hk1) | Asia,HK,HongKong | HK |
| [pl2](https://dashboard.internetcomputer.org/network/centers/pl2) | Asia,IN,Panvel | IN |
| [kr2](https://dashboard.internetcomputer.org/network/centers/kr2) | Asia,KR,Seoul | KR |
| [mb1](https://dashboard.internetcomputer.org/network/centers/mb1) | Europe,SI,Maribor | SI |
| [kr1](https://dashboard.internetcomputer.org/network/centers/kr1) | Asia,KR,Seoul | KR |
| [nm1](https://dashboard.internetcomputer.org/network/centers/nm1) | Asia,IN,Navi Mumbai | IN |
| [ty3](https://dashboard.internetcomputer.org/network/centers/ty3) | Asia,JP,Tokyo | JP |
| [dr1](https://dashboard.internetcomputer.org/network/centers/dr1) | North America,US,Utah | US |
| [im1](https://dashboard.internetcomputer.org/network/centers/im1) | Europe,IM,Douglas | IM |
| [sg3](https://dashboard.internetcomputer.org/network/centers/sg3) | Asia,SG,Singapore | SG |
| [sl1](https://dashboard.internetcomputer.org/network/centers/sl1) | Asia,KR,Seoul | KR |
| [nd1](https://dashboard.internetcomputer.org/network/centers/nd1) | Asia,IN,New Delhi | IN |
| [im2](https://dashboard.internetcomputer.org/network/centers/im2) | Europe,IM,Douglas | IM |
| [es1](https://dashboard.internetcomputer.org/network/centers/es1) | Europe,ES,Barcelona | ES |
| [fm1](https://dashboard.internetcomputer.org/network/centers/fm1) | North America,US,California | US |
| [bn1](https://dashboard.internetcomputer.org/network/centers/bn1) | Europe,CZ,South Moravian Region | CZ |
| [bt1](https://dashboard.internetcomputer.org/network/centers/bt1) | Europe,LT,Vilnius | LT |
| [sc1](https://dashboard.internetcomputer.org/network/centers/sc1) | Oceania,AU,Queensland | AU |
| [mtl1](https://dashboard.internetcomputer.org/network/centers/mtl1) | North America,CA,Quebec | CA |
| [li2](https://dashboard.internetcomputer.org/network/centers/li2) | Europe,PT,Lisbon | PT |
| [ct2](https://dashboard.internetcomputer.org/network/centers/ct2) | Africa,ZA,Cape Town | ZA |
| [zh5](https://dashboard.internetcomputer.org/network/centers/zh5) | Europe,CH,Zurich | CH |
| [jb3](https://dashboard.internetcomputer.org/network/centers/jb3) | Africa,ZA,Gauteng | ZA |

</details>

<details>
<summary>Membership and Registry source receipts (130)</summary>

| Evidence stage | ID | Method | Item | Canister | Observed at | Argument SHA-256 | Reply SHA-256 | Bytes | Rejection |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Membership preview · Governance | 1 | get\_proposal\_info | 144954 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:24.651 UTC | e933c506c524cb2d3d495bec82e7379a083b52eef47e44663678b2995852d003 | 92cc11a832f1c5c044ac4d0f11f81694e8598dce73824656b670f6a28503b07f | 12764 | — |
| Membership preview · Registry | 2 | get\_latest\_version | Registry head | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:24.651 UTC | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | 636fda49c6d3d56e23e8a2589939db06fa9d9a86b8a1b8420a7df4087f8167fa | 4 | — |
| Membership preview · Registry | 3 | get\_value | subnet\_list | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:24.651 UTC | e677037cf18e2b19728af57672d3f0cc512d4c064d0f7db139edd095f3f81954 | b1912c26f82f37f4cd16a8dbccedfdbccc18d12669c6a8a89da8f54f59574e21 | 2993 | — |
| Membership preview · Registry | 4 | get\_value | subnet\_record\_tdb26-jop6k-aogll-7ltgs-eruif-6kk7m-qpktf-gdiqx-mxtrf-vb5e6-eqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:24.651 UTC | b7f20f05a3c1ba75762d9d6fd943b050bbd9dfdc7436c23ba8b7e0951088e95e | 6497dae72639a74c9dd115f782052f1b6a6029eb34c0648789046b7fc0c4ab78 | 1720 | — |
| Membership preview · Registry | 5 | get\_value | node\_record\_tg4ec-b2g4p-h42kd-k7zvb-6rls2-i2q7l-gtr4h-ymr6v-rrez4-w6fao-oqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:24.651 UTC | 9791508728ecf67168ced63d49c087789842b19f3672943856d93200b99f6b9a | b8445d695505738896abbbb7f3544ac1a6273dfc77e5eddae2fc8c9350f8619c | 182 | — |
| Membership preview · Registry | 6 | get\_value | node\_record\_kaoz3-4okcl-24amq-v5y4k-vim56-4njvo-fwvyk-v4grq-kuqum-7zm3p-4qe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:24.651 UTC | bfd05d68947d1dc79ed505871fc0ae342c4a86152520254cde2ffd9becfefcb4 | cebac6b382243c305722ff194f6b6978d4601f69ee7bd85d236b7ff4644a4d0a | 184 | — |
| Membership preview · Registry | 7 | get\_value | api\_boundary\_node\_tg4ec-b2g4p-h42kd-k7zvb-6rls2-i2q7l-gtr4h-ymr6v-rrez4-w6fao-oqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:24.651 UTC | 33ecd1cc72686445fe8f60d53a7c3ee1a3c093e4aec4fc38604c295930aad4e3 | c279ba1472cf7394ef3bbe7bf0b0b7454aa4b09f3e805e83fc390d975243912d | 91 | — |
| Membership preview · Registry | 8 | get\_value | api\_boundary\_node\_kaoz3-4okcl-24amq-v5y4k-vim56-4njvo-fwvyk-v4grq-kuqum-7zm3p-4qe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:24.651 UTC | d9303812512d90fcc23d592c0ce38f73bcd5710ecdee270f36ac1dc4f037606e | 2cd7fe663030d5026cd4920952afc464df190c9d2cb140ab37cfa8391f2328d3 | 91 | — |
| Membership preview · Governance | 9 | get\_proposal\_info | 144954 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:24.651 UTC | e933c506c524cb2d3d495bec82e7379a083b52eef47e44663678b2995852d003 | 92cc11a832f1c5c044ac4d0f11f81694e8598dce73824656b670f6a28503b07f | 12764 | — |
| Registry enrichment · Nodes | 1 | get\_value | node\_record\_dw2ac-qodm4-snxe5-bnat5-2nu2z-mmogu-7gps7-z4gon-zadqs-3dbqh-pae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 80eac5772cc04c741c409f5d9a2feb605affde557502dafcae3150156b33ec76 | b2ed6444f420c18b1b374eceb243ffd426dc1d152afad7c193b21e20b32b9598 | 311 | — |
| Registry enrichment · Nodes | 2 | get\_value | node\_record\_himck-kjpb3-eih7e-knfcr-tkz7f-qzx45-i6xwm-obvn7-fw2hv-2zuy7-aqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 052003a07b1fb2f2fbeed315ce199c9bfec1d85f2ee97bd2e3a81327b462a6ab | 4a5354a55a96d2aa22ff6fbab737bc40fee212e342cc5aaa4aa6bdbffd2acf29 | 229 | — |
| Registry enrichment · Nodes | 3 | get\_value | node\_record\_tbzjp-lv2kb-xhel7-36r77-rfa3z-6iox2-c4ttr-cppwv-naxob-n3arn-fae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | f8188a88b0b79c0a188c2fc02d93552076d7289176774238dd59043bf4893a62 | 3f6862babab9c9758c7cde143669b9f8c6e0e1667b101900af1c50252e202b76 | 184 | — |
| Registry enrichment · Nodes | 4 | get\_value | node\_record\_nf7qq-vkm72-lttne-dsnke-3x73z-ofybh-ogahy-vyvta-dgbny-s5dr7-qqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 2f6771d43ee5b59b97a187b46348f5191315003636df7f771ac728404731d221 | a3223869f5113a5b02223c380955ff7da51c83aaaa82cb43a13e64fb1fd60bb1 | 178 | — |
| Registry enrichment · Nodes | 5 | get\_value | node\_record\_oxevh-yptgl-yzu2p-w6dyn-lr6jc-b2xaq-aatz2-yyfot-hm4pr-ucvh6-gae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 82b6d3dcdb7e1f5c5da2204dd6d2aeb874e75786e1503e4c8be00442f0c7a517 | 9e606e701558695a0d0c72b2729df9aa81ec7eab3aa57b9cae668d5eddf7dcb2 | 184 | — |
| Registry enrichment · Nodes | 6 | get\_value | node\_record\_v6r7h-luxm5-nxusv-bvhek-sis7i-sitrx-ezprf-j2lp3-2tnlt-2m6yt-zae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 41b68d236d7d591465a8d6a931354c4244e62bf95ab992c530dd4403d73cf8f5 | 02ef89ca2163b00bdafbf0eb516a4bcb88210707d475a376064180245e20e68f | 230 | — |
| Registry enrichment · Nodes | 7 | get\_value | node\_record\_urnku-x7qn7-gt2mu-kueib-duqoz-xcdgj-hsnwl-5q32r-w3vqp-on6lq-gae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 80ebf6e875741cdc744dd04e0ce90b7fe9636f8029b8f9164093f2b6a6844b13 | 3f885f8b984e1ab88631aac58bcee88a67a2442b923c9f9ed8a669aee00084d7 | 180 | — |
| Registry enrichment · Nodes | 8 | get\_value | node\_record\_sekkk-e24lo-s2zu3-5ltyu-kbzqs-44bpv-klm7l-72g2n-z7zxu-2pqpu-pae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 5439d1aae7c56b0858fb1cd88816dbc673b9e4d4ddbd31aed4a1fe7005f2558c | db6f23b78638161f3602d2ea52104e98b6c256f589224e01cbe7a4ce37d6ce38 | 176 | — |
| Registry enrichment · Nodes | 9 | get\_value | node\_record\_4mfcc-d3te7-zk2in-n5hm2-tcquv-bgc2e-obpbh-xp5jc-7boqr-oidte-jqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | ff489d62c7166eb6e8a6ef89970fd9cf26cb2dba895703381e37f362136d896c | 7805f87ed8a5c9111cf34882b1883b2e56eff3a0fd6b5db76db2c9f1948de2f5 | 174 | — |
| Registry enrichment · Nodes | 10 | get\_value | node\_record\_nj7re-dvkal-yq25a-opp2g-5y3qy-3ena4-opd5j-22uir-eaakx-ljk7k-6ae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 432c6e7138b65fe325dd240dfdad2fa9893e6d6010c54a7066ffee41cac92f10 | 0a76d24f32e605f86b1e3e079087e0b20256d0f091af598f91102726b858d91c | 244 | — |
| Registry enrichment · Nodes | 11 | get\_value | node\_record\_5veru-kf3gn-vjdxg-drid6-qpl2s-ojbxd-i73zf-kded7-7e4q3-5vuni-3qe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | a1afeb412e464cea987bf5acda1c33dba54df725437dcd82e806f8b27df9b555 | 7fc32d8c472532ee6292bfe30eca77b2361fb2f284b43ede7806994e3ff2e25c | 178 | — |
| Registry enrichment · Nodes | 12 | get\_value | node\_record\_nuass-yihti-wszdr-r7qze-32dgz-osovf-pracd-hg5tt-mwlhf-rvuyq-4ae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 6254473040c77d5e1cba24d87b04f329321ac5b955ef2e7c0332a8f9521c70fb | 7148b1b7d92a60a9028bea9cd78b6ffae868606dc8782f56eabee843439e2044 | 180 | — |
| Registry enrichment · Nodes | 13 | get\_value | node\_record\_uafcv-c76tx-jzddu-wxygw-4yzkm-nyr7u-iwk57-bwind-wmupb-2wos6-4qe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | a1f0c862351ff86930456b6de58906e8774dcfacb5c33361d3564825b7646da4 | ae18085ac8a0842c869a7268e0ba751a8b228094d33366291f72699428ff0a84 | 184 | — |
| Registry enrichment · Nodes | 14 | get\_value | node\_record\_3zfpk-du6xx-yg7j5-h7c5w-6rr7z-cmkbf-pfos7-lhu65-svdmj-co7nc-cae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 6f91b90dbb419e86c888abe199618315b40362d33e4d3a3e17b8c18f6814cf14 | 44ed81f18a86c81dcdb7f24faa39daa4ad8e6269a9e66c73dc0b7de8789c9224 | 182 | — |
| Registry enrichment · Nodes | 15 | get\_value | node\_record\_2nehn-z42p7-36s7j-qqcz6-sy5rb-euhte-necpl-egqsv-hdoph-gx7qd-6ae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 5f3b80172261476dd42b718ee9137c61c299e5a361915912364402f7da462083 | a0c46407f5c7dab32b1d5990741c1918bd7d370aef9a98df3269968cf1006a8b | 236 | — |
| Registry enrichment · Nodes | 16 | get\_value | node\_record\_ulhxy-qlokv-5iual-yizlo-dtlmi-aavz5-bi7ez-kjwqz-la64z-cxjuk-fae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 66d49c08f2eb6737d406ab402dccb9ca461da8589948a0c66d01c70da0caeafd | 6ba6c8fd1e6c37e3e2836f9b8f5fcb643bc23160ea86a54379f11d4be10b3b02 | 249 | — |
| Registry enrichment · Nodes | 17 | get\_value | node\_record\_vysyd-tlwq5-f5vfi-kw2jc-ziylz-di2s5-sf4p3-iflm7-vyvjv-hz3b3-pae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 2305f2f0a5741c76afb02d1bad0e90e6655098afe7ddd591271367244112f0f6 | c82d8ac4a711a23263aef2a7b3a80c2734de9394fd18951323ee36527938a892 | 249 | — |
| Registry enrichment · Nodes | 18 | get\_value | node\_record\_zatyv-4l26n-3lecc-xpeme-ul34o-yiye2-3d447-aiiz4-5pxtm-v44nh-cqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | d458e0f63f52e03fcde2ede0c287bd61e157f5679c28898b95834edaa8ed9bda | 68410a1fa5f9a82b430fba33993f9b3873fa7d439a35c481f9d3b4f052d788a1 | 182 | — |
| Registry enrichment · Nodes | 19 | get\_value | node\_record\_lh2af-66zso-76kqu-d57ag-jca5d-yvmfo-rcabh-ptlvj-ltfdf-kyg6q-lqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 2e81c0bef0b101eefc165f7f20e36bbd8e6cc3eee4746b120aa52cfbace16bb0 | 39c2495f0ba24a5959c325bdcfd34163c1a10cf45e37f21ee67fef18fb855dad | 186 | — |
| Registry enrichment · Nodes | 20 | get\_value | node\_record\_5gcqu-upr5b-ol3fj-vz273-3ov5j-s2dzp-d3n4o-c3rdz-rnhto-tovcx-zqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 0ae6a17ae575d9b04b41352d67b648ab23782464ab76ec4e22b0a03260b51efb | 0ef159818c57b363efb9dad357eab45899787175d09b8778bacc5d0823c4613f | 184 | — |
| Registry enrichment · Nodes | 21 | get\_value | node\_record\_lxgqb-dlqzi-schn4-i2mha-qh6re-eq3c2-3k6cn-oqumg-jkmgk-d4gex-3qe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 49c30149c4294b81a9dcb33fb729305bd0909a6c96b6686e3e1042943b2c1f49 | ea0c4047598314003fd03a361948af278190f38a0b99cf41e90abcd9648b10b7 | 182 | — |
| Registry enrichment · Nodes | 22 | get\_value | node\_record\_jyh32-azcnn-mwosu-urewl-m3pyx-6pmlq-lu5fu-vqjyl-gwx3j-zqrjr-gae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 04ecf97d2f1ac04a2f1c72bd4a73cf3b95ab1c28b7d724673eac34f3e1b60b8c | bf15b9a6e34c9ca55ea06258013eb4a9c79d84c14e45da9ec0f96555dae4e2bf | 178 | — |
| Registry enrichment · Nodes | 23 | get\_value | node\_record\_isegs-i4akf-kb7st-hnqjn-4col7-qxpph-pncbs-25hiy-5pwsu-nyw3x-xae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | 5bdff7f7f1d3dcf9c8cf7e5925c56c9cdfeecb5692f15d611c888fe15bc63d87 | 2fc0d2725eb69de30a49d509bdf4901375e01a397d6ba781a3d6c26642d18963 | 180 | — |
| Registry enrichment · Nodes | 24 | get\_value | node\_record\_k2ovz-ptdmz-hzmkh-ntfqn-evhux-ktxz4-26jg6-qjjsa-rpgal-wkdjo-kqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.437 UTC | f6ce9d8cd06eb11edd0b3ba33cd0deabcae05e8c51482e4bbdf471c43764c71a | 55b306bcfc9abdeec86c0036058c33f28c173dfc05b7fdfd1a1d28d982d69c24 | 178 | — |
| Registry enrichment · Nodes | 1 | get\_value | node\_record\_ncr4b-rasb7-tueb3-n4uos-5nxou-3wbxv-xmyt3-wfdsd-vu4b6-5x3cp-aqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | 4074398934e7f1d1cbdd4d435809672ed65a3aab645ef06dfd47ac1b59de999a | 70c9cca5c6e03c843f57d4dd0dc062e66faca84be7e122e132b20ed04f15e15d | 242 | — |
| Registry enrichment · Nodes | 2 | get\_value | node\_record\_yahq2-6rnmm-n7ubm-q76zd-256dl-5f7k6-jxx5l-njyo2-hl7tk-sqcet-6ae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | bc1dba9cff7bf943c7aa32ccaf2620e12fd929251c4bbef037d015eaa59de32b | 3227731ab991b283e816f97b298fa7e716559678fed2a82b0e9f69c6f6ee2c54 | 186 | — |
| Registry enrichment · Nodes | 3 | get\_value | node\_record\_w2sev-mtuls-aa7m5-cdjgi-5vipg-2jn7i-4awvf-o6suu-73ebs-sw5db-kqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | 6e281aea5f83c9e60368ca31c28f99d70977136e4b58d240dd02540761170d59 | 95d140eea7ac8d4d6cac715c41af4af6d8721f86397b4d448d56a19bf7d0eaeb | 180 | — |
| Registry enrichment · Nodes | 4 | get\_value | node\_record\_gvm7l-ds4n6-vkyjn-gwalp-3vdo6-qfmq7-pxhu4-zvqcu-ozvb7-qz3gr-vqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | b9491fe83311b3bb528ec1d336eac26f24e781a6118640370e1573843c72874f | a2fcf6e45e81ca923f8eab342ab8124d8ad54582f5bcc4a3bc4cce7aa3cdae87 | 186 | — |
| Registry enrichment · Nodes | 5 | get\_value | node\_record\_2ftux-ivgjc-t4i2d-lq5hs-myjdg-3h2pz-l2ddl-nsxfc-wlaq7-fkbc5-6ae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | a13b2be70597397178e6ada620029588c856495f070d23a2f2e2bf2504fc6543 | 13f7d9b1806a249ec31a7a2696b36dd8228dbfb0ae8dd5b6324858903ead06d7 | 176 | — |
| Registry enrichment · Nodes | 6 | get\_value | node\_record\_jmuoq-7kbey-cbtmm-zlz6t-chwt6-dk7ly-d3jim-5nuu4-y5tou-l5egg-7qe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | 03dbf8410ad8f89a1108ff80a6d5543dd6232f0b32f7ea5b4d8bfcf162033f9c | 4da5f76e8b130e187bb088191c38c23d36d30163312b8f8b6881a4ed1320d64b | 180 | — |
| Registry enrichment · Nodes | 7 | get\_value | node\_record\_5iihd-fkroy-ow5zp-hlvwz-bsgbl-mecta-kxubm-6adxr-ckcu6-prsus-fqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | 845b4d51f99149c6f305519af060dff313b379f2e2d63d3080e95ab8e7d27c9a | b1fc792d00e6422a5cec2f4e11b82e95f99548eb8f1465de06c98aecbf828416 | 172 | — |
| Registry enrichment · Nodes | 8 | get\_value | node\_record\_24fcm-3onfs-cykax-al4jb-gvdd3-u76zl-ht6ef-hcsbc-xwf54-xbrym-xae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | a3535ca7f9e6901205485cfba48bbee41b85caa4b2f73e91e89efa4eb8b6473a | d803a8120f8a8fa2a2ea81078f5dce4e5f283c274f4931aab4b967c1db71f51d | 180 | — |
| Registry enrichment · Nodes | 9 | get\_value | node\_record\_q4ksz-lpvfy-ikkem-wyuaa-abopq-nmu5k-ovh6h-xfoqk-hx3x3-g2bk6-4qe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | 03a03dc015611fd2f93da4532e60db2eb58276ff94f45adad994be73a4f5d429 | 78f67ffeb348c30ddf03074bbf420fb87882ce7599ce2c38f15bf9e93e384ece | 180 | — |
| Registry enrichment · Nodes | 10 | get\_value | node\_record\_u4zo2-i6nsc-mowwj-lf6az-s6rdo-caskt-a6yx6-fke5w-qyezs-lyqvn-tqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | 7856c0f382b615593ee23b70f69f8e5ceb281fa3bfc6fba5a3389e4a9ba7ef3a | 1b7a7799f7088d1e29ab08fe47dcca663f2f8bf8e39315b3a12b1a569763f352 | 180 | — |
| Registry enrichment · Nodes | 11 | get\_value | node\_record\_mae7q-ggnbj-xb52f-hvest-dgqoc-whvsq-yui5d-5cys2-zeold-l5ydx-oae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | bbb76cc07a4413bd48627012d983541185b3a40fbdb66ec257f82d9f0aa4ba15 | 272965f4afdb13dc610df507fbadf66d0eb8b36d35a5c0838e38ef68f14ce06d | 174 | — |
| Registry enrichment · Nodes | 12 | get\_value | node\_record\_6hvx2-ymemx-tmykh-vxyic-bgfhv-2lcmt-3oy4x-rysuf-rnerz-vqokw-sqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | ac0d11ba0afcb64c33666f74c23c44b896ebfcfa124d3d638b8f5e4bc521ceb9 | daac7a5b6a04b9f0ca4a7b60eae988a4e1dd83101f1f552388048b20c48716c4 | 178 | — |
| Registry enrichment · Nodes | 13 | get\_value | node\_record\_anudy-m6vfi-lphxb-sazpy-la4ti-2hriw-c67ny-butfn-axcel-otvuh-oqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | d48edb8abb85cea06f922032e3b1dbe826ab4162435c702eeb29f22685a3e215 | f06eac5e322a894b67a8775a0407795c8c6803ae5d741c5a00890bbef7c326dd | 180 | — |
| Registry enrichment · Nodes | 14 | get\_value | node\_record\_tg4ec-b2g4p-h42kd-k7zvb-6rls2-i2q7l-gtr4h-ymr6v-rrez4-w6fao-oqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | 9791508728ecf67168ced63d49c087789842b19f3672943856d93200b99f6b9a | b8445d695505738896abbbb7f3544ac1a6273dfc77e5eddae2fc8c9350f8619c | 182 | — |
| Registry enrichment · Nodes | 15 | get\_value | node\_record\_gj6gc-mbslq-bt63y-72b7h-xs2xw-6vyuj-frvp3-tx375-dsqx5-wem6o-vqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | 3466487c01fadaa553320136debf80753fc462922c98bba65dbb5dc358697c72 | 2b8bed7cd7f2c7f78d75b9996d7f77c9c160cbece4e9e15ed4000e623efb1aa2 | 178 | — |
| Registry enrichment · Nodes | 16 | get\_value | node\_record\_5mpdi-v4qj2-64are-tbe6r-6335g-6tksh-c7uzq-w3xyz-o4p5g-rwnll-vqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | e343afe95b7023e9a7c9ebfe31cdad17f6c005e306bc470728724eaa2f881c6e | de3aefd34289da838063c6a926eab9ed5c828339e2531bde56cabc5e10f4ef3a | 180 | — |
| Registry enrichment · Nodes | 17 | get\_value | node\_record\_kaoz3-4okcl-24amq-v5y4k-vim56-4njvo-fwvyk-v4grq-kuqum-7zm3p-4qe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:25.961 UTC | bfd05d68947d1dc79ed505871fc0ae342c4a86152520254cde2ffd9becfefcb4 | cebac6b382243c305722ff194f6b6978d4601f69ee7bd85d236b7ff4644a4d0a | 184 | — |
| Registry enrichment · Operators | 1 | get\_value | node\_operator\_record\_hoqyg-qkf6b-ulmyi-zfk6z-fuvlo-pekr6-goigz-qweij-xhghd-vibjl-jqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 2bf3e89d2d6ea64b2f68b473cc2dc8adc9fe6b3895ecc56c176dbac27125ab94 | 8a65500d77482cb7333b999e77d12d4c8f37c9bfdd5d4c902d431593db784280 | 111 | — |
| Registry enrichment · Operators | 2 | get\_value | node\_operator\_record\_yngfj-akg4s-nectt-whzgk-5zqbw-z3e5u-zuycn-zqygi-xz4vt-244v6-zae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | de00b9f65963878f98bb8897437f821b20d64f7c31468cd10dbecb9390c5d1b3 | ca9c6270a2eee12e05feddf03db98b6bf0b4a8fbf273f3fafd675530655505f2 | 111 | — |
| Registry enrichment · Operators | 3 | get\_value | node\_operator\_record\_ylbc3-d72nf-cv76h-era7m-zefob-r5kyw-kvdtp-xq4ep-nthfy-ml5ua-iae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | b39f93757a20b7a7167971cd3792adb4880e6ff0d4e39fc3d6d03c63954833b8 | 09d96901f2fdeef8c1268f1f40488620f22760ac23f423bcff9a478a640c6ac6 | 111 | — |
| Registry enrichment · Operators | 4 | get\_value | node\_operator\_record\_jtrpk-wokqg-aqmcn-esiq7-fip4e-dl7lv-iwdyj-cu5pm-wbg7i-4jl4t-wae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 6c4fd96bd0418d23b814821cb2af3cbff9b64fb951890b4e5111ffb731062ead | 062f7237a6310b21827142faa3d7003ae741febab3f65467e676bec3944e1d38 | 111 | — |
| Registry enrichment · Operators | 5 | get\_value | node\_operator\_record\_ap2qh-n5jrf-vpjj6-i5pap-qxnhr-4tnar-yodpw-kh6fy-c5w4z-gibij-5ae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 81c4708531be395840b39d74bd99fe01bd70fbb769f84e3dcf38b5423711b44d | 85e57f88f7fa918603e3bb726b6ce289c0a6dc39a27d1910ecaf3ae9bdf7a678 | 105 | — |
| Registry enrichment · Operators | 6 | get\_value | node\_operator\_record\_nhr3z-ekrj4-7usls-kmdbv-esy2j-3wvez-ck46k-qpdn6-i23c2-5xkgr-dae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 61fccc049e654b4b429f1e16e152b19caf38fddf970056fe10b9afa68ebc8cb0 | 72d3462750c6e49cc4bac5e25306f966e454a361dbae4ddbae63332329dba2b6 | 111 | — |
| Registry enrichment · Operators | 7 | get\_value | node\_operator\_record\_x7fjr-ngws7-jpjtq-e3c7s-735uk-gyusv-ppoeh-n4xhg-fwjck-um6pf-fae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | ec028d4211e92a4aedd639a9a7816ed96766d19fd29f3166836370e0e7e76ba6 | 21934e80f70a0c1e9f887e813b4acc79e9f6834c0f542ea4c986a203df2e7fa1 | 111 | — |
| Registry enrichment · Operators | 8 | get\_value | node\_operator\_record\_4lbqo-vgpoe-kemak-voout-777uo-kk74n-fnct3-pc4eg-3txi3-7cghf-rqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | a3b120a6585323f73f002e714fc2ea8ef738754986d1cfcb2b5e7792d588856b | 511f93491b3d951d199c0f81bdf188aac7f736db4740062d81a925dcacf95438 | 109 | — |
| Registry enrichment · Operators | 9 | get\_value | node\_operator\_record\_z6cfb-dbya3-nh4pm-nyteq-76n7d-xzi27-tf3cg-t7sz7-244qt-6rnjy-3ae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | c3b9a1647b337d1d4b4e27672fe20effd2a01df2dbd3a2096eb6707434b713d5 | 5e37a3d63b22bf305a4390e8157306363a2ee4941c9f7b94ba021e04e98e4b39 | 111 | — |
| Registry enrichment · Operators | 10 | get\_value | node\_operator\_record\_ihcmc-o45dd-elg2s-ntnhr-l4c35-datk6-gsyeb-m77as-yjzd2-4qyxz-xqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 878930f5f89044f6c7227cce6b6ec84b724084467262435d6ed71e6dab069326 | fdd676075bff66edb538b21b595af0db66770ef0b44a8ee599b8ba759318f407 | 109 | — |
| Registry enrichment · Operators | 11 | get\_value | node\_operator\_record\_6zkgt-w7agd-kpvte-mia3x-sxucz-u2r7k-vfphb-tyhvv-i6hsm-h2ueo-uqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 528fa0e78933b890340aae979c6ab5e11b78cbffa7cdd1bc9f5a22c6c77aee1b | c20e6288234b2e6b24d9a05d0d6ca5a17bbe55d9e2e3ced21b7ec0a15448b73d | 111 | — |
| Registry enrichment · Operators | 12 | get\_value | node\_operator\_record\_3bohy-zygmq-6novb-wm65r-3k3y2-deh42-7emld-zhqo7-xl2oa-iextm-fae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | fe9cb57d4fcbd9d896900a0c31e2bba3e3632532d21eac70df2d8a23b0769457 | 55f1550a690609159b3bdbc1d34f5c1a122b5c43252024d19d08f8f461ff4185 | 111 | — |
| Registry enrichment · Operators | 13 | get\_value | node\_operator\_record\_lgp6d-brhlv-35izu-khc6p-rfszo-zdwng-xbtkh-xyvjg-y3due-7ha7t-uae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | b2a827169568dacf61497569a9f181187a8fd453491ca32d09b1e4c382109352 | be795f670fc90cdcc8653aad111982b428a5a2b192c614ef2f2a4b575ba53f36 | 109 | — |
| Registry enrichment · Operators | 14 | get\_value | node\_operator\_record\_vicvb-nkzkt-tj2lz-yzzw4-gfcsj-3eggv-izdti-tarpt-fsojm-lgq22-wae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 9f7437044b17690f369f0089ab5d521fba65d6f541a0395d871bf7623c5540c8 | 74524f4e0d2dfeb212e54508286e6ba4655c127fb7df49e27ec65e3b94a430df | 109 | — |
| Registry enrichment · Operators | 15 | get\_value | node\_operator\_record\_4isre-d3zxy-xpque-tagdf-xdzjp-hk7x3-szquu-kuwej-52cfy-f6jwc-zqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 4b8df6c0f0f8183e96b490ccbf76c4bb778aab8fcdc19e03722afd5efb0c4cc8 | 72cfb5bbe4e6b957a5caa451bb14ba955120e616ab2f8d2ca9c32b7a38f8d914 | 111 | — |
| Registry enrichment · Operators | 16 | get\_value | node\_operator\_record\_oorkg-ilned-36bwb-vyprm-56g55-hp6xq-gucq3-fmn2i-44a4e-txzlp-gqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 3cef777922d1f1885abbde335c46b2e993914f90ed469030c536b3418635b5db | 135e9b11f53ad9ff4d8f740454628af01e7565249eb52e96b5775a573ff3b14b | 109 | — |
| Registry enrichment · Operators | 17 | get\_value | node\_operator\_record\_5dwhe-vpbuf-zz5ml-ylu6k-7y2z2-36ywv-5e4wf-advxd-3endk-icvg4-cae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 03401e4297dd0d578d6109b9a1b9270325f4544e489e038de1640fb30e626026 | 4cc5f6d9165cdb5591c42e77c5d853080915003c4a3e8ba987d74bab09397a77 | 111 | — |
| Registry enrichment · Operators | 18 | get\_value | node\_operator\_record\_3xiew-2wo3x-tnbn2-o7kok-wwsnw-7koo2-gna5r-rlrt3-zotsh-dwpg6-kae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | ed60ead23a3e73636a0b38c3f0e72bc77b84d439c0c46a060c7ff4ac3f3616ab | 4fda33a5a801a2a77b279e64936a4bf7a946eaa864d8183da822c71cf2b35bbd | 111 | — |
| Registry enrichment · Operators | 19 | get\_value | node\_operator\_record\_nvocp-jlbys-d44wi-od3pv-iws4n-2nll3-73hqk-koh72-3obvg-kt5v3-fae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 8662b6543bff31892ea7b8326e143982e254317e0aa6eace94db93f5d1f72973 | 98581a50073d44e00317fc56a6e4a4a16f592a52acc99d0761a9cc5c2d58f7d3 | 109 | — |
| Registry enrichment · Operators | 20 | get\_value | node\_operator\_record\_ywjtr-pq5wc-m6foq-tyxvk-2a3wc-dlg3k-aaebf-6rk2d-5yvn7-tf743-gqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 2cbb402cb41b7845ffe931a07a6dad32191c680e33aeaf7b3c19ceeee47edeeb | dadc426c4ed0ad70fdbe19e6abdb69b967d337e2199bf225dd0762b55e88d766 | 111 | — |
| Registry enrichment · Operators | 21 | get\_value | node\_operator\_record\_c5ssg-eh22p-pmsn6-fpjzj-k5nql-mx5mc-7gb4a-4klco-c4f37-ydnfp-bae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 4e73ba596d33ac90459875681b39b4392d4a553d1de9515b3b0da77320a06ed8 | 128462328aa19548d24a54eaba4828106e7356c0fa51840aadbfe457f95f79bb | 111 | — |
| Registry enrichment · Operators | 22 | get\_value | node\_operator\_record\_iubpe-vrzpt-cdf5f-kkzhq-rgp63-dkbfo-fje7f-6aknf-jekzg-3s7tv-oae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 2e1acb9bd9c60810494eea24407a33450ea9b22968f1952e832b8e68bc021f75 | d8d67c14feb40862f4fcb65744b2813b5b778e4036f680f3475f689256e0dad4 | 111 | — |
| Registry enrichment · Operators | 23 | get\_value | node\_operator\_record\_bftbl-quva3-hsn2r-qsjde-goegh-rupku-gb7xx-utj6e-lswl4-hclva-bqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 9d48e95bb04452fb6be686f490f730d377c9f6b23ece1ab7aa7c8c9657929b79 | f9bc5f223da4ec775474ad99c2ed041b10b99a8b48d0c261f64a9b79ca7a0364 | 109 | — |
| Registry enrichment · Operators | 24 | get\_value | node\_operator\_record\_raiov-7se2a-qvvut-fosrr-ewckg-wwvx5-yiyih-msga4-kibn2-tel4j-uae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:26.507 UTC | 5e5f6ecd602bb2fe7d8ba20d33b18cb508feef7c3ba30dc2815c51c79a798576 | b2710ec2be87717d6d16218438359d17bfcbc330253840d99106754c535ea89f | 109 | — |
| Registry enrichment · Operators | 1 | get\_value | node\_operator\_record\_5p6xp-glfoz-fgh6d-4rx7e-hix7t-c4vcp-u2xhn-gv4mm-fkozw-6mntb-7qe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | 662d5d471931bd27b0486999183138e4dedc278c590bee735c49792cd08f1260 | 2fb2c887426b2c0ea5a8737c42875c23bf74220b7d48d5b72347c66441b605b5 | 109 | — |
| Registry enrichment · Operators | 2 | get\_value | node\_operator\_record\_7rw6b-6r7qv-al3uk-rimg7-ifkjv-hettz-lhmly-t55g7-xrwac-25ayy-wae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | 9d081b7220495c8b3e6b59c6405a357126c966f599fe66494b5d72666edde45d | c3be55698ca63e14b767c582e6e52ca7d62e43a2839332ec503ae7aa9217b0dc | 111 | — |
| Registry enrichment · Operators | 3 | get\_value | node\_operator\_record\_lis4o-siuek-6zrm6-g5pkh-lswnt-ttsd4-henvb-d6mit-lgfpr-lynph-xae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | 78f036787e35d68a1e74ae2a380ec8686cbb932bfdfeb57380101be97bd7009b | 036b7beaecdc2bb0d0bc38cfaebea5cbf1f03ea34d1337fabd1ed4f0278bca68 | 111 | — |
| Registry enrichment · Operators | 4 | get\_value | node\_operator\_record\_ukji3-ju5bx-ty5r7-qwk4p-eobil-isp26-fsomg-44kwf-j4ew7-ozkqy-wqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | a6e1feb976bab1c3b7872b9fa772ab21511c65364d2fdd6920796869de4990a2 | 18f34b2457963b69a7a90ffed70bd83d896a84247f4360ac5e397269e4225839 | 133 | — |
| Registry enrichment · Operators | 5 | get\_value | node\_operator\_record\_feb2q-mgxwe-okz7r-juws2-mahg4-wflqu-oeflf-kvh4r-qaqit-hbqpg-uqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | bc970778f0a3b5d6e6b2941d40d909fe574484df529a49881bc6407412d355a1 | 7e64a27610eb75b185bd42c8f4ee7e3dcb79dd3380076f7f4cc347a425bfa766 | 111 | — |
| Registry enrichment · Operators | 6 | get\_value | node\_operator\_record\_aaxec-cijpz-vzdwe-546fi-vahtf-s2awa-ldn7q-mzl2j-gmvhz-56zlq-mqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | 715f6f362330cfa1c23b56a722aceda3ac6aa4dacbfca82e421f4d0bb908770d | f87eb33f44dcad38eab6fc156784ad8de9d1e262c856df52cd28183736dc7c06 | 111 | — |
| Registry enrichment · Operators | 7 | get\_value | node\_operator\_record\_mbnsu-w4xfc-pmdok-r2lwo-wxfr4-gigu5-4idcm-5uuuy-znvby-biiny-jqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | a726cc9f730454182b5f5599471c5dea7e1ab0fe2057f0eb735a2d3d9cad0204 | 36484f2a914dd47d16c1e60527838bb9c29696c4fc80f3cc7d80e652499f7d3d | 111 | — |
| Registry enrichment · Operators | 8 | get\_value | node\_operator\_record\_ymenq-4sr5h-3imm6-kjjw6-2knuy-ntmlu-oqf5k-vdnzv-z427q-gqdot-sae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | 8897e739b80b94cf75b5e16551ed1b0ab8efbf16bb55132d784a0fb02084be6b | 3412de73c6ecd72851df860d5d7ecd752ee33709ce6b98d92fd1b7263acdb272 | 109 | — |
| Registry enrichment · Operators | 9 | get\_value | node\_operator\_record\_f3toa-2qbnz-67mnl-ws76t-asi36-oz7vd-w5xjx-u5n75-jchls-uhioe-6qe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | 3a347cfc734cc0574f41a1be52bb4e5410d66887d3a0a6e7cc709aae73282e8d | b1433f5d41c0dcab106b86e81b1d36f582a49b44fd568b2cacafe9ab2b26e497 | 111 | — |
| Registry enrichment · Operators | 10 | get\_value | node\_operator\_record\_zc635-ppr46-ap6eg-pghtn-wtnxz-6czvv-a4uxm-adjgb-wtoh4-2ddnl-uae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | ba3e461ff3b3e8ed22d4a0d1f412b37e609161e865ac950156d84e63c8086e0b | 475dda67ab01538d9c01d21c9555272280daf405e8f3755807a46aaa5e6cc99a | 109 | — |
| Registry enrichment · Operators | 11 | get\_value | node\_operator\_record\_mpmyf-juliu-5qwcu-ofamg-es7ug-4mjt4-w5lht-dbrfb-ualjm-hcwmn-pae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | 896c9155ab88374080e2eb32633b1f29fbe4e817349cc87762443e5bfc8ace56 | 85814150b114de950c521472f1f64f6b11ab9cfddef90f72913e2db2e44e1254 | 107 | — |
| Registry enrichment · Operators | 12 | get\_value | node\_operator\_record\_ueggl-7wvx2-2eezj-mgjrg-w6tmy-ngmye-xxbwu-gumli-hdf7u-zzpng-3ae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | 447f8b2c0f5d46f22f4ba330c8345c9a8165241578d5756db604df3f835cec89 | 4d3f35a5ce9bed15129510edbb22ad3f6fd972a1f183ff0f01ac2563e5b8535f | 112 | — |
| Registry enrichment · Operators | 13 | get\_value | node\_operator\_record\_s7dud-dfedw-dmrax-rjvop-5k4qw-htm4w-gj7ak-j2itz-txwwn-o5ymv-tae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | 7fe3f3c33c5856991dfef5738ed82e8701fbb0bcc002382b8a86cd26bcecc19d | afefdc4d98ccfb7a4ec9343d656b8ddc89fd61eaef182a24db444ffee2c572f5 | 109 | — |
| Registry enrichment · Operators | 14 | get\_value | node\_operator\_record\_eu5wc-g7r7l-zzy2o-227af-hfvin-orflw-4vdlf-j7gks-n5wrj-zezt7-tqe | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | 17c8f2d90426c81ed7dd31951bbee6ae99efc0dfeefcc8eaed91e4c68b1e9965 | 2a3d6e4269931c35145bb89744a4dbe5d821650788676da30525cf73bf6b8651 | 107 | — |
| Registry enrichment · Operators | 15 | get\_value | node\_operator\_record\_a5glg-n6ul6-rkuc7-idthk-fb2fe-d5m75-4g4l7-22yko-h27pr-q3a7k-lae | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.023 UTC | 260b83add88ac489b5d6b5c858026c97d2e941387dace76db7dc841c4803523c | ca3dc094aa5bf974475b42b231448e3809b20828259d66d6528e1dd3c05ca456 | 111 | — |
| Registry enrichment · DataCenters | 1 | get\_value | data\_center\_record\_fm1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 7840e7fffef258e8db908e7c20f0394ee4a789c010c469f150fdd6c22114597e | 4d3405b1a64b9dd506c5a6d2736a9196341d6561259aecd13244c73097d3b562 | 72 | — |
| Registry enrichment · DataCenters | 2 | get\_value | data\_center\_record\_ge1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 3a86b41d54d0becbf66a316e10c3ecacb376660e6eecc168a0c605e2a4828d3d | cf19de915d1348d931b735f33a2ec23f23ef6e7aea7b95136c21521ae239a39c | 49 | — |
| Registry enrichment · DataCenters | 3 | get\_value | data\_center\_record\_im2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 3156bd577a072301b421fe882bfc7cc89a31216591583172fde6c03ab2e7efaa | b6342cf5bae017509ffdab3a2097920ca6217207bb9b2723f282a329bb05c628 | 54 | — |
| Registry enrichment · DataCenters | 4 | get\_value | data\_center\_record\_sj3 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | cffaf1475ebc49753b5e4e7bb3cfa932ff3360119eca3bb479e2e6b935177979 | 544c70ff00ec165e5dfa5984b2a8948e18198a318a237fc98acd1b278d5b748f | 65 | — |
| Registry enrichment · DataCenters | 5 | get\_value | data\_center\_record\_zh5 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 5b83a274370b9b5ef366c298fada3c0b495a8490a37dd700d8ed9d4fb4aebeab | 89951e82b567e469034ad419a60ac364a932c43ec312dae86274a1c1094a31bc | 51 | — |
| Registry enrichment · DataCenters | 6 | get\_value | data\_center\_record\_dr1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 115e36c3002712e26ea638a2f3233e3a14393b6b4bb3dfd1c81db456e7feaf63 | a6d4495d574de8fd7d573e50e66fbed814a2f01fd3b71af081b6215c4fd8d6a3 | 58 | — |
| Registry enrichment · DataCenters | 7 | get\_value | data\_center\_record\_ct2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | d5af31ce9af80393c7400790941ebc9038399034aa2ed6110788a89753fdb3d6 | 05978248f855294ec52e7c98f5c316db09439ff76c4b281117e08426be66018f | 52 | — |
| Registry enrichment · DataCenters | 8 | get\_value | data\_center\_record\_hk3 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 80cd59262037de1abb01d9f33395212cd8f7a31dd79f32e6b04838636892ce8d | 703e7654239492219f6ef1ec0b2ff335f86680a4f28a73c19c3a2ac32fde5f98 | 49 | — |
| Registry enrichment · DataCenters | 9 | get\_value | data\_center\_record\_hk1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 15409f8b0fbbfb13155a3d633ba3dfc6a7e97da3579a0072fc4ee28cabe40667 | a0623e80bc5fc3d5997b639dc9df02b6b416761e26f48d8a04c020945680943e | 49 | — |
| Registry enrichment · DataCenters | 10 | get\_value | data\_center\_record\_nd1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | eae5cd5c1234e88d0989a87bbd29876775b0308e2ce6fb0452e43d3d6dc1ce54 | f82211b477eab656aacf2a8dd2c122b1ab365cac8118616e034961d55f1f8e08 | 61 | — |
| Registry enrichment · DataCenters | 11 | get\_value | data\_center\_record\_es1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 17f0658786fdab35399bbfb8b5732a3de9cd749d82bf3104d90737dbeb1a404f | b6a83b7fbad389bbb2e3229826901dada23ba235f27b2b44c35764cdda612027 | 50 | — |
| Registry enrichment · DataCenters | 12 | get\_value | data\_center\_record\_jb2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 325e4a3244e28e672c599510a59a3ee8eb269eb5e29fbac7ba8fb69925b1e437 | c3de5004f3e0bab997fdb6a247ebeebcefdf8185b1d61f52ed5b634cf48f2fa9 | 63 | — |
| Registry enrichment · DataCenters | 13 | get\_value | data\_center\_record\_sh1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 141f187b0ca112f44d31a19d98b8ec913d808a6595ad2893605a7e6443d66ec6 | 5efaa12dbed1f6f6ec61857abab3f001b8e7c8193e92b72642dbe71707ae36c9 | 60 | — |
| Registry enrichment · DataCenters | 14 | get\_value | data\_center\_record\_sg3 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 778dcee5f6e31251ff9d0073ca452ca5e807458ef1f0fc3fc89aed4d7412b2d0 | 90929f77df0b87158be9d169b7a4530d3702cdbcf5a548deaf9d1c9a98d34e66 | 57 | — |
| Registry enrichment · DataCenters | 15 | get\_value | data\_center\_record\_im1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 0b1aa1d2bfddded65ca56feee133a0e7ca6b009fa3873dbb23d5650b88d905c3 | 1f5097695d5bfa4382a41a7d4be6e2f4d43b1fb1254eebf83cea6feb374f64c9 | 56 | — |
| Registry enrichment · DataCenters | 16 | get\_value | data\_center\_record\_br2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 7ed1188ebd7086f7d10590490d53b381d1ad965370e229ae7b19d94a6d4b3131 | 4700170a4bf4480762729c9482fd3d2b34901e7d826742f90aa419604c463d98 | 62 | — |
| Registry enrichment · DataCenters | 17 | get\_value | data\_center\_record\_kr2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 6ddb33396d239bcab45c4cf869aadce5a457fec424d2f1d370de684a6fa8e249 | db8915b061b89414bd5d72c79c882d410d26ad5074cc0001e3609d77d6b68e26 | 45 | — |
| Registry enrichment · DataCenters | 18 | get\_value | data\_center\_record\_mb1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 071a1ba11254af2f5e6e591e3069b4308e38afb80b662185da79d0227b4f53dd | 0f2f0864280c7194e987163feee911fd7190935a417cdc1cd8ce7d418ae53df2 | 53 | — |
| Registry enrichment · DataCenters | 19 | get\_value | data\_center\_record\_li2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 6b7c39ec863f67736ab9b62ad261c645550a5818147bc7dda803e6e442e6f09a | 0c9b5ffa0c8395d4c7ae8dfd2b4cbc5fb2b338d690e60c8de44f8dce69dd9036 | 57 | — |
| Registry enrichment · DataCenters | 20 | get\_value | data\_center\_record\_cm1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 735ab29eabb9477b6e518d796185f954a70d708e3c9a883559689a1f6570946d | 196a9e101c271c668cb422d44200eb74f22a2236e8b7b94ad613749e3542bdf6 | 54 | — |
| Registry enrichment · DataCenters | 21 | get\_value | data\_center\_record\_bu1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 4d9cb07f745a125bd3f62c1ac0f59a5e2797ef64ab31a43837c9b9d23255f759 | 10a377d477c585d54013f0b053ef7a8772021450ce81f964d8822fde1c2975f0 | 51 | — |
| Registry enrichment · DataCenters | 22 | get\_value | data\_center\_record\_kr1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | f3a15e317a7fcbd0ff123ef7648239cf7555bc98e4411e81fe766f5b563a2934 | e9f8c63be7e127b33d1150cfd70776bd3c884fe2a511906e8e413e57ae11c531 | 42 | — |
| Registry enrichment · DataCenters | 23 | get\_value | data\_center\_record\_rg3 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 1d5e01fc50c837188f45a64b9a6db7ff5b6c0d4af8c071e265a33f295c9c9c2d | 40b84b11a4767306abfad18b475d88cc410c9c6e601fc9abef4c309e037a3716 | 45 | — |
| Registry enrichment · DataCenters | 24 | get\_value | data\_center\_record\_ld1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:27.536 UTC | 5011a29572a8b8fc94e922a15ce07bfa94ab71275769cccad5822e00e20ad631 | 4c0bb1f7dcebc8ae7dbb2812648d148e705148f027766daa0f4a73f9307f03ef | 54 | — |
| Registry enrichment · DataCenters | 1 | get\_value | data\_center\_record\_ar1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | 02b3cfb31ea67d22ab21eabfc6743114b4b47247ead51a3900c6e631461b4bf3 | c0839cbc5c8c5f99cd558494bc95a297de911ff44a94599483d8f1eede96a3ff | 89 | — |
| Registry enrichment · DataCenters | 2 | get\_value | data\_center\_record\_pl2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | 3c859e15134ab00e74a4f129c0a973dad401564cf30fe852359d5213cdca6fb0 | 7e0739d8f49ab5e841be5444a4bf280c278bf3fc5b6c1a29c3c7178cd235bc97 | 46 | — |
| Registry enrichment · DataCenters | 3 | get\_value | data\_center\_record\_tv1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | a8830bbea47510decb735c5784c15f46ae370b7e0ceaa72f34699f8b419ccfc7 | bd8ff141cd5a9befe51d3d4aa19e92f2b84c2665d6f08b6c0dc8f9a4d26f5f2a | 52 | — |
| Registry enrichment · DataCenters | 4 | get\_value | data\_center\_record\_sl1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | b66857812a5f71b3d82979de78faaeb40438a663760560eb4e83f9f737e09a1c | 8db4a62cd24fdfc1c6ac20dd26e04d6c22fbb2d0a0c5a69fb6a6843fea4b60ad | 54 | — |
| Registry enrichment · DataCenters | 5 | get\_value | data\_center\_record\_bc1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | 9ab43ffabccb2a4d03fe1784aed9877a0b5cd1ec1767da693e684f2a8535ab88 | 356705da5622503db0720e5fde5815a73e5511644f85d746124a5579b8c5f48c | 67 | — |
| Registry enrichment · DataCenters | 6 | get\_value | data\_center\_record\_hk4 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | e30e801983959af9de3829764315165c83ceb91b1ba84c5b0de6fa7bf06e054f | ef55f61f9e75cbc5b03f6084221cd013af6bf61d45018e1ea249f3ffb8684921 | 48 | — |
| Registry enrichment · DataCenters | 7 | get\_value | data\_center\_record\_bt1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | 3322263f3636907bcad3b72fc57030f0d02b3e7c8b8ff3b7157836f32e378036 | 938e30a1df74b250b88697cb55743087aaccd468e1246398014e05275d9ce39e | 52 | — |
| Registry enrichment · DataCenters | 8 | get\_value | data\_center\_record\_jb3 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | 4ab8577e84c052b72b04d12265e5509419fc45d4cb3eb2714c3e877fa4e5d019 | 9257d1cdb4c0a85b98da1b4316509b65097acb58160e1f273dd84f67e32b9dd8 | 50 | — |
| Registry enrichment · DataCenters | 9 | get\_value | data\_center\_record\_sc1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | 0761a4eb80cc04f74570aa22d3ab0673d8f2067155738dc5e87f73f524c672a1 | f6eb434904757db5ba0765775edb48f20eabc6f2c54a2e87823351cff4d164d6 | 54 | — |
| Registry enrichment · DataCenters | 10 | get\_value | data\_center\_record\_bn1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | 0e92f5c006b858d5e95d8a260c0acfba7667b0b0f93d01b4cdc2bc08be6e700c | 79e1aaa1b284af487ba718d57c30b8b3c967a5c442dd873de43c420ea1a463cd | 73 | — |
| Registry enrichment · DataCenters | 11 | get\_value | data\_center\_record\_nm1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | f96ec97f1afec73b147a8f306b413c8d5541048c75711a7c2e53a3ad7ba3911a | 9a733b9f0173f0ea07b5c547c98b810e13255a83f31f7be6fa6eb161ccd22e76 | 52 | — |
| Registry enrichment · DataCenters | 12 | get\_value | data\_center\_record\_mtl1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | 46a1f6faf67ea38588986d15b8e0d405d0b9563617f00a5e7e8350dfef5f5748 | 058df8cad602f7e2ad115f25fb5b943f0a0f4a81947180ea385fc09cfaf04f99 | 59 | — |
| Registry enrichment · DataCenters | 13 | get\_value | data\_center\_record\_zh2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | bf3d8bec8cc3e8e57f509721b7f85d578bcd05b26b06878c99bb9efd34322b5b | 4b9e402badaac247f34bd1f798ea065309d92823c9d0ff16c8278a590f0c9394 | 52 | — |
| Registry enrichment · DataCenters | 14 | get\_value | data\_center\_record\_lj2 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | e01f4a6e619993db195eba6cf041f89a36e6d179838063bb36ff41dfce1f9668 | ce255c8a6ab1ef92f40f537c193b09158abe7744a6b680a0dc6fe49365d13ad6 | 55 | — |
| Registry enrichment · DataCenters | 15 | get\_value | data\_center\_record\_ty3 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.061 UTC | b616e502dcd344a4bc30b11397f742e8adcaef65f72744db16556b4e8ed1201f | 9b914fd2c10cfb81862c10844447af01e280a5af3008521561e21955cbc5c0c3 | 47 | — |
| Registry enrichment · Role | 1 | get\_value | nns\_subnet\_id | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:28.575 UTC | 694166e85b60f2511372e23644da763e045edbf1a7a77c2cb9f5a6cd9fca39f5 | 4645427b3f67aacd8194bcbef764dd7eb7eb945ceacb1192e083933f002333b5 | 39 | — |
| Final Governance verification | 1 | get\_proposal\_info | 144954 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 11:25:29.505 UTC | e933c506c524cb2d3d495bec82e7379a083b52eef47e44663678b2995852d003 | 92cc11a832f1c5c044ac4d0f11f81694e8598dce73824656b670f6a28503b07f | 12764 | — |

</details>
