# Proposal review · [#145075](https://dashboard.internetcomputer.org/proposal/145075)

Proposal #145075 · After proposal #145075 · Step 1 of 1

Subnet [4ecnw-byqwz-dtgss-ua2mh-pfvs7-c3lct-gtf4e-hnu75-j7eek-iifqm-sqe](https://dashboard.internetcomputer.org/network/subnets/4ecnw-byqwz-dtgss-ua2mh-pfvs7-c3lct-gtf4e-hnu75-j7eek-iifqm-sqe)

## Summary

Add 2 and remove 2 nodes. The subnet remains at 13 nodes.

13 members · Add 2 · Remove 2 · Unchanged 11

Target subnet checked; assignments in the other 97 listed subnets were not checked.

## Evidence scope

Pinned Registry version **66,274**. Governance checked after the selected comparisons.

- #145075 · Open observed 2026-11-28 15:51:10.503 UTC

- Proposed membership is conditional on the pinned evidence. Full execution validity remains unverified.

## Review checks

Conservative availability model. The fault budget is floor((N − 1) / 3). Model departing nodes unavailable in the before-state and incoming nodes still synchronizing in the proposed state. The smaller margin applies. A margin below one triggers a warning. The cumulative case keeps all earlier arrivals unavailable while they remain in the subnet. These conditional margins do not establish global assignment, execution validity or actual liveness.

### Step 1 · Proposal #145075

Add and Remove are disjoint · Add duplicates 0 · Remove duplicates 0 · Membership preconditions · Incoming assignments could not be established across the Registry roster

Conditional step margin · 2 additional faults tolerable · 3 would exceed the modeled budget

<details>
<summary>Instruction and margin arithmetic</summary>

- Duplicate Add principals · none
- Duplicate Remove principals · none
- Overlapping principals · none
- Individual step · 4ecnw-byqwz-dtgss-ua2mh-pfvs7-c3lct-gtf4e-hnu75-j7eek-iifqm-sqe · Before · 13 members, budget 4, modeled unavailable 2, remaining 2 · Proposed · 13 members, budget 4, modeled unavailable 2, remaining 2 · Limiting side: both states · Margin 2

</details>

Governance check incomplete · 0 references found

- Sources rrkah-fqaaa-aaaaa-aaaaq-cai · 6 admitted reads

- Discovery observed 2026-11-28 15:51:12.616 UTC to 2026-11-28 15:51:33.295 UTC

- Pagination complete · 6 pages · oldest listed #340 · Open 29 · Adopted awaiting execution 21

- Title, summary and supported motion text checked for 50 proposals · Supported actions decoded 23 · Hydrated 0 · Lifecycle changed 0

- Unsupported actions 27 · Missing payloads 0 · Malformed payloads 0 · Omitted findings 0

- Checked the exact node identities in the accepted Membership instructions.

- Findings restricted to accepted instructions for #145075 · Review-specific discovery.

## Map

![Map of registered node locations for the selected comparison](map.png)

Add (green) · Remove (red) · Unchanged (blue). 15 unique nodes across both states · 15/15 located. Positions use the registered data-center coordinates. The dotted halo indicates multiple node identities at the same coordinates.

Natural Earth map-unit boundaries are cartographic. Country shading uses recorded membership groups. Green shows increases and red shows decreases. A dashed border marks a country falling to zero. Small squares mark represented map units too small to see at the current zoom.

Changed sites · bu1 · 1 → 0 nodes · cr1 · 0 → 1 nodes · dl1 · 1 → 0 nodes · st1 · 0 → 1 nodes

## Node changes

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
| Remove | [o42ny-ab3zt-iknyx-eo4ji-utgbe-xmae4-ybmwp-wdkzt-efffe-oq6nh-oae](https://dashboard.internetcomputer.org/network/nodes/o42ny-ab3zt-iknyx-eo4ji-utgbe-xmae4-ybmwp-wdkzt-efffe-oq6nh-oae) | [bu1](https://dashboard.internetcomputer.org/network/centers/bu1) | M247 | [i7dto-bgkj2-xo5dx-cyrb7-zkk5y-q46eh-gz6iq-qkgyc-w4qte-scgtb-6ae](https://dashboard.internetcomputer.org/network/provider/i7dto-bgkj2-xo5dx-cyrb7-zkk5y-q46eh-gz6iq-qkgyc-w4qte-scgtb-6ae) | c5ssg-eh22p-pmsn6-fpjzj-k5nql-mx5mc-7gb4a-4klco-c4f37-ydnfp-bae | 🇷🇴 Romania (RO) |
| Remove | [vw36t-lgksm-5cgtg-ait3y-sy25v-gdtsq-en6oe-md35y-a7cji-uiryt-3ae](https://dashboard.internetcomputer.org/network/nodes/vw36t-lgksm-5cgtg-ait3y-sy25v-gdtsq-en6oe-md35y-a7cji-uiryt-3ae) | [dl1](https://dashboard.internetcomputer.org/network/centers/dl1) | Flexential | [eipr5-izbom-neyqh-s3ec2-52eww-cyfpg-qfomg-3dpwj-4pffh-34xcu-7qe](https://dashboard.internetcomputer.org/network/provider/eipr5-izbom-neyqh-s3ec2-52eww-cyfpg-qfomg-3dpwj-4pffh-34xcu-7qe) | mw64v-jynex-7tu52-5a3te-ifbop-nh7y7-w7lno-ymmht-b7fmy-wfhha-gqe | 🇺🇸 United States (US) |
| Add | [6jidn-uqgyz-hl2l3-ou2rg-slu73-iztvd-yhdu7-hjfuz-cy4wc-jvoqc-uae](https://dashboard.internetcomputer.org/network/nodes/6jidn-uqgyz-hl2l3-ou2rg-slu73-iztvd-yhdu7-hjfuz-cy4wc-jvoqc-uae) | [st1](https://dashboard.internetcomputer.org/network/centers/st1) | CyrusOne | [izmhk-lpjum-uo4oy-lviba-yctpc-arg4b-2ywim-vgoiu-gqaj2-gskmw-2qe](https://dashboard.internetcomputer.org/network/provider/izmhk-lpjum-uo4oy-lviba-yctpc-arg4b-2ywim-vgoiu-gqaj2-gskmw-2qe) | tcn4t-xktz4-qm6yk-udidk-m5ays-paeqx-xaevx-hb3fj-nvocf-vr5yq-yqe | 🇺🇸 United States (US) |
| Add | [gfeqv-7ndps-okvma-qxwsi-ozk4x-b5wyp-hzwmb-v6g5t-dmen4-aff4d-zae](https://dashboard.internetcomputer.org/network/nodes/gfeqv-7ndps-okvma-qxwsi-ozk4x-b5wyp-hzwmb-v6g5t-dmen4-aff4d-zae) | [cr1](https://dashboard.internetcomputer.org/network/centers/cr1) | Navegalo | [6sq7t-knkul-fko6h-xzvnf-ktbvr-jhx7r-hapzr-kjlek-whugy-zt6ip-xqe](https://dashboard.internetcomputer.org/network/provider/6sq7t-knkul-fko6h-xzvnf-ktbvr-jhx7r-hapzr-kjlek-whugy-zt6ip-xqe) | eqv2i-6dtlf-bhbjd-2popw-vvavp-7xzci-6gdd7-qxgox-wdw5w-l3a4w-eae | 🇨🇷 Costa Rica (CR) |

<details>
<summary>Other Nodes (11)</summary>

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
|  | [lpkij-6jgir-sukcx-6kplx-qddla-ufncr-e3m2p-kikly-bcwzd-mtslj-4ae](https://dashboard.internetcomputer.org/network/nodes/lpkij-6jgir-sukcx-6kplx-qddla-ufncr-e3m2p-kikly-bcwzd-mtslj-4ae) | [kr2](https://dashboard.internetcomputer.org/network/centers/kr2) | Gasan | [64xe5-tx2s3-4gjmj-pnozr-fejw2-77y5y-rhcjk-glnmx-62brf-qin5q-pqe](https://dashboard.internetcomputer.org/network/provider/64xe5-tx2s3-4gjmj-pnozr-fejw2-77y5y-rhcjk-glnmx-62brf-qin5q-pqe) | 5dwhe-vpbuf-zz5ml-ylu6k-7y2z2-36ywv-5e4wf-advxd-3endk-icvg4-cae | 🇰🇷 South Korea (KR) |
|  | [rfe2u-pdp5u-frzdb-r2ga3-5jept-24323-5pere-7lerg-toh4w-cwdsl-cqe](https://dashboard.internetcomputer.org/network/nodes/rfe2u-pdp5u-frzdb-r2ga3-5jept-24323-5pere-7lerg-toh4w-cwdsl-cqe) | [sh1](https://dashboard.internetcomputer.org/network/centers/sh1) | Digital Realty | [bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe](https://dashboard.internetcomputer.org/network/provider/bvcsg-3od6r-jnydw-eysln-aql7w-td5zn-ay5m6-sibd2-jzojt-anwag-mqe) | lgp6d-brhlv-35izu-khc6p-rfszo-zdwng-xbtkh-xyvjg-y3due-7ha7t-uae | 🇸🇪 Sweden (SE) |
|  | [m4e6a-3t7oi-ooshc-2b2vq-56xpu-pyo7q-qafn2-3sem2-cvtck-6xfqy-vae](https://dashboard.internetcomputer.org/network/nodes/m4e6a-3t7oi-ooshc-2b2vq-56xpu-pyo7q-qafn2-3sem2-cvtck-6xfqy-vae) | [ge2](https://dashboard.internetcomputer.org/network/centers/ge2) | SafeHost | [7ryes-jnj73-bsyu4-lo6h7-lbxk5-x4ien-lylws-5qwzl-hxd5f-xjh3w-mqe](https://dashboard.internetcomputer.org/network/provider/7ryes-jnj73-bsyu4-lo6h7-lbxk5-x4ien-lylws-5qwzl-hxd5f-xjh3w-mqe) | 5atxd-q4jom-dtpxr-awd3p-e562x-hpavj-godtj-g6vmz-of2c6-ildhh-fae | 🇨🇭 Switzerland (CH) |
|  | [4vwpn-budhw-o2kvm-axlue-sr5lt-vy3be-ammju-rw22w-w4qtn-sns52-3qe](https://dashboard.internetcomputer.org/network/nodes/4vwpn-budhw-o2kvm-axlue-sr5lt-vy3be-ammju-rw22w-w4qtn-sns52-3qe) | [nm1](https://dashboard.internetcomputer.org/network/centers/nm1) | Rivram | [ulyfm-vkxtj-o42dg-e4nam-l4tzf-37wci-ggntw-4ma7y-d267g-ywxi6-iae](https://dashboard.internetcomputer.org/network/provider/ulyfm-vkxtj-o42dg-e4nam-l4tzf-37wci-ggntw-4ma7y-d267g-ywxi6-iae) | mpmyf-juliu-5qwcu-ofamg-es7ug-4mjt4-w5lht-dbrfb-ualjm-hcwmn-pae | 🇮🇳 India (IN) |
|  | [rwze6-4mvpx-o5pdv-3sujg-2szcx-223oi-f3jnl-jx27g-2qs22-dmt2j-jae](https://dashboard.internetcomputer.org/network/nodes/rwze6-4mvpx-o5pdv-3sujg-2szcx-223oi-f3jnl-jx27g-2qs22-dmt2j-jae) | [ty1](https://dashboard.internetcomputer.org/network/centers/ty1) | Equinix | [sixix-2nyqd-t2k2v-vlsyz-dssko-ls4hl-hyij4-y7mdp-ja6cj-nsmpf-yae](https://dashboard.internetcomputer.org/network/provider/sixix-2nyqd-t2k2v-vlsyz-dssko-ls4hl-hyij4-y7mdp-ja6cj-nsmpf-yae) | cqjev-4qb7l-xv373-jfmhi-73n3a-cxhst-p6okb-vywwc-a4zbi-6sf3u-bae | 🇯🇵 Japan (JP) |
|  | [hhixb-o5xrj-s5pty-esitz-m6s46-wgsez-c7thd-6h27w-7hikq-ae5n7-pae](https://dashboard.internetcomputer.org/network/nodes/hhixb-o5xrj-s5pty-esitz-m6s46-wgsez-c7thd-6h27w-7hikq-ae5n7-pae) | [lj1](https://dashboard.internetcomputer.org/network/centers/lj1) | Posita.si | [wdjjk-blh44-lxm74-ojj43-rvgf4-j5rie-nm6xs-xvnuv-j3ptn-25t4v-6ae](https://dashboard.internetcomputer.org/network/provider/wdjjk-blh44-lxm74-ojj43-rvgf4-j5rie-nm6xs-xvnuv-j3ptn-25t4v-6ae) | gl27f-y5srq-yy5ot-v4x5z-y2a2s-sgoor-l4gjg-qv4x4-v2olb-dz4dc-wae | 🇸🇮 Slovenia (SI) |
|  | [c3syk-l56ky-owcvg-y4ogf-3qfti-elv4e-2bqp7-k5v32-ibzm6-o4k6s-eqe](https://dashboard.internetcomputer.org/network/nodes/c3syk-l56ky-owcvg-y4ogf-3qfti-elv4e-2bqp7-k5v32-ibzm6-o4k6s-eqe) | [hk1](https://dashboard.internetcomputer.org/network/centers/hk1) | Unicom | [r3yjn-kthmg-pfgmb-2fngg-5c7d7-t6kqg-wi37r-j7gy6-iee64-kjdja-jae](https://dashboard.internetcomputer.org/network/provider/r3yjn-kthmg-pfgmb-2fngg-5c7d7-t6kqg-wi37r-j7gy6-iee64-kjdja-jae) | vzsx4-ldpic-3zcoa-mfki2-gfsai-ok7ap-gb2sp-fxvaf-ckd7h-jluem-qqe | 🇭🇰 Hong Kong (HK) |
|  | [b5pgw-6wtjo-dzwgu-zkfz6-3l5f3-cw6ka-y4crr-dikku-fkjbe-lfzki-qae](https://dashboard.internetcomputer.org/network/nodes/b5pgw-6wtjo-dzwgu-zkfz6-3l5f3-cw6ka-y4crr-dikku-fkjbe-lfzki-qae) | [sg1](https://dashboard.internetcomputer.org/network/centers/sg1) | Telin | [6nbcy-kprg6-ax3db-kh3cz-7jllk-oceyh-jznhs-riguq-fvk6z-6tsds-rqe](https://dashboard.internetcomputer.org/network/provider/6nbcy-kprg6-ax3db-kh3cz-7jllk-oceyh-jznhs-riguq-fvk6z-6tsds-rqe) | d4bin-5o2wg-ycbdq-yljr7-45pjv-ptf6d-v243j-vg6x5-dlo7t-yqu62-5qe | 🇸🇬 Singapore (SG) |
|  | [7f5c7-l7cuq-7jnfc-yexo3-bytd3-yf6xa-ctk76-wywln-jsy2n-ds2lp-tqe](https://dashboard.internetcomputer.org/network/nodes/7f5c7-l7cuq-7jnfc-yexo3-bytd3-yf6xa-ctk76-wywln-jsy2n-ds2lp-tqe) | [sc1](https://dashboard.internetcomputer.org/network/centers/sc1) | NEXTDC | [fwnmn-zn7yt-5jaia-fkxlr-dzwyu-keguq-npfxq-mc72w-exeae-n5thj-oae](https://dashboard.internetcomputer.org/network/provider/fwnmn-zn7yt-5jaia-fkxlr-dzwyu-keguq-npfxq-mc72w-exeae-n5thj-oae) | srrm2-zawrj-4euwg-w24k6-yiwlj-ln6r7-kxkgb-itaal-efw4m-fp36x-bqe | 🇦🇺 Australia (AU) |
|  | [5ttnf-xhdip-7e2uw-iuikh-5dlli-r6jdc-nxjp7-bjumm-5usid-rpiqn-jqe](https://dashboard.internetcomputer.org/network/nodes/5ttnf-xhdip-7e2uw-iuikh-5dlli-r6jdc-nxjp7-bjumm-5usid-rpiqn-jqe) | [si1](https://dashboard.internetcomputer.org/network/centers/si1) | Bacloud | [3oqw6-vmpk2-mlwlx-52z5x-e3p7u-fjlcw-yxc34-lf2zq-6ub2f-v63hk-lae](https://dashboard.internetcomputer.org/network/provider/3oqw6-vmpk2-mlwlx-52z5x-e3p7u-fjlcw-yxc34-lf2zq-6ub2f-v63hk-lae) | ceta5-wu56p-aqtjd-2cy2f-atzz3-srckr-wkupd-ratc5-62ckj-vsj5u-zae | 🇱🇹 Lithuania (LT) |
|  | [ns7kv-kp2mu-mw7yi-krd4z-eqcvq-qeeej-mxtwb-c2ujq-xtq6x-orzoj-3qe](https://dashboard.internetcomputer.org/network/nodes/ns7kv-kp2mu-mw7yi-krd4z-eqcvq-qeeej-mxtwb-c2ujq-xtq6x-orzoj-3qe) | [to2](https://dashboard.internetcomputer.org/network/centers/to2) | Cyxtera | [7at4h-nhtvt-a4s55-jigss-wr2ha-ysxkn-e6w7x-7ggnm-qd3d5-ry66r-cae](https://dashboard.internetcomputer.org/network/provider/7at4h-nhtvt-a4s55-jigss-wr2ha-ysxkn-e6w7x-7ggnm-qd3d5-ry66r-cae) | 4lp6i-khv7q-lkgk3-hhrc6-ysjag-korh7-ysojw-7gv3h-glhdz-rpjrt-sqe | 🇨🇦 Canada (CA) |

</details>

## Decentralisation

Arrows show before → proposed; a single value is unchanged.

### Different groups represented

How many different registered groups have at least one member in this subnet?

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 4 | 13 | 13 | 13 | 13 | 13 |

### Largest group size

The most subnet nodes sharing one value, such as one provider or one country label. Several groups may tie.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 5 | 1 | 1 | 1 | 1 | 1 |

### Nakamoto coefficients

How many of the largest registered groups together contain more than one-third of the subnet's nodes? Each state uses floor(N / 3) + 1. Recorded groups do not establish independent ownership, subnet safety, execution validity or Target Topology compliance.

Node threshold: 5.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 1 | 5 | 5 | 5 | 5 | 5 |

### Distances between registered node locations

Straight-line geographic distances calculated from registered data-center coordinates, counting each pair of nodes once. These are not measured network latency or health.

| Shortest | Average | Longest |
| --- | --- | --- |
| 492.2 km | 7,772.6 km → 8,457.0 km | 16,403.1 km → 18,499.6 km |

78 of 78 pairs before and proposed.

No current Target Topology thresholds, exceptions or applicability are assumed.

<details>
<summary>Recorded country membership</summary>

| Country (recorded token) | Subnet members |
| --- | --- |
| 🇦🇺 Australia (AU) | 1 |
| 🇨🇦 Canada (CA) | 1 |
| 🇨🇭 Switzerland (CH) | 1 |
| 🇨🇷 Costa Rica (CR) | 0 → 1 |
| 🇭🇰 Hong Kong (HK) | 1 |
| 🇮🇳 India (IN) | 1 |
| 🇯🇵 Japan (JP) | 1 |
| 🇰🇷 South Korea (KR) | 1 |
| 🇱🇹 Lithuania (LT) | 1 |
| 🇷🇴 Romania (RO) | 1 → 0 |
| 🇸🇪 Sweden (SE) | 1 |
| 🇸🇬 Singapore (SG) | 1 |
| 🇸🇮 Slovenia (SI) | 1 |
| 🇺🇸 United States (US) | 1 |

</details>

## Sources and calculation

Membership preview revision `1607dff7a23915d287e9ef56140b375d17b5e3824f0b0908b019817983d37467`.

Calculation input SHA-256 `11e93154102e6ead9039ed5c0c624bfc8c5a1ab8df08a6af79686daa0ab12686` · analysis v5.

The replicated calculation digest identifies the exact submitted evidence and scope. Source receipts identify the separate Registry and Governance observations.

- #145075 executable payload SHA-256 422f6f7a9e5983dbb3e59fcdb40ce13df037fbbc4ba380b260568a998523ecc8

<details>
<summary>Exact distance evidence in metres</summary>

| Distance | Before | Proposed |
| --- | --- | --- |
| Shortest | 492224 | 492224 |
| Average | 7772585 | 8456985 |
| Longest | 16403082 | 18499628 |

</details>

<details>
<summary>Registered geography evidence</summary>

| Data center | Original Registry region | Country token |
| --- | --- | --- |
| [bu1](https://dashboard.internetcomputer.org/network/centers/bu1) | Europe,RO,Bucuresti | RO |
| [dl1](https://dashboard.internetcomputer.org/network/centers/dl1) | North America,US,Texas | US |
| [st1](https://dashboard.internetcomputer.org/network/centers/st1) | North America,US,Virginia | US |
| [cr1](https://dashboard.internetcomputer.org/network/centers/cr1) | North America,CR,San Jose | CR |
| [kr2](https://dashboard.internetcomputer.org/network/centers/kr2) | Asia,KR,Seoul | KR |
| [sh1](https://dashboard.internetcomputer.org/network/centers/sh1) | Europe,SE,Stockholm | SE |
| [ge2](https://dashboard.internetcomputer.org/network/centers/ge2) | Europe,CH,Geneva | CH |
| [nm1](https://dashboard.internetcomputer.org/network/centers/nm1) | Asia,IN,Navi Mumbai | IN |
| [ty1](https://dashboard.internetcomputer.org/network/centers/ty1) | Asia,JP,Tokyo | JP |
| [lj1](https://dashboard.internetcomputer.org/network/centers/lj1) | Europe,SI,Ljubljana | SI |
| [hk1](https://dashboard.internetcomputer.org/network/centers/hk1) | Asia,HK,HongKong | HK |
| [sg1](https://dashboard.internetcomputer.org/network/centers/sg1) | Asia,SG,Singapore | SG |
| [sc1](https://dashboard.internetcomputer.org/network/centers/sc1) | Oceania,AU,Queensland | AU |
| [si1](https://dashboard.internetcomputer.org/network/centers/si1) | Europe,LT,Siauliai | LT |
| [to2](https://dashboard.internetcomputer.org/network/centers/to2) | North America,CA,Ontario | CA |

</details>

<details>
<summary>Membership and Registry source receipts (60)</summary>

| Evidence stage | ID | Method | Item | Canister | Observed at | Argument SHA-256 | Reply SHA-256 | Bytes | Rejection |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Membership preview · Governance | 1 | get\_proposal\_info | 145075 | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 15:50:14.330 UTC | 4dc5c7a743336805a34bbe089103f45ae200939a088673df09040296f751bd83 | fd8778f26a185a130589379f67edce203d1273739f75e571769b3c46056660ce | 7898 | — |
| Membership preview · Registry | 2 | get\_latest\_version | Registry head | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:17.025 UTC | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | bd45fd57b94f01cffaf16ad5662ede11d57f4baa0991f66b106c8f7d51038105 | 4 | — |
| Membership preview · Registry | 3 | get\_value | subnet\_list | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:19.374 UTC | 1dbea7d679ccb4b140993adb9a09d4aff6ca02cf86e64bfc0587a897245a6acf | e700ca41381ba571f790b439875b923b4845fc269cfdb27ba1cb7dff6643f2b1 | 3055 | — |
| Membership preview · Registry | 4 | get\_value | subnet\_record\_4ecnw-byqwz-dtgss-ua2mh-pfvs7-c3lct-gtf4e-hnu75-j7eek-iifqm-sqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:22.173 UTC | b15329e9ffae1b8568924265a1b23e7bdb7d8d96676a40ea89e42f8398d8a73c | 27ff1a34a9ac9040d83ffb969bfe1b5c0664c0ad5fd41784802665bea6dd490a | 496 | — |
| Membership preview · Registry | 5 | get\_value | node\_record\_6jidn-uqgyz-hl2l3-ou2rg-slu73-iztvd-yhdu7-hjfuz-cy4wc-jvoqc-uae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:25.199 UTC | a989ce0e1350ee59e488cac3f84755f0b604e2987c20effaabe7e470c5ad7d75 | 7a669ebf8b77f7f248fe0d148f626120cae170f559268c99a4ea484d4482d7e9 | 178 | — |
| Membership preview · Registry | 6 | get\_value | node\_record\_o42ny-ab3zt-iknyx-eo4ji-utgbe-xmae4-ybmwp-wdkzt-efffe-oq6nh-oae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:25.199 UTC | a442e6efdfadb0b5774f9a00219addf88cc366a258b408d073abebcddc2bfd79 | 0129d72063817cb1251d4a89e33405265e8e136a6d2545854faddafa1377b515 | 176 | — |
| Membership preview · Registry | 7 | get\_value | node\_record\_gfeqv-7ndps-okvma-qxwsi-ozk4x-b5wyp-hzwmb-v6g5t-dmen4-aff4d-zae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:25.199 UTC | ab20fd7a469507123091b31e9130ff97545accc8d2e5d1e9098b3c7398d7b4c0 | fa6c3e8ba5aa70aa1b39f5cd24e2020da6657c4039022c7f619ff0e6d85c6ef0 | 237 | — |
| Membership preview · Registry | 8 | get\_value | node\_record\_vw36t-lgksm-5cgtg-ait3y-sy25v-gdtsq-en6oe-md35y-a7cji-uiryt-3ae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:25.199 UTC | 1d79ba73048e3daf83d024c09f402a33daad962ec784e9daadffe624f10801a4 | aa9ece81ad5d1e0328dab2c0d599975960e9442573cb34836f2c9f1cc5cee1e4 | 184 | — |
| Membership preview · Registry | 9 | get\_value | api\_boundary\_node\_6jidn-uqgyz-hl2l3-ou2rg-slu73-iztvd-yhdu7-hjfuz-cy4wc-jvoqc-uae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:28.378 UTC | 1089c081322c27e547e3f5a169478fef42606792ca0c034032e5f46367f2f7f2 | 1ddc3fce10be7b4c00bdd5461747cee793c044f5cae54147a893d1e8238f31f0 | 91 | — |
| Membership preview · Registry | 10 | get\_value | api\_boundary\_node\_o42ny-ab3zt-iknyx-eo4ji-utgbe-xmae4-ybmwp-wdkzt-efffe-oq6nh-oae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:28.378 UTC | c8851bde6b126255e5564d0739d32b3bd1baebf9db3df35bedef3f06a8390cea | fabc47460ae2c542794ebee92d57e0c65e1c9eea883970459b6d65629a0d5816 | 91 | — |
| Membership preview · Registry | 11 | get\_value | api\_boundary\_node\_gfeqv-7ndps-okvma-qxwsi-ozk4x-b5wyp-hzwmb-v6g5t-dmen4-aff4d-zae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:28.378 UTC | c1374a23bb0b44af2cf5ac822f54592d9ce55e985c786b2e7f028ffef03d3636 | 495456b9a625c00b43b59f20e1e488c98399bd57c7eb0b322d58da42b9e8fcd4 | 91 | — |
| Membership preview · Registry | 12 | get\_value | api\_boundary\_node\_vw36t-lgksm-5cgtg-ait3y-sy25v-gdtsq-en6oe-md35y-a7cji-uiryt-3ae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:28.378 UTC | 5f46451f03b023cd8ce52b013459fea6b0025d9095f9eaa31835c34dfd5690a1 | eeea0de169e5d4a8c891bf4db6c718f9d77914e2d99784838945e819845dd2ad | 91 | — |
| Membership preview · Governance | 13 | get\_proposal\_info | 145075 | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 15:50:31.061 UTC | 4dc5c7a743336805a34bbe089103f45ae200939a088673df09040296f751bd83 | a811af5027d1ead391cd6dc6aaecfe86bb97f48f0dd8041237285948f5fb407d | 7898 | — |
| Registry enrichment · Nodes | 1 | get\_value | node\_record\_vw36t-lgksm-5cgtg-ait3y-sy25v-gdtsq-en6oe-md35y-a7cji-uiryt-3ae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:37.143 UTC | 1d79ba73048e3daf83d024c09f402a33daad962ec784e9daadffe624f10801a4 | aa9ece81ad5d1e0328dab2c0d599975960e9442573cb34836f2c9f1cc5cee1e4 | 184 | — |
| Registry enrichment · Nodes | 2 | get\_value | node\_record\_rwze6-4mvpx-o5pdv-3sujg-2szcx-223oi-f3jnl-jx27g-2qs22-dmt2j-jae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:37.143 UTC | 44e8224f20064cb0c64ee4a2074c8b075b5c19829b717e0ed578c9d9acb97cbc | fc5911a45a05d08bf233fe84614bed7df908463544d4e089b6baf8462fb6acd5 | 180 | — |
| Registry enrichment · Nodes | 3 | get\_value | node\_record\_lpkij-6jgir-sukcx-6kplx-qddla-ufncr-e3m2p-kikly-bcwzd-mtslj-4ae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:37.143 UTC | 2d9e923dffaf82ac4e039ff8ebdb64f7e0423949021eaa50e04bed64ce3fdaff | b446d28c4b59b276997cb55bb1445785c24842f3e12d93384c6583fffab73bd3 | 184 | — |
| Registry enrichment · Nodes | 4 | get\_value | node\_record\_hhixb-o5xrj-s5pty-esitz-m6s46-wgsez-c7thd-6h27w-7hikq-ae5n7-pae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:37.143 UTC | fa19540d0c1a07caa212883128c63bf89c52411930e08a4c9f72c38e89c33ec8 | 327dc2a55047a7c77fdd7e38ec345082fd25da810fb2df56060ea64533c9e8a3 | 178 | — |
| Registry enrichment · Nodes | 5 | get\_value | node\_record\_ns7kv-kp2mu-mw7yi-krd4z-eqcvq-qeeej-mxtwb-c2ujq-xtq6x-orzoj-3qe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:37.143 UTC | 0c7311e73ced26a17a8ab2f259f42f1a2eacc26792a148ca570d9955f66d4c0c | 88d7887bc0fb28fe240a058eeb1ace156eca65ec55962573ba7916a312969093 | 180 | — |
| Registry enrichment · Nodes | 6 | get\_value | node\_record\_c3syk-l56ky-owcvg-y4ogf-3qfti-elv4e-2bqp7-k5v32-ibzm6-o4k6s-eqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:37.143 UTC | 68e1e3e80679395edc0422ef48775965768d3cda08fc08612fd464cbe1fbdc10 | 0c70fbf8cbbc44ce3f7f8726cf54399b52f819998edd46876a0baccede8a5263 | 172 | — |
| Registry enrichment · Nodes | 7 | get\_value | node\_record\_b5pgw-6wtjo-dzwgu-zkfz6-3l5f3-cw6ka-y4crr-dikku-fkjbe-lfzki-qae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:37.143 UTC | d72ab253922823d08f532b01174793b884691644e4d7bd1af12f81a0d2cf8859 | 3307408a851918052ec1f05157377164ff3b83526b28039610aeaf0f24311349 | 182 | — |
| Registry enrichment · Nodes | 8 | get\_value | node\_record\_5ttnf-xhdip-7e2uw-iuikh-5dlli-r6jdc-nxjp7-bjumm-5usid-rpiqn-jqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:37.143 UTC | 519cc07ca3c3121f853f0fade41ac27b6a3fb6921a74a5c073a5c4e7d903c79d | 80c15ae3deb7426c49048c4dc05b811c986731cbb690e7d160c500da0a6f0378 | 186 | — |
| Registry enrichment · Nodes | 9 | get\_value | node\_record\_7f5c7-l7cuq-7jnfc-yexo3-bytd3-yf6xa-ctk76-wywln-jsy2n-ds2lp-tqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:43.091 UTC | 40f3eba0a6735fdd3d4d4465acdd36a374340a775823da3147a2fbc97c837a92 | a5c69f0b556f4c8edf0dec489a5d97b6efacebf43bb994baad8efc48d5c0af14 | 176 | — |
| Registry enrichment · Nodes | 10 | get\_value | node\_record\_rfe2u-pdp5u-frzdb-r2ga3-5jept-24323-5pere-7lerg-toh4w-cwdsl-cqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:43.091 UTC | 7c9673f3d33dcfc46540da5eb7fe4aae8007548dd183df9490c6f42702b0c421 | 5c3666538fc088ba879e4e81710e79fcb741d6d6e2b0357a3bd511ece3c7af1d | 184 | — |
| Registry enrichment · Nodes | 11 | get\_value | node\_record\_m4e6a-3t7oi-ooshc-2b2vq-56xpu-pyo7q-qafn2-3sem2-cvtck-6xfqy-vae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:43.091 UTC | 4d3dadbc29e1f103af3d08f6186131311014243eeea73e8cc67d54eb4c34321d | 7f9b6157c03ccf90a89956ed5dba155655021c22a58db042778f70865cf83b3d | 172 | — |
| Registry enrichment · Nodes | 12 | get\_value | node\_record\_o42ny-ab3zt-iknyx-eo4ji-utgbe-xmae4-ybmwp-wdkzt-efffe-oq6nh-oae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:43.091 UTC | a442e6efdfadb0b5774f9a00219addf88cc366a258b408d073abebcddc2bfd79 | 0129d72063817cb1251d4a89e33405265e8e136a6d2545854faddafa1377b515 | 176 | — |
| Registry enrichment · Nodes | 13 | get\_value | node\_record\_4vwpn-budhw-o2kvm-axlue-sr5lt-vy3be-ammju-rw22w-w4qtn-sns52-3qe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:43.091 UTC | 764baee8dd557a0be3823fdebeb71cddb6dd75814b356719d1df2c735c5f7f98 | 0537977a8749d0ea4358efdf0062f52d9c9c625ff290797b24b840de621e6ddb | 180 | — |
| Registry enrichment · Nodes | 14 | get\_value | node\_record\_6jidn-uqgyz-hl2l3-ou2rg-slu73-iztvd-yhdu7-hjfuz-cy4wc-jvoqc-uae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:43.091 UTC | a989ce0e1350ee59e488cac3f84755f0b604e2987c20effaabe7e470c5ad7d75 | 7a669ebf8b77f7f248fe0d148f626120cae170f559268c99a4ea484d4482d7e9 | 178 | — |
| Registry enrichment · Nodes | 15 | get\_value | node\_record\_gfeqv-7ndps-okvma-qxwsi-ozk4x-b5wyp-hzwmb-v6g5t-dmen4-aff4d-zae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:43.091 UTC | ab20fd7a469507123091b31e9130ff97545accc8d2e5d1e9098b3c7398d7b4c0 | fa6c3e8ba5aa70aa1b39f5cd24e2020da6657c4039022c7f619ff0e6d85c6ef0 | 237 | — |
| Registry enrichment · Operators | 1 | get\_value | node\_operator\_record\_mw64v-jynex-7tu52-5a3te-ifbop-nh7y7-w7lno-ymmht-b7fmy-wfhha-gqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:49.800 UTC | d910e59a319594303073416ef85b55d323b4f7b0a5f4602f72ed46f7da4e6cdc | 9e807809b50c46f444d850166529b66e5d0d22c627909bae03e84e0cf4465284 | 111 | — |
| Registry enrichment · Operators | 2 | get\_value | node\_operator\_record\_cqjev-4qb7l-xv373-jfmhi-73n3a-cxhst-p6okb-vywwc-a4zbi-6sf3u-bae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:49.800 UTC | 2262fbf6fa617f9c676271d5bf219c525f178ff5f29701d68e0e99cb11394061 | a9774eaf2940ff011d989d5ad018cb6a3c9ee6c4ff556b759dfbbafcd31a2130 | 111 | — |
| Registry enrichment · Operators | 3 | get\_value | node\_operator\_record\_5dwhe-vpbuf-zz5ml-ylu6k-7y2z2-36ywv-5e4wf-advxd-3endk-icvg4-cae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:49.800 UTC | 550f4b3182ee6ef172394e6f2d4fb00cf4700de361f21decf839bf6168779ec8 | 4cc5f6d9165cdb5591c42e77c5d853080915003c4a3e8ba987d74bab09397a77 | 111 | — |
| Registry enrichment · Operators | 4 | get\_value | node\_operator\_record\_gl27f-y5srq-yy5ot-v4x5z-y2a2s-sgoor-l4gjg-qv4x4-v2olb-dz4dc-wae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:49.800 UTC | 1319bd423a9009b5cf0ef53d711920dfe028ad286be1725ffc1f572028891fce | 1fa4d72537af8fbd1798916221dde161175a7fad9a85f05b40e303dc74d705c1 | 111 | — |
| Registry enrichment · Operators | 5 | get\_value | node\_operator\_record\_4lp6i-khv7q-lkgk3-hhrc6-ysjag-korh7-ysojw-7gv3h-glhdz-rpjrt-sqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:49.800 UTC | 462a7f2fd03c97dc15830685f807332df84d5eb79a0cf72cbd6687ed9cf68241 | 1c6bda60eae8cdff26d68fd39a03abc7a4a3d5a693b95fb47240be9e38353c81 | 111 | — |
| Registry enrichment · Operators | 6 | get\_value | node\_operator\_record\_vzsx4-ldpic-3zcoa-mfki2-gfsai-ok7ap-gb2sp-fxvaf-ckd7h-jluem-qqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:49.800 UTC | 55e984156709b4b8ef4f4ff7a69bb3af0d814956a2182696bae72907e0230512 | 44bc513d4b155b70e86714f0ee2c47539051d6ba62b09dcb59ce3fe14f54d003 | 133 | — |
| Registry enrichment · Operators | 7 | get\_value | node\_operator\_record\_d4bin-5o2wg-ycbdq-yljr7-45pjv-ptf6d-v243j-vg6x5-dlo7t-yqu62-5qe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:49.800 UTC | b892bcca7d3509eaebf83ce92e97e15c2c72e94e850bae491edc95007344b6c8 | 605f0773da9d12d3a9428068393a1a7c258702ca68243fe5bdee8db153e02aaa | 111 | — |
| Registry enrichment · Operators | 8 | get\_value | node\_operator\_record\_ceta5-wu56p-aqtjd-2cy2f-atzz3-srckr-wkupd-ratc5-62ckj-vsj5u-zae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:49.800 UTC | 1bd066f40581fc4411f263cca0958e5bfa764d051859d35043b2f2977e1cd18e | b9964b3dca3a1e669662620ab3bdc113095c01dd9bea7d06c40dc7a70f792f82 | 109 | — |
| Registry enrichment · Operators | 9 | get\_value | node\_operator\_record\_srrm2-zawrj-4euwg-w24k6-yiwlj-ln6r7-kxkgb-itaal-efw4m-fp36x-bqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:52.723 UTC | b021ecc82ea9ca30bf328efcac83f828c4b01ce59bd853a917a45d7740f5c06f | 3aea40e782647273540a97a57fd901e889f6feff88d8d0d75923e6c8739036c6 | 111 | — |
| Registry enrichment · Operators | 10 | get\_value | node\_operator\_record\_lgp6d-brhlv-35izu-khc6p-rfszo-zdwng-xbtkh-xyvjg-y3due-7ha7t-uae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:52.723 UTC | f153a65b722b1a93a4c2c2a1f0f210837766881b307336eae93f3036c180c012 | 8b2fbe78cc4b1377882bb74555264106dd4c5970f199b579868fc3e5a41245fc | 111 | — |
| Registry enrichment · Operators | 11 | get\_value | node\_operator\_record\_5atxd-q4jom-dtpxr-awd3p-e562x-hpavj-godtj-g6vmz-of2c6-ildhh-fae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:52.723 UTC | 27ad863c3f39d02511ff609911dee6d38f1563e5aef7e823a141eb03e1e1e0ab | 1388360b56112f1080e9e265c5876cad17e78f9dfb72f6bdaa76175bd01542aa | 111 | — |
| Registry enrichment · Operators | 12 | get\_value | node\_operator\_record\_c5ssg-eh22p-pmsn6-fpjzj-k5nql-mx5mc-7gb4a-4klco-c4f37-ydnfp-bae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:52.723 UTC | 98afa47e37b6d8376af020f55d36a9f55cb19991d3f2802ecf9a7041c338e143 | 128462328aa19548d24a54eaba4828106e7356c0fa51840aadbfe457f95f79bb | 111 | — |
| Registry enrichment · Operators | 13 | get\_value | node\_operator\_record\_mpmyf-juliu-5qwcu-ofamg-es7ug-4mjt4-w5lht-dbrfb-ualjm-hcwmn-pae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:52.723 UTC | 19c8bc437952a32867b7a151f71879da2482eb47d058be6f8e7e17b7353cff4b | 6a7dbb73f28bf7888c6b63b45b52abcd8bdaecd4663cec1e90dff9b30aeae692 | 107 | — |
| Registry enrichment · Operators | 14 | get\_value | node\_operator\_record\_tcn4t-xktz4-qm6yk-udidk-m5ays-paeqx-xaevx-hb3fj-nvocf-vr5yq-yqe | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:52.723 UTC | e47f94c46c1055dec5b4baebc85c5759e60cfe0517e07677bf4b793c84aba316 | 0c63e5539bc101473560d2685889b489f77901b6423ba7c479380c8074ecf540 | 111 | — |
| Registry enrichment · Operators | 15 | get\_value | node\_operator\_record\_eqv2i-6dtlf-bhbjd-2popw-vvavp-7xzci-6gdd7-qxgox-wdw5w-l3a4w-eae | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:52.723 UTC | c4e003ff8f5f3763af298037603084e07c90a672817da71f2e30f3e6f0ec83d4 | 6b7740d875f1b76f831a1a1da78af8d43637c69c3b28223a2a401de13c203d5c | 111 | — |
| Registry enrichment · DataCenters | 1 | get\_value | data\_center\_record\_dl1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:57.040 UTC | 64417fb5f578974c69c27b4f16e3ba059841508bea9e93098b4460ef81ae6e9d | 570fa1dfc7c9ae7e05f1781a760e9c465be126482cc23cd77369d86b3b103dfe | 59 | — |
| Registry enrichment · DataCenters | 2 | get\_value | data\_center\_record\_ty1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:57.040 UTC | 3f1a6906edcf84f6f1fc83d01a57ab0cee594bb25b6d9d3176a39e21eb8011ca | 562ce9f18179c196651cb665a7ff23f21e4030b94edd71891bb896fd5ba3957e | 47 | — |
| Registry enrichment · DataCenters | 3 | get\_value | data\_center\_record\_kr2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:57.040 UTC | 8ae847446d8a3d6ffb25e03397fae6469010bfd9ac17df35922774355934271f | db8915b061b89414bd5d72c79c882d410d26ad5074cc0001e3609d77d6b68e26 | 45 | — |
| Registry enrichment · DataCenters | 4 | get\_value | data\_center\_record\_lj1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:57.040 UTC | f892782b0d155b10dc5d38f4c4b69e171b18fd4ccf3e8b983377fe14b7e1ec02 | 5f6dae6011b9f61e3f1c0a7710009816800e54292d1ffc313b541ab4b5d6e9db | 55 | — |
| Registry enrichment · DataCenters | 5 | get\_value | data\_center\_record\_to2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:57.040 UTC | c9146384ec3f68e95fb75c941e7a13512b4bf657d34395cfdc1af9f9d9e89a71 | 7161762007c951239545c9fc2ea667c99df4da49bb96ee366972bceaf74e6741 | 58 | — |
| Registry enrichment · DataCenters | 6 | get\_value | data\_center\_record\_hk1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:57.040 UTC | ed6ea8bd764020e1401c36836664f523288ccaa350374d7369aa2bd4938312b0 | a0623e80bc5fc3d5997b639dc9df02b6b416761e26f48d8a04c020945680943e | 49 | — |
| Registry enrichment · DataCenters | 7 | get\_value | data\_center\_record\_sg1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:57.040 UTC | 3c397f337d86c7811f33ad98cc62337f6ab5ec65c05f9c06cc5ed3f89b9b995b | 8063f1b111f69a286f34d0ee712ad6a834f57a52f62aab5634039a231095e7c2 | 49 | — |
| Registry enrichment · DataCenters | 8 | get\_value | data\_center\_record\_si1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:50:57.040 UTC | 56e781c91456c19934d7939c7d4d6d772469d0b9b46b00ac0ffc769af0692145 | 306ee5dea512812cd1ba03aae403591f8e8be724f4d5c9a2f76a00815274da91 | 52 | — |
| Registry enrichment · DataCenters | 9 | get\_value | data\_center\_record\_sc1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:51:00.121 UTC | f26dd4fed558d9cb57d8b602488f0873a2cfd8e5f0047dcee53ba6b1f549937c | f6eb434904757db5ba0765775edb48f20eabc6f2c54a2e87823351cff4d164d6 | 54 | — |
| Registry enrichment · DataCenters | 10 | get\_value | data\_center\_record\_sh1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:51:00.121 UTC | 0354a9e3297c0984bc8241b2eba6aafc4e14d31db4c3aba7cd8217e9bb4cb01c | 5efaa12dbed1f6f6ec61857abab3f001b8e7c8193e92b72642dbe71707ae36c9 | 60 | — |
| Registry enrichment · DataCenters | 11 | get\_value | data\_center\_record\_ge2 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:51:00.121 UTC | cb100ed116d0e70f5c0eb78224784e277d0d3266836836a1a485352450bc4017 | f5fe58753652335ca955fa15826fe946c69cd3d4350511c5d5916827829d0e78 | 51 | — |
| Registry enrichment · DataCenters | 12 | get\_value | data\_center\_record\_bu1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:51:00.121 UTC | 0e94bfe4a5bed1feaa158188e139d1cfb9fef4518e6969e04a1c23d862b2c6c5 | 10a377d477c585d54013f0b053ef7a8772021450ce81f964d8822fde1c2975f0 | 51 | — |
| Registry enrichment · DataCenters | 13 | get\_value | data\_center\_record\_nm1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:51:00.121 UTC | ba7db443f4f39373001c85bbc42415339a2bd3c111d6ff2734b61e341c74cb6a | 9a733b9f0173f0ea07b5c547c98b810e13255a83f31f7be6fa6eb161ccd22e76 | 52 | — |
| Registry enrichment · DataCenters | 14 | get\_value | data\_center\_record\_st1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:51:00.121 UTC | 51de1c400f5108422a2f8b33db8e7231e24d69b2b9a6c36d7c5c2b70138aec25 | 2cba13159fecab221976e21b19f083d67966d72504aa39240762470af323e68d | 60 | — |
| Registry enrichment · DataCenters | 15 | get\_value | data\_center\_record\_cr1 | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:51:00.121 UTC | 3557b25c3e6920505812e4d9a08db8d7187150785ffa99fe325e67cc95f10d73 | 396b20861d1ecadfb9253527f6faea6e023b4b3653ae4c5a98a43ea51e7d2d25 | 60 | — |
| Registry enrichment · Role | 1 | get\_value | nns\_subnet\_id | rwlgt-iiaaa-aaaaa-aaaaa-cai | 2026-11-28 15:51:04.012 UTC | 5942977e9a098e584fe8a7390e599e506d2c9cf8a2726db05c8f0771cd0d2726 | 74ca3bc2b0e0a7a0f6c02c9a4f286cbd1616ef3b3ce2cae7ecf2495d691d6154 | 37 | — |
| Final Governance verification | 1 | get\_proposal\_info | 145075 | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 15:51:10.503 UTC | 4dc5c7a743336805a34bbe089103f45ae200939a088673df09040296f751bd83 | f7fd917298687aba60f9438b01a6a9a62e5f7603e4b17722b91a929c75572f0a | 7898 | — |

</details>

<details>
<summary>Accepted Governance discovery source receipts (6)</summary>

| ID | Method | Item | Canister | Observed at | Argument SHA-256 | Reply SHA-256 | Bytes | Rejection |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | list\_proposals | Open and adopted before None | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 15:51:17.525 UTC | 8178e19650c447132e0ca1b72f81e65df3e5200f15038b56141093b9a7e553eb | c6322a540a7acbd91829cd2a1c60aec9a9826ab9dc958f3e41af0296a4e7b401 | 40616 | — |
| 2 | list\_proposals | Open and adopted before Some(145072) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 15:51:20.946 UTC | aa80da650b49c62fbec334b60793fa82bfd49ecf264febd305c8c17a5c17cf00 | 15f49d666f9e17f67a9279cb31f2772db7aab3e255f7f5fbf47937b6f4a0ac1f | 54421 | — |
| 3 | list\_proposals | Open and adopted before Some(145062) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 15:51:24.613 UTC | 9e3a2e6a598604d6c95480bfdb3e4aa3df06549b8324b4439e8603396c0279ae | 5dea2a71e904674d501345c72e4d502d8795e3ba511244705fb929ac9a807c0e | 46297 | — |
| 4 | list\_proposals | Open and adopted before Some(4570) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 15:51:27.785 UTC | ce0ed7e76562155297b3205ac5c351d60ad2445d43fd7e73f365de492bd36607 | e7526b511990ca317ad44bea6329d58680d3dde017d8244f44a3bd8a8b95ea5a | 8998 | — |
| 5 | list\_proposals | Open and adopted before Some(1520) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 15:51:30.842 UTC | b6515ac79a94d09698c9b7c9c276a67d6be5a54bc15556fed4af152210e7fa63 | d26de1dc6a3cd89e8a040fac13c7333799593756fa201dcd6368452bb2ed72f5 | 13959 | — |
| 6 | list\_proposals | Open and adopted before Some(340) | rrkah-fqaaa-aaaaa-aaaaq-cai | 2026-11-28 15:51:33.295 UTC | 6aa61d071a144ad5e73cf212b24645bb51cfdac8308c2ad14b233613dd5953a4 | 3548dbeb53d501d199e613b3427784c8a3f8b9b34ff3cfee6ddd2870c411c693 | 2670 | — |

</details>
