# Proposal review · [#990011](https://dashboard.internetcomputer.org/proposal/990011)

Proposal #990011 · After proposal #990011 · Step 1 of 1

Subnet [5ag63-q3yke-ba](https://dashboard.internetcomputer.org/network/subnets/5ag63-q3yke-ba)

Bundled test case · Synthetic scenario · Constructed Open proposal · Registry 100

## Proposer’s stated purpose · #990011

Synthetic subnet membership change

[Full proposer statement](https://dashboard.internetcomputer.org/proposal/990011)

## Summary

Add 4 and remove 4 nodes. The subnet remains at 13 nodes.

13 members · Add 4 · Remove 4 · Unchanged 9

Checked all 1 listed subnet memberships. Full execution validity remains unverified.

- NNS role was not recorded at the pinned version

## Evidence scope

Pinned Registry version **100**. Governance checked after the selected comparisons.

- #990011 · Constructed status: Open · Synthetic Governance action · Fixture backend observed 2026-11-28 10:14:44.680 UTC

- NNS role was not recorded at the pinned version
- Proposed membership is conditional on the pinned evidence. Full execution validity remains unverified.

Original Registry observation times unavailable for this replay.

## Review checks

Conservative availability model. The fault budget is floor((N − 1) / 3). Model departing nodes unavailable in the before-state and incoming nodes still synchronizing in the proposed state. The smaller margin applies. A margin below one triggers a warning. The cumulative case keeps all earlier arrivals unavailable while they remain in the subnet. These conditional margins do not establish global assignment, execution validity or actual liveness.

### Step 1 · Proposal #990011

Add and Remove are disjoint · Add duplicates 0 · Remove duplicates 0 · Membership preconditions · Established within the checked membership scope

Conditional step margin · Warning · zero margin. One further fault would exceed the modeled budget

<details>
<summary>Instruction and margin arithmetic</summary>

- Duplicate Add principals · none
- Duplicate Remove principals · none
- Overlapping principals · none
- Individual step · 5ag63-q3yke-ba · Before · 13 members, budget 4, modeled unavailable 4, remaining 0 · Proposed · 13 members, budget 4, modeled unavailable 4, remaining 0 · Limiting side: both states · Margin 0

</details>

Governance check incomplete · 0 references found

- Sources uxrrr-q7777-77774-qaaaq-cai · 4 admitted reads

- Discovery observed 2026-11-28 10:14:45.012 UTC to 2026-11-28 10:14:45.012 UTC

- Pagination complete · 2 pages · oldest listed #990011 · Open 2 · Adopted awaiting execution 0

- Title, summary and supported motion text checked for 2 proposals · Supported actions decoded 1 · Hydrated 1 · Lifecycle changed 0

- Unsupported actions 0 · Missing payloads 1 · Malformed payloads 0 · Omitted findings 0

- Findings restricted to accepted instructions for #990011 · Review-specific discovery.

- Proposal #990012 has no available executable payload.

## Map

![Map of registered node locations for the selected comparison](map.png)

Add (green) · Remove (red) · Unchanged (blue). 17 unique nodes across both states · 17/17 located. Positions use the registered data-center coordinates. The dotted halo indicates multiple node identities at the same coordinates.

Natural Earth map-unit boundaries are cartographic. Country shading uses recorded membership groups. Green shows increases and red shows decreases. A dashed border marks a country falling to zero. Small squares mark represented map units too small to see at the current zoom.

Unmatched recorded country labels remain in the distribution.

Changed sites · fixture-0 · 7 nodes · fixture-1 · 6 nodes

## Node changes

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
| Remove | [kk3lb-f3yae-ba](https://dashboard.internetcomputer.org/network/nodes/kk3lb-f3yae-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
| Remove | [pgn6g-vdyai-ba](https://dashboard.internetcomputer.org/network/nodes/pgn6g-vdyai-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
| Remove | [mcane-flyam-ba](https://dashboard.internetcomputer.org/network/nodes/mcane-flyam-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
| Remove | [f7auj-utyaq-ba](https://dashboard.internetcomputer.org/network/nodes/f7auj-utyaq-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
| Add | [2uxky-wdyby-ba](https://dashboard.internetcomputer.org/network/nodes/2uxky-wdyby-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
| Add | [zq2z2-glyb4-ba](https://dashboard.internetcomputer.org/network/nodes/zq2z2-glyb4-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
| Add | [afxzh-b3yca-ba](https://dashboard.internetcomputer.org/network/nodes/afxzh-b3yca-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
| Add | [db2kf-rtyce-ba](https://dashboard.internetcomputer.org/network/nodes/db2kf-rtyce-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |

<details>
<summary>Other Nodes (9)</summary>

| Action | Node | Data center | Data center owner | Provider | Operator | Country |
| --- | --- | --- | --- | --- | --- | --- |
|  | [g3nhl-e3yau-ba](https://dashboard.internetcomputer.org/network/nodes/g3nhl-e3yau-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
|  | [dx3sm-udyay-ba](https://dashboard.internetcomputer.org/network/nodes/dx3sm-udyay-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
|  | [atwbo-elya4-ba](https://dashboard.internetcomputer.org/network/nodes/atwbo-elya4-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
|  | [qn2ax-xtyba-ba](https://dashboard.internetcomputer.org/network/nodes/qn2ax-xtyba-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
|  | [tjxtv-h3ybe-ba](https://dashboard.internetcomputer.org/network/nodes/tjxtv-h3ybe-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
|  | [wfbgs-xdybi-ba](https://dashboard.internetcomputer.org/network/nodes/wfbgs-xdybi-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
|  | [vbmvq-hlybm-ba](https://dashboard.internetcomputer.org/network/nodes/vbmvq-hlybm-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |
|  | [44mm5-wtybq-ba](https://dashboard.internetcomputer.org/network/nodes/44mm5-wtybq-ba) | [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Synthetic owner 1 | [ga4h3-xlffi-ba](https://dashboard.internetcomputer.org/network/provider/ga4h3-xlffi-ba) | d3g3k-r23fi-ba | Label 1 |
|  | [7yb77-g3ybu-ba](https://dashboard.internetcomputer.org/network/nodes/7yb77-g3ybu-ba) | [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Synthetic owner 0 | [gh5bp-2tefi-ba](https://dashboard.internetcomputer.org/network/provider/gh5bp-2tefi-ba) | d4h56-4c2fi-ba | Label 0 |

</details>

## Decentralisation

Arrows show before → proposed; a single value is unchanged.

### Different groups represented

How many different registered groups have at least one member in this subnet?

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 1 | 2 | 2 | 2 | 2 | 2 |

### Largest group size

The most subnet nodes sharing one value, such as one provider or one country label. Several groups may tie.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 13 | 7 | 7 | 7 | 7 | 7 |

### Nakamoto coefficients

How many of the largest registered groups together contain more than one-third of the subnet's nodes? Each state uses floor(N / 3) + 1. Recorded groups do not establish independent ownership, subnet safety, execution validity or Target Topology compliance.

Node threshold: 5.

| Continent | Country | Data center | Data center owner | Provider | Operator |
| --- | --- | --- | --- | --- | --- |
| 1 | 1 | 1 | 1 | 1 | 1 |

### Distances between registered node locations

Straight-line geographic distances calculated from registered data-center coordinates, counting each pair of nodes once. These are not measured network latency or health.

| Shortest | Average | Longest |
| --- | --- | --- |
| 0 km | 3,585.0 km | 6,657.9 km |

78 of 78 pairs before and proposed.

No current Target Topology thresholds, exceptions or applicability are assumed.

<details>
<summary>Recorded country membership</summary>

| Country (recorded token) | Subnet members |
| --- | --- |
| Label 0 | 7 |
| Label 1 | 6 |

</details>

## Sources and calculation

Membership preview revision `fddf034327e0097c384d47d31603b223cb816dae8d8d4aefac5e7fc517568b5d`.

Calculation input SHA-256 `1b6c81d774f89c634afda74011096061d396d9414af30c000517ba1fd1293c86` · analysis v5.

The replicated calculation digest identifies the exact submitted evidence and scope. Source receipts identify the separate Registry and Governance observations.

- #990011 executable payload SHA-256 4b807560a6a8e75401798b83a5386b92ccfbdeebf490a0ae1292c43db4899ec1

<details>
<summary>Exact distance evidence in metres</summary>

| Distance | Before | Proposed |
| --- | --- | --- |
| Shortest | 0 | 0 |
| Average | 3584997 | 3584997 |
| Longest | 6657851 | 6657851 |

</details>

<details>
<summary>Registered geography evidence</summary>

| Data center | Original Registry region | Country token |
| --- | --- | --- |
| [fixture-0](https://dashboard.internetcomputer.org/network/centers/fixture-0) | Fixture,Label 0,Synthetic site 0 | Label 0 |
| [fixture-1](https://dashboard.internetcomputer.org/network/centers/fixture-1) | Fixture,Label 1,Synthetic site 1 | Label 1 |

</details>

<details>
<summary>Membership and Registry source receipts (44)</summary>

| Evidence stage | ID | Method | Item | Canister | Observed at | Argument SHA-256 | Reply SHA-256 | Bytes | Rejection |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Membership preview · Governance | 1 | get\_proposal\_info | 990011 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | 34120e54b09d36b4c77715feca238d83584c71ea0ce9ddcf55d81903f0b56537 | 1d275ce6db37fb87a5e653bcef9394aba3a3f7e4746bd7813a9096e187375f8b | 440 | — |
| Membership preview · Registry | 2 | get\_latest\_version | Registry head | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | c0bffeaab8e16948afec4ac6e56088d8072a68d0788301b53e60560e8d85ce58 | 2 | — |
| Membership preview · Registry | 3 | get\_value | subnet\_list | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | 7b015b3b4f6a5d6f2354c4392603ed1e27adb7b7422646eedd217ca2ef85edf1 | 40061793c7ab638a07e0263d0c9edc78271ddc35825f444a9714da4e659a47e1 | 9 | — |
| Membership preview · Registry | 4 | get\_value | subnet\_record\_5ag63-q3yke-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | 671ff200155d9ab6380c902d8e4d0851ba128cf352d7a8507a8b27a13c9fdea8 | f518a8db3a5cd45d6a3cb7f3338014b81b364561d521e4eaf8de2a9feb905d4e | 71 | — |
| Membership preview · Registry | 5 | get\_value | node\_record\_kk3lb-f3yae-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | 235e029c22e90b1165c9624669eb5a690f92499c384f7d257d1c23d85224e552 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Membership preview · Registry | 6 | get\_value | node\_record\_pgn6g-vdyai-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | d59909f87f4f1f02e34dcd60eeec13782416c9967716db86a1d9755d9c3a96b8 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Membership preview · Registry | 7 | get\_value | node\_record\_mcane-flyam-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | 6ab0dcbc3931634a0d9f0060f766ad91778ecc7308b01e304f7d091ae2acf163 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Membership preview · Registry | 8 | get\_value | node\_record\_f7auj-utyaq-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | e350bd8046ed3a4da73cfbae91cac2ece9fb9a6603c86f09c1fa72769962ae01 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Membership preview · Registry | 9 | get\_value | node\_record\_2uxky-wdyby-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | c978298b01887ea1df04d4dff4436e98bcf5a7917f93e11d7fb4c60e7ff54886 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Membership preview · Registry | 10 | get\_value | node\_record\_zq2z2-glyb4-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | d6e6ffbce451b87bc7a784fbe0c02639603d8e8afbc47cea5481e55cd05b9f4b | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Membership preview · Registry | 11 | get\_value | node\_record\_afxzh-b3yca-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | be0d16bcc8ac34aa2b30c17505392fd9a6e3dd266fe3cde81d764cc5266d3fbc | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Membership preview · Registry | 12 | get\_value | node\_record\_db2kf-rtyce-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | d93c39e5dad6b345f3a16946378899552765f79e963592138092e40b664726fb | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Membership preview · Registry | 13 | get\_value | api\_boundary\_node\_kk3lb-f3yae-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | 571f3e204e21cfa021ebd5cefdf8ea0a53bcc09a9a4cd457ef3fd199fbfd879b | e529d73779dbecacf4f438ddca5ffaf6acb7d5b8c21f4a2768d7cc15048628a8 | 66 | — |
| Membership preview · Registry | 14 | get\_value | api\_boundary\_node\_pgn6g-vdyai-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | 873a3488af5fec23a762f1d5003d7c4422ab85d40010840db433591a1e4481da | 6fb04ee8ef77f75ca6de77bb0fe1ac9dc783fa5ee5eb63b1b5ccfa1d0f4796a5 | 66 | — |
| Membership preview · Registry | 15 | get\_value | api\_boundary\_node\_mcane-flyam-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | effcc2501b5224c111aae8edae4f032c86ff1b1971747687c3ed1a415e1f4457 | 3d1df03ab5598250df94d18e4ac38e78f9b3ab6c3aebc3532df3f25dabd74633 | 66 | — |
| Membership preview · Registry | 16 | get\_value | api\_boundary\_node\_f7auj-utyaq-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | 3ecae51ed9af3d7beddcf8f50051f3c9d5e6aa30e5cb3ac0f6d135817318984a | de15154af0b9bf0ef9d96ea00a9f81c0bc45c7e5457a30b8bf9899366d24c725 | 66 | — |
| Membership preview · Registry | 17 | get\_value | api\_boundary\_node\_2uxky-wdyby-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | c9cbd674bbc64ea38a211bde93d474de29a97a4f9f188f058348599d515f77bf | 258bb64fae2f80a40d71481d8f44c333a54cc4ca8dcd83843ef61a12f1aea69a | 66 | — |
| Membership preview · Registry | 18 | get\_value | api\_boundary\_node\_zq2z2-glyb4-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | 8eb40b218e5c8da19e543e05e44fc9b1a9b0c2f35c30933616f64bfe3af213a5 | aeeeebd00c4f208437fae3789190f505d411271857052979b81205b050c3dc1a | 66 | — |
| Membership preview · Registry | 19 | get\_value | api\_boundary\_node\_afxzh-b3yca-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | 2e0a80f45584a1e244c641ac8999a66c1fbe890626f616d4496a163991c802d4 | 4bb10a22d6ab34079337fd0b5ea9cbedf8f5271d7e9fc6f6c6a27f489ff9a196 | 66 | — |
| Membership preview · Registry | 20 | get\_value | api\_boundary\_node\_db2kf-rtyce-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | 113fb09b22916391b42496b9776a498e004aa908cca5def2a4af5f72867b42a5 | eca77d053773859288f509bb0a34795a27f820c95f8ce7555a5aedcc6adeb9e3 | 66 | — |
| Membership preview · Governance | 21 | get\_proposal\_info | 990011 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.582 UTC | 34120e54b09d36b4c77715feca238d83584c71ea0ce9ddcf55d81903f0b56537 | 1d275ce6db37fb87a5e653bcef9394aba3a3f7e4746bd7813a9096e187375f8b | 440 | — |
| Registry enrichment · Nodes | 1 | get\_value | node\_record\_kk3lb-f3yae-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | 235e029c22e90b1165c9624669eb5a690f92499c384f7d257d1c23d85224e552 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Registry enrichment · Nodes | 2 | get\_value | node\_record\_pgn6g-vdyai-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | d59909f87f4f1f02e34dcd60eeec13782416c9967716db86a1d9755d9c3a96b8 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Registry enrichment · Nodes | 3 | get\_value | node\_record\_mcane-flyam-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | 6ab0dcbc3931634a0d9f0060f766ad91778ecc7308b01e304f7d091ae2acf163 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Registry enrichment · Nodes | 4 | get\_value | node\_record\_f7auj-utyaq-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | e350bd8046ed3a4da73cfbae91cac2ece9fb9a6603c86f09c1fa72769962ae01 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Registry enrichment · Nodes | 5 | get\_value | node\_record\_g3nhl-e3yau-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | 670273e3c423409dcc12e21200933dabf8a21456513bab85221563b17155e213 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Registry enrichment · Nodes | 6 | get\_value | node\_record\_dx3sm-udyay-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | c70a175e9b75ff9d0a96768bbd0cb4c02d54e218ba7b61d104297d4808a720a2 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Registry enrichment · Nodes | 7 | get\_value | node\_record\_atwbo-elya4-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | 4c3aee6d0201c2dbcba37843282408c468372a17186378c17026eaf12814cd0d | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Registry enrichment · Nodes | 8 | get\_value | node\_record\_qn2ax-xtyba-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | 4ad7dcba605553c5a3f531e51da0e5ba4fc01eb6e6d989427cead729c03fd3e1 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Registry enrichment · Nodes | 9 | get\_value | node\_record\_tjxtv-h3ybe-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | d60d5879d0be2cec7668473a6fef8a30ad4cdc5638caa82141b03f398ce2a298 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Registry enrichment · Nodes | 10 | get\_value | node\_record\_wfbgs-xdybi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | 17cd515a02dd9da0d9ea7f1906c1683ba6a62ef98aa3f50789817433e3443354 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Registry enrichment · Nodes | 11 | get\_value | node\_record\_vbmvq-hlybm-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | 902ae051c1022a1f512b9024528b01c8b95f63dc445cba092e516c739cd8eeb3 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Registry enrichment · Nodes | 12 | get\_value | node\_record\_44mm5-wtybq-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | a5a7185be187d81899b2aaa00f033320f231baaf690ef151a7baf2d8a5b0b7b1 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Registry enrichment · Nodes | 13 | get\_value | node\_record\_7yb77-g3ybu-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | 2a3d75cf417f5d52cf07a150fa28d16a73909ed86f6ac12faa6fca7d23e254a7 | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Registry enrichment · Nodes | 14 | get\_value | node\_record\_2uxky-wdyby-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | c978298b01887ea1df04d4dff4436e98bcf5a7917f93e11d7fb4c60e7ff54886 | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Registry enrichment · Nodes | 15 | get\_value | node\_record\_zq2z2-glyb4-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | d6e6ffbce451b87bc7a784fbe0c02639603d8e8afbc47cea5481e55cd05b9f4b | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Registry enrichment · Nodes | 16 | get\_value | node\_record\_afxzh-b3yca-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | be0d16bcc8ac34aa2b30c17505392fd9a6e3dd266fe3cde81d764cc5266d3fbc | 9a34cfe03b96ce476cd56e51473ecdcf4adfb0e08a81280622148b9add58394f | 9 | — |
| Registry enrichment · Nodes | 17 | get\_value | node\_record\_db2kf-rtyce-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:42.948 UTC | d93c39e5dad6b345f3a16946378899552765f79e963592138092e40b664726fb | c50e38220aeb72e42e11f408b8f3a20e801b9a09db0cce332aa1abf5c4d8a54a | 9 | — |
| Registry enrichment · Operators | 1 | get\_value | node\_operator\_record\_d4h56-4c2fi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:43.302 UTC | d6bd293fdb86568ac703a572219f01030f1fc3a5ba20d6184771df71d95f62ed | b7a469fce576bc5f0ffe09c60c5c7547423ab90160a86d9f71c535df6364257e | 25 | — |
| Registry enrichment · Operators | 2 | get\_value | node\_operator\_record\_d3g3k-r23fi-ba | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:43.302 UTC | 4fa37126004210f138e4a470265f13e48a463775b19a800c6c043f9579067341 | bc8572c5d088d87e16d73701f59a02e3135c91965012deab1a153bd0eebf3582 | 25 | — |
| Registry enrichment · DataCenters | 1 | get\_value | data\_center\_record\_fixture-0 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:43.634 UTC | f2a1652b184f4903441c185e4f75666250e116ddfc55c9a6b6eb92e1e6b6fb55 | 2463378715bdb8a06123a9dff29e19870852dce08d95c90b7a45ce15a11d81d6 | 80 | — |
| Registry enrichment · DataCenters | 2 | get\_value | data\_center\_record\_fixture-1 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:43.634 UTC | 825fd5006a70b5d13fee09bb31eedc65c9592eff95026598ae5eae75a1761222 | 42df72beb94c88c8654c293d38c6fb24216ed0975ec211e7c21238bba1c1f80a | 80 | — |
| Registry enrichment · Role | 1 | get\_value | nns\_subnet\_id | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:43.990 UTC | dcf35c4bec323ea1feb4b58dc22ae37801372bd60be9cf950ca0a27a9f8dff91 | 4cdd267ab9320daa812408894fca044891acc034f7e60a0c6d05104eda09df85 | 47 | — |
| Final Governance verification | 1 | get\_proposal\_info | 990011 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:44.680 UTC | 34120e54b09d36b4c77715feca238d83584c71ea0ce9ddcf55d81903f0b56537 | 1d275ce6db37fb87a5e653bcef9394aba3a3f7e4746bd7813a9096e187375f8b | 440 | — |

</details>

<details>
<summary>Accepted Governance discovery source receipts (4)</summary>

| ID | Method | Item | Canister | Observed at | Argument SHA-256 | Reply SHA-256 | Bytes | Rejection |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | get\_proposal\_info | 990011 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.012 UTC | 34120e54b09d36b4c77715feca238d83584c71ea0ce9ddcf55d81903f0b56537 | 1d275ce6db37fb87a5e653bcef9394aba3a3f7e4746bd7813a9096e187375f8b | 440 | — |
| 2 | list\_proposals | Open and adopted before None | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.012 UTC | 8178e19650c447132e0ca1b72f81e65df3e5200f15038b56141093b9a7e553eb | 7cd65cacb32dcf9a87d81598e65c3bd6af720779677165f9c39ad03f73dd662b | 540 | — |
| 3 | list\_proposals | Open and adopted before Some(990011) | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.012 UTC | 7d9d97252fd8a3e7ba3732ab402a01ff490ffdd157ec3471244b982b4d2c9684 | 315ddac773cf085376eb7fb2660f5489551871d3a43812fcddc924e7cd82bee5 | 278 | — |
| 4 | get\_proposal\_info | 990012 | uxrrr-q7777-77774-qaaaq-cai | 2026-11-28 10:14:45.012 UTC | 705003043a8527999d34725fec987de4f415b628dc83e2c51e156860167e2f1a | 383a646ed3708974279fd77c8c38a98f0ad9f7ec618feacb6a53d2c0fc033d0c | 362 | — |

</details>
